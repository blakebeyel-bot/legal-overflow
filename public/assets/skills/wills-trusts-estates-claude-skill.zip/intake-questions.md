# Intake Questions

Ask in the order given. Fields marked **[Required]** must be answered before drafting begins. Where the attorney responds with "unknown," record the answer as `[TO BE CONFIRMED: description]` and proceed; Phase 3 will flag it.

For married clients, most answers are captured for each spouse independently. Where a question is inherently joint, it is so labeled.

---

## Section 0 — Ethics and scope gates

**These questions are true gates. The skill does not move to Section 1 until they are answered.**

1. **[Required]** Is the attorney using this skill acting as counsel of record for the client? (The skill does not operate without an attorney behind the wheel.)
2. **[Required]** Has the client been advised, in the engagement letter or a separate writing, that the attorney uses generative AI tools in the representation, and has the client provided informed written consent? *(Per ABA Formal Opinion 512 (July 29, 2024) and state-bar analogs. The skill refuses Phase 2 absent affirmative answer.)*
3. **[Required]** Is there any actual or potential conflict of interest between the attorney and any beneficiary named in the plan, or between joint clients (e.g., spouses with divergent dispositive intent)? If yes, has conflict been disclosed and consent obtained?
4. **[Required]** Is the drafting attorney (or a member of the drafting firm, or a person related to the drafting attorney within the degrees in the governing-state's analog to ABA Model Rule 1.8(c)) named anywhere as a beneficiary, fiduciary, or recipient of a non-compensatory benefit? If yes, route to `ethics-and-compliance.md` hard-refusals before proceeding.
5. **[Required]** Is this package for in-person, paper execution? *(The skill v1.0.0 does not draft electronic wills or for remote online notarization.)*

---

## Section 1 — Client identity and jurisdiction

1. **[Required]** Legal name of the client (and spouse, if applicable).
2. **[Required]** Date of birth of client (and spouse).
3. **[Required]** Mailing address of principal residence.
4. **[Required]** State of domicile for estate-planning purposes. *(This drives the jurisdictional checklist the skill loads. If the client has more than one residence, identify which state is domicile and flag the presence of real property in other states.)*
5. Prior states of domicile material to the plan (prior wills still on file, prior marriages, prior trusts).
6. Citizenship of client (and spouse). Relevant for estate-tax marital deduction if a spouse is a non-U.S.-citizen.

## Section 2 — Family

1. **[Required]** Marital status. If married, date and state of marriage.
2. Prior marriages, date of each dissolution, and whether any pre-divorce instrument remains on file. *(Governing jurisdictions vary on automatic revocation of pre-divorce spousal provisions. Pre-divorce instruments must be identified so the skill can flag them in Phase 3.)*
3. **[Required]** Children — full names, dates of birth, and for each: parent of each child; biological/adopted; any special needs (SSI, SSDI, Medicaid, or government-benefit eligibility concerns); any estrangement the plan should account for.
4. Grandchildren and more-remote descendants, if the plan provides for any.
5. Any person the client wishes to treat as a child or descendant who is not biologically so (stepchildren, foster children). Flag if so.
6. Any person the client wishes to expressly disinherit. Capture the reason if known and confirm the attorney is advising on spoliation / contest risk.

## Section 3 — Assets and liabilities

1. **[Required]** Approximate total net worth bracket (under $500K, $500K–$2M, $2M–$10M, $10M–$25M, over $25M). Drives whether federal / state estate-tax planning is live.
2. **[Required]** Real property — address, approximate value, title (individual, joint tenants, tenants in common, tenants by entireties in states that recognize it, trust), mortgage balance. Flag whether any parcel is the homestead and whether the governing state imposes devise restrictions on the homestead.
3. Brokerage / banking accounts — institution, approximate value, current titling.
4. Retirement accounts — type (401(k), traditional IRA, Roth IRA, inherited IRA, pension), institution, approximate value, current primary and contingent beneficiary designations.
5. Life insurance — carrier, face amount, owner, insured, current beneficiaries.
6. Business interests — entity name, entity type, client's percentage ownership, presence of a buy-sell or operating agreement that constrains transfer.
7. Significant tangible personal property (art, jewelry, collectibles, vehicles) the client wishes to dispose of by specific devise or by tangible-personal-property memorandum.
8. Digital assets (cryptocurrency holdings, domain names, online accounts of value, NFTs). Capture whether the state has adopted RUFADAA (or the local equivalent).
9. Liabilities of material size.

## Section 4 — Fiduciary nominees

Nominate primary and at least one alternate for each role.

1. **[Required]** Trustee of the revocable trust during incapacity and after death. *(If the drafting attorney or firm member is being nominated, route to hard-refusal ethics gate.)*
2. **[Required]** Personal representative of the pour-over will. *(Same routing as above.)*
3. Guardian of the person of minor children (if any).
4. Guardian of the property of minor children (if any).
5. **[Required]** Agent under the Durable Power of Attorney for financial matters. Note whether the client wants any of the following powers expressly granted: authority to make gifts, authority to amend or revoke the revocable trust, authority to change beneficiary designations, authority to engage in self-dealing transactions for tax purposes, authority over retirement-plan beneficiary designations.
6. **[Required]** Agent under the Advance Directive for Health Care. Capture any disqualifications under the governing state's rules (facility employees, treating physicians).
7. Preneed / standby guardian of the declarant — if the governing state authorizes a standalone declaration.
8. Preneed / standby guardian of the declarant's minor children — if authorized.

## Section 5 — Dispositive plan

1. **[Required]** At death, how should the residuary estate pass? Typical options: to surviving spouse outright; to surviving spouse in a continuing marital trust (QTIP, GPA, credit shelter / disclaimer); to descendants per stirpes; to descendants in continuing trusts to stated ages; to a specific person or charity. Capture the client's instruction verbatim.
2. If descendants take in trust, at what ages and on what terms? (Outright at age X; staggered distributions; HEMS standard; fully discretionary; income-only.)
3. Trustee-removal powers? Should beneficiaries have the power to remove and replace the trustee with a qualified successor? With any limitations to prevent loss of independent-trustee status for tax purposes?
4. Should any beneficiary be disinherited on specified contingencies (substance abuse, creditor protection, divorce)?
5. Specific devises. Capture each devisee, the item or amount, and any conditions.
6. Charitable dispositions. Identify each charity (exact legal name, EIN, address); form (outright, charitable remainder trust, charitable lead trust); amount or percentage.
7. Tangible personal property memorandum. Does the client want the will to reference a separate writing under the governing state's tangible-personal-property memorandum statute?

## Section 6 — Tax planning

1. For clients in the over-$2M bracket: is federal estate-tax planning live? Has the client made lifetime gifts reducing the unified credit? Is portability / deceased-spousal-unused-exclusion (DSUE) being preserved?
2. State estate or inheritance tax — does the governing state impose one? Threshold?
3. Generation-skipping transfer tax — is GST planning live?
4. Charitable-deduction strategies — any active lifetime charitable vehicle (DAF, private foundation, supporting organization) the plan should coordinate with?
5. Retirement-account beneficiary planning post-SECURE Act — has the client considered the 10-year payout rule for designated beneficiaries and any conduit-trust vs. accumulation-trust design for trust beneficiaries?
6. Basis planning. If the client is in a community-property state or can avail themselves of a community-property trust in a recognizing state, is the IRC § 1014(b)(6) double step-up planning being considered?

## Section 7 — Contingencies and safeguards

1. Common-disaster provision — if spouses die simultaneously, whose estate is deemed to have survived?
2. Disappearance / presumption of death — any specific instruction?
3. Anti-lapse override — does the client want to negate the state's default anti-lapse rule for any specific devisee?
4. Spendthrift — confirm the trust will include a spendthrift clause and whether the governing state recognizes any material exceptions.
5. Contest / in terrorem clause — is one desired? (Availability and enforceability vary by state; flag for attorney judgment.)
6. Special-needs trust — if any beneficiary receives means-tested government benefits, is a third-party special-needs sub-trust designed to preserve eligibility?
7. Pet-care trust — if any beneficiary is a pet, does the governing state recognize a honorary-pet-trust statute?

## Section 8 — Administrative

1. Who will hold the original executed documents? (Firm vault, client, a named custodian.) If a non-firm custodian, remind the attorney of the custodian's duty to deposit the original will with the probate clerk on death, where applicable.
2. Where will the documents be signed? (Firm office, client's home, assisted-living facility, hospital.) Execution-formalities memo must be calibrated to the location.
3. Any urgency (e.g., client is traveling, is in pre-surgery posture, is receiving hospice care)? Flag capacity-at-execution concerns if urgency is health-driven.
4. Is there a prior will or trust that will be expressly revoked by the new instruments? Locate the prior instruments and flag any funding coordination required (e.g., retitling assets out of an old trust).

## Section 9 — Closing

1. **[Required]** Has the attorney confirmed capacity to execute at the time the client's answers were given, and does the attorney intend to make a fresh capacity assessment at signing?
2. **[Required]** Has the attorney identified any red flags of undue influence (unequal bargaining position, beneficiary present at intake, last-minute departure from a long-standing plan, isolation of client from family)? If yes, attorney to decide whether to proceed.
3. Is there anything the client has said outside the form that the attorney thinks the drafter should know? *(The skill treats this as a free-text field; anything captured here is flagged in Phase 2 for drafter attention.)*

---

## Sign-off

- Date intake completed: ___
- Attorney completing intake: ___
- Attorney affirms Section 0 answers remain true as of this date: ___
