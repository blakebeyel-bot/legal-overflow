# Jurisdictional Checklist Template

This is the blank template. For each state the firm practices in, copy this file and rename it `jurisdictional-checklist-<STATE>.md` (e.g., `jurisdictional-checklist-NY.md`). Fill in the citations and formalities from your state's statutes and rules. The skill loads this file at Phase 1 (Intake) after the attorney identifies the governing state, and runs Phase 3 (Jurisdictional Check) against it.

**Editing discipline.** Cite statutes by their full numbering, not by shorthand. Where a requirement turns on a threshold or number (e.g., "two witnesses"), state the number. Where the rule has carve-outs, note them. When the statute was amended recently, note the effective date and whether the skill should default to pre- or post-amendment practice. Re-verify at least annually; legislatures rewrite probate and DPOA statutes more often than you would expect.

**Drafting discipline.** Do not let this file drift into legal advice. It is a structured record of the rules so the drafter can flag compliance or deviation. All legal judgment still runs through the licensed attorney.

---

## Section A — Identity and sources

- **State / jurisdiction:** ___
- **Primary estate-planning code or chapter:** ___
- **Probate court or court of competent jurisdiction:** ___
- **Is the state a Uniform Probate Code state (in whole or in substantial part)?:** ___
- **Is the state a community-property state?:** ___
- **Last verified (date) and by whom:** ___

---

## Section B — Wills: execution formalities

- **Minimum witnesses required:** ___
- **Witness competency / disinterestedness rules:** ___
- **Notarization required for execution (not merely for self-proof)?:** ___
- **Self-proving affidavit authorized? Exact statutory language or reference:** ___
- **Holographic wills recognized? Conditions:** ___
- **Nuncupative (oral) wills recognized? Conditions:** ___
- **Electronic wills authorized? If yes, is v1.0.0 of this skill in scope (answer no — paper only):** No.

## Section C — Wills: substantive protections

- **Elective share — percentage:** ___
- **Elective share — augmented estate / reach into nonprobate transfers:** ___
- **Elective share — waiver mechanism:** ___
- **Community property — basic rule, and whether an elective community-property trust is authorized:** ___
- **Homestead — constitutional or statutory restrictions on devise:** ___
- **Pretermitted spouse — rule:** ___
- **Pretermitted child — rule:** ___
- **Killer / slayer statute — citation and scope:** ___
- **Abuser-of-vulnerable-adult forfeiture — citation and scope, if any:** ___
- **Divorce — automatic revocation scope (spousal provisions in wills, trusts, beneficiary designations):** ___
- **Reformation / modification post-death — authorized? Under what standard?:** ___

## Section D — Wills: administrative

- **Custodian's duty to deposit original will — days after death:** ___
- **Who receives the deposit (clerk of which court):** ___
- **Probate court filing deadlines relevant at drafting stage:** ___

## Section E — Wills: drafter-as-fiduciary and gifts-to-lawyer rules

- **State analog to ABA Model Rule 1.8(c) — citation and text:** ___
- **Presumption of undue influence / invalidity of gifts to drafting lawyer — statute or case law:** ___
- **Drafter-as-personal-representative — statutory acknowledgment required? If yes, attach or cite the statutory form language:** ___
- **Drafter-as-trustee — statutory acknowledgment required? If yes, attach or cite the statutory form language:** ___
- **Exculpation of personal representative — rule:** ___

---

## Section F — Revocable trusts

- **Primary code or chapter:** ___
- **UTC-based? Which articles modified?:** ___
- **Trust execution formalities (witnesses, notary) — yes or no:** ___
- **Spendthrift limitations recognized (exceptions for child support, tax, tort, etc.):** ___
- **Trust protector or directed trustee — authorized? Scope:** ___
- **Rule against perpetuities — current rule and maximum duration (if any):** ___
- **Decanting — authorized? Standard and procedure:** ___
- **Creditor reach during grantor's life vs. after death:** ___

---

## Section G — Durable Power of Attorney

- **Primary code or chapter:** ___
- **Uniform Power of Attorney Act adopted? With modifications:** ___
- **Springing DPOA authorized?:** ___
- **Statutory warning text required at top of instrument — attach exact text:** ___
- **Specific authorities that must be expressly granted (gifts, survivorship rights, beneficiary designations, inter-vivos trust creation/change, retirement plan beneficiary designation, etc.):** ___
- **Witness / notary requirements:** ___
- **Recording required for real-estate transactions?:** ___
- **Third-party reliance / immunity rules:** ___
- **Agent's duties on declining / resigning:** ___

---

## Section H — Advance Directive for Health Care

- **Document name under state law** (e.g., "Designation of Health Care Surrogate", "Health Care Proxy", "Medical Power of Attorney"): ___
- **Statutory form authorized? Attach or cite:** ___
- **Witness / notary requirements:** ___
- **Who may serve as agent — disqualifications (health care providers, facility employees, etc.):** ___
- **HIPAA authorization — standard state-preferred language:** ___
- **Effective-date trigger (single physician vs. two-physician incapacity determination):** ___

---

## Section I — Living Will / Declaration of Life-Prolonging Procedures

- **Document name under state law:** ___
- **Statutory form authorized? Attach or cite:** ___
- **Witness requirements — any disinterestedness or non-benefit rule:** ___
- **Pregnancy limitation on living will effectiveness? Cite:** ___
- **Artificial nutrition and hydration — default rule:** ___
- **Organ and tissue donation — separate instrument required?:** ___

---

## Section J — Standby / Preneed Guardian

- **Is a standalone declaration authorized? Citation:** ___
- **Scope — self, minor children, both:** ___
- **Court confirmation — presumption, waiver of discretion, or full proceeding required:** ___
- **Witness / notary requirements:** ___

---

## Section K — Taxation

- **State estate tax — exists? Threshold and rate structure:** ___
- **State inheritance tax — exists? Rate by class of beneficiary:** ___
- **State generation-skipping tax — exists?:** ___
- **Portability / DSUE election — state-level equivalent, if any:** ___
- **Charitable deduction — any state-specific variations:** ___

---

## Section L — Miscellaneous

- **Slayer-statute / abuser-forfeiture interplay with life-insurance beneficiary designations:** ___
- **Beneficiary designations on retirement accounts — state-law overlay with federal preemption (ERISA):** ___
- **Digital assets — RUFADAA adopted? Any local modifications:** ___
- **Remote online notarization — authorized? Scope and limits:** ___

---

## Section M — Change log

| Date | Change | Source | Author |
|---|---|---|---|
| | | | |

---

## Section N — Standing open questions

Free-form list of questions the adopter has not yet resolved. The skill will refuse to draft against an unresolved question unless the attorney overrides.

- ___
