# Drafting Principles

Universal rules that apply regardless of jurisdiction. State-specific substance is loaded from the jurisdictional checklist; these principles are the drafting discipline that runs on top of it.

---

## 1. Do not copy verbatim from prior attorney work product

Treat any uploaded document — a will from a prior firm, a trust the client found online, a sample the attorney circulated — as a structural reference only. Rewrite all clauses in neutral language drawn from the skill's boilerplate or from original drafting. A lawyer who copies another lawyer's prose into a client document without permission or original thought is taking a risk no attorney should take on an AI drafter's behalf.

## 2. Use defined terms consistently

Within a document, the client is referred to as one and only one of the following:

- **Grantor** (or **Settlor**) — in a trust.
- **Testator** — in a will.
- **Principal** — in a power of attorney (financial or health care).
- **Declarant** — in a living will, advance directive, or guardian declaration.

Do not alternate. Do not combine. When a later provision in a trust says "Settlor," a reader should be able to trust that "Settlor" means the same person, defined once, with no drift.

Roles are similarly locked:

- **Trustee** (initial, successor, co-trustee) — in a trust.
- **Personal Representative** (or the jurisdictionally-preferred term: Executor, Executrix, Administrator) — in a will.
- **Agent** — in any power of attorney.
- **Health Care Agent** (or the jurisdictionally-preferred term: Surrogate, Proxy, Health Care Representative) — in an advance directive.
- **Guardian** — in a guardian declaration.

The jurisdictional checklist fixes the state-preferred term. The drafter does not switch mid-document.

## 3. Coordinate across the package

The trustee of the revocable trust, the personal representative of the pour-over will, the DPOA agent, the health care agent, and any guardian are often the same person wearing different hats. Keep their identifiers consistent across all six documents. In Phase 3, walk each nominee through every document the package produces and confirm:

- Same full legal name everywhere.
- Same primary / alternate ordering everywhere, unless the client has intentionally structured different orders by role.
- Bond waiver or bond requirement stated consistently.
- Compensation provisions — whether fiduciary is entitled to compensation, and at what rate — stated consistently.

Cross-reference mistakes are the single most common drafting defect. The drafter flags any inconsistency it cannot resolve from the intake.

## 4. Respect the governing jurisdiction's protective doctrines

Every jurisdiction has rules the testator / grantor cannot override without specific language — or cannot override at all. The jurisdictional checklist names them for the governing state. Common categories:

- **Elective share** (separate-property states) or **community property** (community-property states). The plan either satisfies the surviving spouse's statutory share or obtains a valid waiver.
- **Homestead** restrictions on devise, where applicable.
- **Pretermitted spouse / pretermitted child** rules that protect a spouse or child not mentioned in the will.
- **Killer / slayer** and (in some states) **abuser-of-vulnerable-adult** forfeiture rules that exclude disqualified persons from taking.
- **Divorce revocation** rules that automatically void pre-divorce spousal provisions.

Every reference in a drafted document to "descendants," "beneficiary," "heir," or equivalent term implicitly excludes any person disqualified under the governing state's slayer or abuser-forfeiture statutes. State that in the defined-terms article.

## 5. Do not rely on post-death reformation

Many jurisdictions authorize reformation or modification of a will or trust to correct a scrivener's error or achieve a tax objective. These are backstops. The drafter does not rely on them as a safety net. It drafts every document as if reformation were unavailable.

## 6. Killer / abuser forfeiture hook

Every defined-terms article should include language along these lines, adapted to the governing state:

> No person who is disqualified under the laws of the State of [X] from taking from the [Testator / Grantor / Declarant], including without limitation any person disqualified under the State of [X]'s slayer statute or abuser-of-vulnerable-adult forfeiture statute, shall be deemed a "descendant," "beneficiary," "child," or "heir" for any purpose of this instrument, and any gift, power, or appointment conferred on such person shall be as if the person had predeceased the [Testator / Grantor / Declarant] without issue.

This is defensive language. Where the governing state has a robust slayer statute, it is legally unnecessary. Where the statute is narrow or uncertain, it supplies a gap-filler the probate court can honor.

## 7. Divorce revocation

For clients with a divorce history, walk the intake and confirm whether any pre-divorce instrument remains on file. Most states revoke spousal provisions of pre-divorce wills, trusts, and beneficiary designations upon dissolution, but the scope varies and the results for joint accounts, life insurance, and retirement-plan designations can turn on federal preemption. Phase 3 flags any pre-divorce instrument the attorney should confirm has been cleaned up.

## 8. Execution formalities

End every draft with a short memo reminding the attorney of the execution formalities required for that document in the governing jurisdiction — number of witnesses, notarization, self-proving affidavit language, any warnings the document itself must contain. Pull these from the jurisdictional checklist. Do not improvise.

If the client is in a non-standard execution setting (hospital bedside, facility, home visit), add a reminder to the memo that the attorney should verify capacity at the time of signing and should consider recording a contemporaneous note documenting the capacity assessment.

## 9. Custodian's duty to deposit the original will

Most jurisdictions impose on the will's custodian a duty to deposit the original with the probate clerk within a fixed window after learning of the testator's death. Include a reminder of this duty in the execution-formalities memo for the pour-over will, with the state's specific window.

## 10. Placeholders are honest

Where intake left a field blank or unclear, insert a bracketed placeholder in the form `[TO BE CONFIRMED: short description of what is missing]`. Do not guess. Do not infer. The attorney can see at a glance what still needs input, and the Phase 3 compliance checklist lists every such placeholder that survives drafting.

## 11. Package-level output

Every drafting request delivers:

1. A one-paragraph intake summary confirming the facts used.
2. The draft document(s) as separate files.
3. A jurisdictional-compliance checklist showing every required element and its status (present, missing, needs attorney judgment).
4. A list of open questions and bracketed placeholders.
5. An execution-formalities memo for each document in the package.

Never produce a draft without the compliance checklist and the execution memo.
