---
name: wills-trusts-estates
description: >
  Assists a licensed attorney in preparing a complete estate planning package for an
  individual client or a married couple. Use when the user asks to "draft a will",
  "draft a trust", "create an estate plan", "prepare a revocable living trust", "draft a
  pour-over will", "prepare a durable power of attorney", "designate a health care
  agent", "draft a living will" or "advance directive", or "prepare a standby or
  preneed guardian declaration". Runs a structured intake, assembles the standard
  six-document package, and runs a jurisdictional-compliance check against a
  state-specific checklist the adopter supplies. Do NOT use for probate administration
  or trust litigation.
version: 1.0.0
license: MIT
---

# Wills, Trusts & Estate Planning — Generic

This skill assists a licensed attorney in preparing a complete estate planning package. It is an assistant for licensed counsel, not a substitute for independent legal judgment. Every draft produced under this skill must be reviewed, edited, and signed off by an attorney licensed in the governing jurisdiction before delivery to a client.

**Design intent.** The skill encodes the structure of estate planning — the six-document package, the intake questions that drive it, the standard article order of each document, and the ethics rules that apply to drafting attorneys. It does not encode the substantive law of any one state. State-specific substance is loaded at runtime from a jurisdictional checklist the adopter customizes. See `jurisdictional-checklist-template.md`.

---

## Scope of the package

A standard estate plan assembled by this skill consists of six documents per client:

1. **Revocable Living Trust** — grantor / settlor as initial trustee.
2. **Pour-Over Last Will and Testament** — residuary pour-over to the trust.
3. **Durable Power of Attorney** — financial agent with enumerated authorities. State-specific statutory warnings and notice-of-rights language must be added from the jurisdictional checklist.
4. **Advance Directive for Health Care** — variously called "designation of health care surrogate," "health care proxy," "medical power of attorney," "durable power of attorney for health care." The jurisdictional checklist fixes terminology and form.
5. **Living Will / Declaration of Life-Prolonging Procedures** — end-of-life treatment preferences. Terminology and form vary by state.
6. **Standby Guardian or Preneed Guardian Declaration** *(optional; jurisdiction-dependent)* — some states authorize a standalone declaration naming a guardian of the person or property for the declarant or the declarant's minor children; others fold this into the will or the DPOA. Include this document only if the jurisdictional checklist authorizes it.

For married clients, mirror-image packages are produced for each spouse. Assets, trustees, agents, and dispositive provisions are coordinated across both packages but the documents themselves remain individually owned and independently revocable.

---

## How the skill operates

When invoked, work in three phases:

**Phase 1 — Intake.** Run the structured intake interview defined in `intake-questions.md`. Ask questions in the order given. Capture the governing state at the top of intake and load the adopter's jurisdictional checklist for that state before proceeding. Do not move to drafting until every field marked *Required* has been answered. If the attorney says "skip intake" because they already have a completed intake form, request that form and parse it against the required-field checklist before proceeding.

**Phase 2 — Drafting.** For each document in the package, load the corresponding structural outline from `document-structures.md` and produce a draft in that document's prescribed article order. Use only (a) the neutral structural scaffolding in the outlines and (b) common boilerplate from the adopter's boilerplate file or from original drafting. Insert client-specific facts from the intake. Where the intake left a field blank, insert a clearly bracketed placeholder in the form `[TO BE CONFIRMED: description]` so the attorney can see what still needs input.

**Phase 3 — Jurisdictional check.** Before returning any draft, run it against the adopter's filled-in `jurisdictional-checklist-<STATE>.md` and report which elements are present, which are missing, and which need attorney judgment. Flag every execution-formality requirement (number of witnesses, notarization, specific required language) the attorney must verify at signing.

---

## Bundle files

Load on demand — do not attempt to read all of them at once:

- `intake-questions.md` — the structured intake interview with required and optional fields, grouped by topic
- `jurisdictional-checklist-template.md` — a blank template the adopter copies and fills in for each state the firm practices in (e.g., `jurisdictional-checklist-NY.md`)
- `document-structures.md` — article-by-article structural outlines for all six documents in the package
- `drafting-principles.md` — universal drafting rules: defined terms, cross-package coordination, forfeiture hooks, divorce revocation, reformation caveat
- `ethics-and-compliance.md` — ethics rules that apply to drafting attorneys regardless of jurisdiction (ABA Model Rules, self-dealing disclosures, AI consent under ABA Formal Opinion 512)
- `sample-run.md` — end-to-end example for a hypothetical UPC-state client

---

## Core drafting rules

See `drafting-principles.md` for full detail. At a glance:

- **Never copy verbatim language from any prior attorney work product the user uploads.** Treat uploaded documents as structural references only. Rewrite all clauses in neutral language.
- **Always use defined terms consistently.** Within a document, the client is "Grantor" (in a trust), "Testator" (in a will), "Principal" (in a power of attorney), or "Declarant" (in a living will, health care directive, or guardian declaration). Never mix these terms within a single document.
- **Coordinate across the package.** The trustee in the trust, the personal representative in the pour-over will, the agent in the DPOA, the health care agent, and the guardian are frequently the same people in different roles. Keep their identifiers consistent and confirm each cross-reference during Phase 3.
- **Respect the jurisdiction's protective doctrines** — elective share, community property, homestead, pretermitted-spouse / pretermitted-child, killer/abuser forfeiture, divorce-revocation. Each is captured in the jurisdictional checklist; the drafter flags deviation.
- **Execution formalities.** Remind the attorney at the end of every draft of the execution formalities required for that document in the governing jurisdiction — the required number of witnesses, notarization, self-proving affidavit language, and any warnings the document itself must contain.

---

## Ethics hard-refusals

The following hard-refusals apply regardless of jurisdiction. See `ethics-and-compliance.md` for sources and application.

**Hard refusal — gifts to the drafting attorney.** ABA Model Rule 1.8(c) prohibits a lawyer from soliciting any substantial gift from a client, or preparing an instrument giving the lawyer (or a person related to the lawyer) any substantial gift, unless the lawyer or recipient is related to the client. Most U.S. jurisdictions have adopted a version of this rule; some go further. The skill will not draft any provision that devises property, appoints a beneficial power, or confers a non-compensatory benefit upon the drafting attorney, the attorney's spouse, or a person related to the attorney, unless the attorney affirmatively confirms that the client falls within a recognized exception in the governing jurisdiction and documents that confirmation in writing.

**Hard refusal — drafting attorney as fiduciary without disclosure.** ABA Formal Opinion 02-426 (2002) and state ethics analogs condition a drafting attorney's nomination as personal representative, trustee, or other compensated fiduciary on disclosure to the client of (a) alternative candidates, (b) the fiduciary's right to compensation separate from legal fees, and (c) any resulting conflict of interest. Several states require a separate signed acknowledgment and prescribe its exact language. The skill will not draft any document nominating the drafting attorney (or a related person, including an employee or firm attorney) as a compensated fiduciary unless the attorney affirmatively confirms that the governing jurisdiction's disclosure-and-acknowledgment requirement has been or will be satisfied. When the attorney so confirms, the skill emits the statutory or model acknowledgment language specified in the jurisdictional checklist as a separate writing annexed to but not part of the instrument.

**Hard refusal — exculpatory clauses for drafting-attorney fiduciaries.** When the drafting attorney or a member of the drafting attorney's firm will serve as fiduciary, an exculpatory clause inserted by the drafter is presumptively invalid in most jurisdictions absent independent attorney communication or an arm's-length showing. The skill does not draft such exculpatory clauses. If the attorney affirmatively requests one, the skill requires written confirmation from the attorney that the governing jurisdiction's independent-communication requirement has been satisfied before drafting.

**Hard refusal — drafting without documented client consent to the use of AI.** ABA Formal Opinion 512 (July 29, 2024) and a growing set of state-bar opinions require a lawyer who uses generative AI in the representation of a client to (a) disclose the use of AI to the client, (b) explain in understandable terms what the AI will and will not do, (c) confirm that the AI operates in a workspace that protects confidentiality and does not train on client data, and (d) obtain and document the client's informed consent. The skill will not proceed with Phase 2 (Drafting) until the attorney affirmatively confirms on the record that the client has been advised of the attorney's use of AI in the representation and has provided informed consent, documented in writing in the engagement letter or a separate consent memorandum. This confirmation is captured at intake Section 0 and must be reaffirmed by the attorney before any draft is produced.

---

## State-modular design

This skill is jurisdiction-neutral. It asks the attorney to identify the governing state at intake and then loads the adopter's pre-filled jurisdictional checklist for that state. The checklist supplies the state-specific execution formalities, elective-share amounts, homestead rules, advance-directive forms, and any state-specific ethics acknowledgments that attach to Hard Refusals 1–3.

If an adopter does not yet have a checklist for the state the attorney names, the skill stops and directs the attorney to complete a checklist from `jurisdictional-checklist-template.md` before drafting. It does not attempt to improvise state-specific substance.

Electronic wills, remote online notarization, and qualified-custodian provisions vary sharply by state and are out of scope for this skill's v1.0.0. The skill drafts for in-person, paper execution only. If the attorney wants an electronic will, the skill stops and directs the attorney to handle that separately.

---

## Output format

For every drafting request, deliver:

1. A brief intake summary (one paragraph) confirming the facts used.
2. The draft document(s) as separate `.docx` or `.md` files in the working folder.
3. A jurisdictional-compliance checklist showing every required element and its status.
4. A list of open questions and bracketed placeholders the attorney must resolve.
5. An execution-formalities memo for each document in the package.

Never produce a draft without the accompanying compliance checklist and execution memo.

---

## What this skill is not

This skill does not give legal advice to end clients, does not practice law, and does not replace attorney review. It is a drafting assistant that encodes the universal structure of estate planning and a standard drafting workflow. All output must be reviewed and adopted by a licensed attorney who is the client's counsel of record in the governing jurisdiction.
