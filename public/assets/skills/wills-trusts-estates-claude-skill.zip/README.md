# Wills, Trusts & Estate Planning — Generic

A Claude skill that assists a licensed attorney in preparing a complete estate planning package — revocable living trust, pour-over will, durable power of attorney, advance directive for health care, living will, and (where the jurisdiction authorizes) a standby or preneed guardian declaration — with a structured three-phase workflow: intake, drafting, jurisdictional compliance check.

The skill is jurisdiction-neutral. State-specific substance (execution formalities, elective share, homestead, statutory warnings, drafter-as-fiduciary acknowledgments) is supplied by an adopter-maintained jurisdictional checklist that the skill loads at runtime. The skill does not improvise state-specific law.

**Every draft produced under this skill must be reviewed, edited, and signed off by an attorney licensed in the governing jurisdiction before delivery to a client.** The skill assists counsel; it does not substitute for independent legal judgment.

**License:** MIT.
**Version:** 1.0.0.

---

## Bundle contents

| File | Purpose |
|---|---|
| `SKILL.md` | The skill definition — scope, three-phase workflow, ethics hard-refusals, output format. |
| `taxonomy-of-documents.md` | Map of the six-document package with state-by-state variation notes. |
| `jurisdictional-checklist-template.md` | Blank template adopters copy and fill in for each state the firm practices in. |
| `intake-questions.md` | Structured intake interview with required and optional fields. |
| `drafting-principles.md` | Universal drafting rules — defined terms, cross-package coordination, forfeiture hooks, placeholders. |
| `ethics-and-compliance.md` | Ethics rules a drafting attorney owes regardless of jurisdiction, with ABA Model Rule and Formal Opinion citations. |
| `document-structures.md` | Article-by-article structural outlines for all six documents. |
| `sample-run.md` | End-to-end example for a hypothetical UPC-state client. |
| `prompt-pack.md` | Paste-ready prompts for use without a skill-execution environment. |
| `README.md` | This file. |

---

## Install

### Option A — As a Claude skill (Claude Code, Cowork, Agent SDK)

Copy the folder into the host's skills directory. For example:

```
~/.claude/skills/wills-trusts-estates/
```

The host identifies the skill by the `name: wills-trusts-estates` field in `SKILL.md`'s YAML frontmatter. The skill loads its own reference files on demand; the host does not need to expose them separately.

### Option B — Hosted skill catalog

Upload the folder as a single skill entry. The host should treat `SKILL.md` as the main definition and the remaining files as attachments reachable relative to `SKILL.md`.

### Option C — Prompt-only (no skill host)

Use the prompts in `prompt-pack.md`. Paste each prompt into any general-purpose LLM and follow the three-phase pattern manually. The prompts embed the structural outlines and the intake questionnaire.

---

## Adopter setup — before first use

1. **Populate a jurisdictional checklist** for each state the firm practices in. Copy `jurisdictional-checklist-template.md` to `jurisdictional-checklist-<STATE>.md` and fill in every section from the state's current probate code, UPOAA (as adopted), and advance-directive statutes. Re-verify annually; legislatures amend these statutes more often than firms expect.
2. **Load the firm's engagement-letter AI-use disclosure** — confirm that your standard engagement letter includes the disclosure required by ABA Formal Opinion 512 (July 29, 2024) and any state-bar analog (FL Ethics Op. 24-1, NY Op. 1233, CA Practical Guidance, etc.), and that the firm captures informed client consent in writing. The skill refuses to produce drafts without attorney affirmation that this has been done.
3. **Decide on drafter-as-fiduciary posture.** If the firm's practice routinely nominates firm members as personal representatives or trustees, document the jurisdictional-specific acknowledgment forms in the checklist and confirm the firm's standard engagement language addresses the disclosures required by ABA Formal Opinion 02-426 and the state's analogs.
4. **Audit boilerplate library.** Adopters who have a firm boilerplate library (spendthrift, savings, severability, fiduciary powers) should cross-check it against `document-structures.md` to confirm the structural placement matches. The skill does not ship a boilerplate library; it relies on the drafter's.

---

## How to use — attorney flow

1. Open the skill with a drafting request (e.g., "draft a full estate package for a married couple in State X").
2. Answer Section 0 (ethics gates). The skill will not advance until these are answered affirmatively.
3. Answer the remaining intake sections, section by section. If the firm already has a completed intake on file, upload it; the skill will parse it against the required-field checklist.
4. The skill identifies the governing state and loads the firm's `jurisdictional-checklist-<STATE>.md`. If no checklist exists for the named state, the skill stops and directs the attorney to complete one.
5. The skill produces drafts. Each draft carries bracketed placeholders for any fact the intake left open.
6. The skill produces a jurisdictional-compliance checklist and an execution-formalities memo for each document.
7. The attorney reviews, edits, and finalizes. The skill does not finalize; the attorney does.

---

## What this skill does NOT do

- **Does not give legal advice.** All output must be reviewed and adopted by a licensed attorney who is the client's counsel of record.
- **Does not practice law.** The skill is an assistant, not counsel.
- **Does not draft electronic wills** or documents for remote online notarization. v1.0.0 is paper-and-ink only.
- **Does not handle probate administration or trust litigation.** Those require different skills, or none at all.
- **Does not opine on state-specific substance** that the adopter has not captured in the jurisdictional checklist.
- **Does not replace the drafting attorney's judgment at signing.** Capacity assessment, conflict review, and execution oversight stay with counsel.

---

## Maintenance

- **Jurisdictional checklists.** Re-verify each state's checklist at least annually. Key rewrite-triggers: probate-code amendments, new UPOAA provisions, legislative changes to elective share or pretermitted-spouse / pretermitted-child rules, new drafter-as-fiduciary statutes, RUFADAA or e-will amendments.
- **Ethics opinions.** Ethics-and-compliance guidance evolves — monitor new ABA Formal Opinions and the state bars' AI-use opinions. When a new opinion adds a duty the skill should enforce, add it to `ethics-and-compliance.md` and wire it into Section 0 of the intake.
- **Taxonomy of documents.** Revisit annually. If a jurisdiction the firm serves has added a new recognized document (e.g., a digital-asset designation instrument or a recent electronic-will equivalent), add it to the taxonomy.

---

## License

MIT License.

Copyright (c) 2026

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---

## Disclaimer

This skill is a workflow aid for licensed attorneys. It does not provide legal advice, does not create an attorney-client relationship with any reader, and does not substitute for attorney judgment. All draft output must be reviewed and adopted by a licensed attorney who is the client's counsel of record in the governing jurisdiction. The adopter is responsible for the accuracy of any jurisdictional checklist the skill loads.
