# Taxonomy of Documents — Standard Estate Planning Package

This file lists the six documents the skill produces and flags which elements vary materially by state. Use this as a map when deciding which documents to produce for a given client and as a sanity check at the end of Phase 3.

---

## 1. Revocable Living Trust

**Purpose.** A funded revocable trust holds titled assets during the grantor's lifetime, provides seamless management on incapacity, and avoids probate at death for assets properly titled into the trust.

**Near-universal structure.** Recitals; name and tax status of the trust; identification of grantor and initial trustee; funding mechanism; lifetime distributive provisions (self, spouse, descendants); incapacity provisions; successor trustee succession; dispositive provisions at grantor's death (outright, per-stirpes, per-capita, continuing trust, generation-skipping, special-needs); trustee powers; trustee compensation and exculpation; spendthrift clause; savings clause; governing law; amendment and revocation.

**State-variable elements.**

- **Elective-share coordination.** Separate-property states protect surviving spouses via a statutory elective share that reaches into the trust; the percentage and reach vary. Community-property states have a different baseline (equal ownership of community property). The jurisdictional checklist must specify whether the trust can be used to defeat the elective share, the elective-share percentage, and any augmented-estate concept.
- **Homestead and similar protections.** Several states (e.g., Florida, Texas) impose constitutional or statutory restrictions on devise of the homestead that constrain what the trust can do with it. Confirm via the checklist.
- **Community property vs. separate property.** For married clients in community-property states, whether to title assets into a joint community-property trust (preserving community character and the IRC § 1014(b)(6) double basis step-up) or into separate revocable trusts is a material design decision. The checklist flags whether this is the client's state.
- **Rule against perpetuities / dynasty trusts.** Some states have abolished or extended the RAP; others retain a 21-years-plus-life formulation. The checklist sets the maximum permissible duration.
- **Drafter-as-trustee disclosures.** Some states require a signed statutory acknowledgment before a drafting attorney can receive trustee compensation. See ethics hard refusals.

---

## 2. Pour-Over Last Will and Testament

**Purpose.** Catches any asset that escapes trust funding and devises it to the trust. Nominates the personal representative (executor) and, if minor children, the guardian of the person and property.

**Near-universal structure.** Caption; identification of testator; revocation of prior wills; family identification; payment of debts and expenses; residuary devise to trustee of the revocable trust; nomination of personal representative and successors; nomination of guardian of minor children; fiduciary powers; tax apportionment; execution clause; self-proving affidavit or equivalent.

**State-variable elements.**

- **Execution formalities.** Every U.S. jurisdiction requires the testator's signature and two witnesses; many permit a "self-proving affidavit" that avoids probate-court witness testimony. A minority permit holographic wills. Electronic wills are authorized by statute in a growing number of states but rules vary sharply — qualified-custodian, remote-online-notarization, vulnerable-adult protections all in play. This skill drafts for in-person paper execution only.
- **Homestead devise.** Where applicable, the will's residuary devise of the homestead must be tested against the state's constitutional or statutory homestead restrictions.
- **Pretermitted spouse / pretermitted child.** All jurisdictions have some rule protecting a spouse the testator married after making the will, and (less uniformly) protecting children born or adopted after. The checklist specifies the rule's terms.
- **Drafter-as-PR disclosures.** Some states require a signed statutory acknowledgment before a drafting attorney can receive personal-representative compensation.
- **Custodian's duty to deposit the original will.** Most states impose a duty on the will's custodian to deposit the original with the probate clerk within a fixed window after learning of the testator's death. The checklist states the window.
- **Divorce revocation.** Most states automatically revoke pre-divorce spousal provisions upon divorce, but the scope and carve-outs vary. Intake captures divorce history and Phase 3 flags any pre-divorce instrument that may need republication.

---

## 3. Durable Power of Attorney

**Purpose.** Appoints an agent to act on financial matters on the principal's behalf, surviving the principal's incapacity.

**Near-universal structure.** Identification of principal; appointment of agent and successor agents; statement of durability (effective immediately or springing); enumeration of general and special authorities; authority to engage in gift transactions (if applicable); authority over retirement accounts; authority regarding real property; authority over entity interests; agent compensation and reimbursement; third-party reliance and indemnification; revocation; execution.

**State-variable elements.**

- **Statutory warnings.** Many states require specific notice language at the top of the instrument — a warning to the principal about the nature of the powers being granted, and a notice to third parties about their obligations. The checklist supplies the exact required text.
- **Uniform Power of Attorney Act (UPOAA).** About half the states have adopted some form of the UPOAA with varying modifications. Some jurisdictions retain a "springing" (incapacity-triggered) DPOA; others disfavor or prohibit it. The checklist states which regime applies.
- **Specific-grant requirements.** Several states require certain powers (e.g., gift transactions, creating or changing survivorship interests, designating beneficiaries, exercising fiduciary powers) to be conferred only by express, affirmative written grant in the instrument itself. The checklist lists them.
- **Recording.** Some states require recording the DPOA with the county or land records when real-estate transactions are contemplated. The checklist specifies.

---

## 4. Advance Directive for Health Care

Terminology varies: "designation of health care surrogate" (FL); "health care proxy" (NY, MA); "durable power of attorney for health care" (CA); "medical power of attorney" (TX).

**Purpose.** Appoints an agent to make health care decisions on the principal's behalf when the principal cannot. Should authorize access to protected health information under HIPAA.

**Near-universal structure.** Identification of principal; appointment of health care agent and successors; scope of authority (consent to or refuse medical treatment, admission to facilities, receive PHI); HIPAA authorization; effective-date trigger (incapacity determined by attending physician vs. a two-physician rule); limitations and instructions; execution.

**State-variable elements.**

- **Form.** Some states prescribe a statutory form that must be followed "substantially." The checklist attaches or cites the form.
- **Witness and notary requirements.** Vary widely. The checklist specifies.
- **Who may serve as agent.** Several states disqualify the principal's health care provider, an employee of that provider, an operator of a health care facility, or an employee of the facility. The checklist lists disqualifications.
- **HIPAA authorization.** The HIPAA privacy rule is federal but the form of authorization is local; embed state-preferred language.

---

## 5. Living Will / Declaration of Life-Prolonging Procedures

Sometimes combined with the advance directive in a single instrument; often separate.

**Purpose.** Declares the principal's wishes regarding life-prolonging treatment in circumstances of terminal condition, end-stage condition, or persistent vegetative state. Distinct from the health care agent's general decisionmaking authority because the living will speaks directly to the physician.

**Near-universal structure.** Identification of declarant; circumstances in which the declaration takes effect; treatment preferences (withholding or withdrawing life-prolonging procedures; artificial nutrition and hydration; pain management); organ and tissue donation (optional); religious or conscience provisions; revocation; execution.

**State-variable elements.**

- **Statutory form.** Most states prescribe a form or suggested language.
- **Witness requirements.** Often differ from the will's witness requirements — some states require two non-relatives who would not benefit under the will; some require one witness and a notary.
- **Pregnancy limitation.** A number of states by statute limit the living will's effect during pregnancy. The checklist notes any such limitation.

---

## 6. Standby / Preneed Guardian Declaration *(optional)*

Some states authorize a standalone written declaration by which a competent adult designates a preneed guardian of the declarant's own person or property, to take effect on later incapacity, and/or a standby or preneed guardian for the declarant's minor children. Others fold this designation into the will or the DPOA. Others do not authorize a standalone declaration at all.

**Near-universal structure.** Identification of declarant; declaration of guardian of the person; declaration of guardian of the property; alternates; circumstances of effectiveness; revocation; execution.

**State-variable elements.**

- **Availability.** The checklist says whether the state authorizes a standalone declaration. If it does not, the nomination goes in the will or the DPOA.
- **Court confirmation.** Some states make the declaration a rebuttable presumption in favor of the nominee; some treat it as an express waiver of court discretion; others require a formal proceeding before guardianship is established.
- **Minor children.** The checklist states whether a separate declaration for minor children is recognized apart from the will's nomination of guardian.

---

## Summary table — document vs. state-variable element

| Document | Exec formalities | Statutory form | Drafter-as-fiduciary acknowledgment | Pregnancy limit | Electronic permitted |
|---|:-:|:-:|:-:|:-:|:-:|
| Revocable Trust | Low | No | In some states | No | Varies |
| Pour-Over Will | High | Optional self-proving | In some states | No | Growing authorization, out of scope v1.0.0 |
| Durable POA | Medium | Some states | N/A | No | Some states |
| Advance Directive | Medium | Most states | N/A | Some states | Varies |
| Living Will | Medium | Most states | N/A | Yes, in some | Varies |
| Standby/Preneed Guardian | Varies | Rare | N/A | No | Varies |
