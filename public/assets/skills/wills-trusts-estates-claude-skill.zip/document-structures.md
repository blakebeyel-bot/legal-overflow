# Document Structures

Article-by-article structural outlines for the six documents in the standard estate planning package. Use each outline as the skeleton for drafting. Fill client-specific facts from the intake; insert bracketed placeholders where intake is incomplete; do not import verbatim prose from any uploaded prior work product.

Each outline is jurisdiction-neutral. The jurisdictional checklist supplies the state-specific requirements that slot in at the marked positions — statutory warnings, elective-share coordination, execution formalities, specific-grant requirements, and similar.

---

## Part I — Revocable Living Trust

**Article I — Name and Initial Parties.** Name of the trust. Identification of grantor. Appointment of initial trustee (typically the grantor). Definition of "Grantor" and "Trustee" as defined terms usable throughout.

**Article II — Funding.** Schedule of initial funding. Acknowledgment that additional property may be added by the grantor or by testamentary pour-over. Authority to accept additional property.

**Article III — Lifetime Provisions.** While the grantor is living and has capacity: full revocability, amendability, distributive discretion to or for the grantor. Acknowledgment that the trust is a grantor trust for income-tax purposes and all taxable items are reported on the grantor's personal return.

**Article IV — Incapacity.** Definition of incapacity (single-physician vs. two-physician determination; disability insurer certification; court order — adopt the governing jurisdiction's preferred rule). On incapacity: successor trustee serves; distributions permitted for grantor's health, education, maintenance, and support (HEMS); discretionary distributions for spouse and dependents to maintain accustomed standard of living, if intake so directs.

**Article V — Distributions on the Grantor's Death — Debts and Expenses.** Coordination with the pour-over will. Authority to pay debts, funeral, expenses of administration, taxes. Tax-apportionment election.

**Article VI — Specific Gifts at Death.** Each specific devise from intake.

**Article VII — Residuary Disposition.** The client's core dispositive plan. Structured as the intake directs — outright to surviving spouse, to marital trust, to descendants per stirpes, to descendants in continuing trust, charitable remainder, etc. Each sub-plan gets its own sub-article.

**Article VIII — Continuing Trusts for Beneficiaries** *(if the plan calls for them).* For each beneficiary: definition of the beneficiary's separate trust; trustee; distribution standard (HEMS, fully discretionary, unitrust, income-only); termination events (stated ages, specified events); distribution on termination.

**Article IX — Trustee Succession.** Primary and alternate trustees. Procedure for resignation, removal, appointment of successor. Acceptance procedure. Bond waiver (or requirement).

**Article X — Trustee Powers.** Broad grant of powers subject to fiduciary duty. Prudent-investor standard. Delegation. Right to employ professionals.

**Article XI — Trustee Compensation.** Reasonable compensation, unless declined. Reimbursement of expenses. Indemnification consistent with fiduciary-duty limits.

**Article XII — Spendthrift; Creditor Protections.** Spendthrift clause. Note any statutory limits.

**Article XIII — Savings / Perpetuities.** Limit trust's duration to the governing jurisdiction's perpetuities rule.

**Article XIV — Killer / Abuser Forfeiture Hook.** Standard defined-terms exclusion of disqualified persons.

**Article XV — Definitions.** Descendants; distribution by representation; incapacity; related-defined terms. Include the forfeiture hook from Article XIV.

**Article XVI — Governing Law.** Governing state's law.

**Article XVII — Amendment and Revocation.** During grantor's life and capacity, fully revocable and amendable by signed writing delivered to the trustee. Upon grantor's death, becomes irrevocable subject to explicit reserved powers, if any.

**Execution.** Grantor signs; trustee signs acceptance; notary acknowledgment if required by the governing jurisdiction.

---

## Part II — Pour-Over Last Will and Testament

**Article 1 — Caption and Preamble.** Testator's full legal name, residence. Declaration of testamentary intent. Revocation of prior wills and codicils.

**Article 2 — Family.** Identification of spouse (if any); identification of living children (full names, dates of birth); acknowledgment if any child was intentionally omitted, with the statement that such omission is not the result of oversight.

**Article 3 — Debts, Expenses, and Taxes.** Authority and direction regarding debts, funeral, and administration expenses. Tax-apportionment direction coordinated with the revocable trust.

**Article 4 — Specific Devises** *(if any).* Any tangible-personal-property memorandum referenced under the governing state's authorizing statute.

**Article 5 — Homestead** *(if the governing jurisdiction imposes devise restrictions).* Devise structured to comply with the state's constitutional or statutory homestead protections.

**Article 6 — Residuary Devise.** To the trustee of the revocable trust, to be administered under its terms as they exist at the testator's death.

**Article 7 — Nomination of Personal Representative.** Primary and alternates. Authority to act without bond, if the governing jurisdiction permits waiver. Authority to act independently / without supervision, if the jurisdiction recognizes that option. Drafter-as-PR routing through the ethics hard-refusal before finalizing.

**Article 8 — Nomination of Guardian of Minor Children** *(if applicable).* Guardian of the person; guardian of the property.

**Article 9 — Fiduciary Powers.** Broad incorporated-by-reference grant (or express enumeration, per adopter preference).

**Article 10 — Definitions.** Descendants; distribution by representation; spouse; the killer/abuser-forfeiture hook.

**Article 11 — No-Contest Provision** *(if requested and enforceable in the governing jurisdiction).*

**Article 12 — Miscellaneous.** Survivorship; common disaster; anti-lapse override, if any; simultaneous death.

**Article 13 — Execution.** Testator's signature. Witness attestation. Self-proving affidavit (per the governing jurisdiction's statutory form), if authorized.

---

## Part III — Durable Power of Attorney

**Statutory warning** *(placed above the body of the instrument, as the governing state requires).*

**Section 1 — Designation.** Principal; agent; successor agents.

**Section 2 — Effective Date and Durability.** Immediately effective and durable; OR springing on a stated incapacity trigger, if the governing jurisdiction permits and the client elects.

**Section 3 — General Authorities.** Enumerated authorities as customary under the governing state's DPOA statute (Uniform Power of Attorney Act authorities where adopted).

**Section 4 — Specific Authorities Requiring Express Grant** *(per the governing jurisdiction's checklist).* Typical candidates: gifts; creation, amendment, or revocation of inter-vivos trusts; designation or change of beneficiary designations on life insurance, retirement accounts, or accounts with payable-on-death or transfer-on-death registration; survivorship rights; authority to engage in retirement-plan elections; waiver of the principal's right to be a beneficiary.

**Section 5 — Third-Party Reliance and Indemnification.** Per the governing state's customary provisions.

**Section 6 — Agent's Duties.** Reference to statutory duties; resignation procedures.

**Section 7 — Compensation and Reimbursement.** Whether the agent is entitled to compensation; reimbursement of reasonable expenses.

**Section 8 — Revocation and Amendment.**

**Section 9 — Governing Law.**

**Execution.** Signature. Witness and notary per the governing jurisdiction.

---

## Part IV — Advance Directive for Health Care

(Terminology — "designation of health care surrogate," "health care proxy," "medical power of attorney" — follows the governing state. The jurisdictional checklist fixes the state-preferred term.)

**Section 1 — Declarant and Agent.** Declarant; health care agent; successor agents.

**Section 2 — Scope of Authority.** Consent to or refuse medical treatment; admission to facilities; access to protected health information; hire or discharge providers; arrange home or hospice care; make decisions regarding artificial life support consistent with the living will, if separate.

**Section 3 — HIPAA Authorization.** Designation as a "personal representative" for HIPAA purposes; authorization to receive PHI; duration of authorization.

**Section 4 — Effective-Date Trigger.** Incapacity as determined in accordance with the governing state's rule (single-physician vs. two-physician determination).

**Section 5 — Limitations and Special Instructions.** Any instructions the declarant wishes binding on the agent.

**Section 6 — Disqualifications.** Recital that the agent is not disqualified under the governing state's rules.

**Execution.** Per the governing state's statutory form requirements. Witnesses and any notary.

---

## Part V — Living Will / Declaration of Life-Prolonging Procedures

**Section 1 — Declarant and Declaration.** Full legal name. Declaration of testamentary-equivalent intent.

**Section 2 — Triggering Circumstances.** Terminal condition; end-stage condition; persistent vegetative state. Use the governing state's statutory defined terms where they exist.

**Section 3 — Treatment Preferences.** Withholding or withdrawing life-prolonging procedures; artificial nutrition and hydration (separately elected); pain management and palliative care (default opt-in).

**Section 4 — Pregnancy Provision** *(if the governing state imposes a pregnancy limitation).*

**Section 5 — Organ and Tissue Donation** *(optional).*

**Section 6 — Primary Physician** *(optional).*

**Section 7 — Revocation.**

**Execution.** Per the governing state's statutory form requirements. Note any witness disinterestedness rule.

---

## Part VI — Standby / Preneed Guardian Declaration *(optional, jurisdiction-dependent)*

**Section 1 — Declarant.**

**Section 2 — Declaration as to Guardian of the Declarant's Own Person.** Primary; alternates.

**Section 3 — Declaration as to Guardian of the Declarant's Own Property.** Primary; alternates.

**Section 4 — Declaration as to Guardian of the Person of the Declarant's Minor Children** *(if the governing state recognizes a standalone declaration distinct from the will's nomination).*

**Section 5 — Declaration as to Guardian of the Property of the Declarant's Minor Children.**

**Section 6 — Effective-Date Trigger.** Consistent with the governing state's statute.

**Section 7 — Revocation.**

**Execution.** Per the governing state's statutory form requirements.

---

## Cross-document sanity check (run during Phase 3)

- Client's legal name identical in every caption.
- Spouse's legal name identical.
- Each nominee's legal name and address identical across every document that names them.
- Primary/alternate ordering consistent across roles the same individual fills, unless intake intentionally differs.
- Bond waiver or bond requirement stated consistently.
- Compensation provisions stated consistently.
- Governing-law recital consistent across all trust, DPOA, and advance-directive instruments.
- Dispositive-plan cross-references between the pour-over will and the revocable trust resolve correctly (e.g., trust article numbers referenced in the will match the trust's article numbers as drafted).
- Homestead, elective-share, pretermitted-spouse, and pretermitted-child issues addressed per the jurisdictional checklist.
- Every forfeiture-hook recital is present in every document that references descendants or beneficiaries.
