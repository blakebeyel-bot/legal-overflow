# Ethics and Compliance

This file collects the ethics rules that bind a drafting attorney regardless of jurisdiction, with citations to the ABA Model Rules and the most prominent federal or cross-jurisdictional opinions. Every state is different — the jurisdictional checklist supplies the state-specific citations, amounts, and acknowledgment forms that bolt onto these universal duties. This file names the duties; the checklist supplies the local implementation.

---

## 1. Competence and supervision

**ABA Model Rule 1.1** requires a lawyer to provide competent representation, which "requires the legal knowledge, skill, thoroughness, and preparation reasonably necessary for the representation." Comment 8 to Rule 1.1 (as amended) expressly extends the duty to keeping abreast of the benefits and risks associated with relevant technology. A lawyer using an AI drafting tool bears the same competence duty as the lawyer drafting unassisted — the tool does not substitute judgment.

**ABA Model Rule 5.3** requires a lawyer to make reasonable efforts to ensure that non-lawyer assistants (which, under ABA Formal Opinion 512 (2024), includes generative AI tools treated as non-lawyer assistance) conduct themselves consistently with the lawyer's professional obligations. The lawyer remains responsible for the output.

---

## 2. Communication and informed consent to AI use

**ABA Formal Opinion 512 (July 29, 2024)** — "Generative Artificial Intelligence Tools" — addresses a lawyer's duties when using generative AI in client representation. Key obligations:

- **Competence** — understand the tool's capabilities and limitations sufficiently to use it responsibly.
- **Confidentiality (Rule 1.6)** — evaluate whether the tool preserves confidentiality, including whether prompts or outputs are used to train the provider's models or are otherwise exposed. Obtain informed client consent before inputting client confidential information into a tool that does not adequately protect it.
- **Communication (Rule 1.4)** — inform the client of the lawyer's use of AI to the extent a reasonable client would want to know; in some matters and some jurisdictions, the informed-consent showing is explicit and in writing.
- **Reasonable fees (Rule 1.5)** — fees and expenses charged for AI-assisted work must be reasonable; a lawyer generally may not charge the client for the lawyer's own time spent learning to use the tool, and must disclose how AI costs will be passed through.

Several state bars have issued parallel opinions (including California, New York, Florida, and others) with state-specific refinements. Check the checklist for the governing state.

**Hard refusal.** The skill will not proceed to Phase 2 (Drafting) until the attorney affirmatively confirms at intake Section 0 that the client has been advised of the use of AI in the representation and has provided informed written consent (typically captured in the engagement letter or a separate consent memorandum).

---

## 3. Conflicts of interest

**ABA Model Rules 1.7, 1.8, 1.9** govern conflicts between current clients, former clients, and the lawyer's own interests. For estate-planning joint representations (most commonly spouses), the lawyer must be alert to divergent dispositive intent, unequal bargaining power, possible undue influence, and the practical impossibility of keeping secrets between jointly-represented spouses.

The intake's Section 0 item 3 requires the attorney to affirm that any actual or potential conflict has been disclosed and consent obtained.

---

## 4. Gifts to the drafting lawyer

**ABA Model Rule 1.8(c)**: "A lawyer shall not solicit any substantial gift from a client, including a testamentary gift, or prepare on behalf of a client an instrument giving the lawyer or a person related to the lawyer any substantial gift unless the lawyer or other recipient of the gift is related to the client."

**Operational implementation.** The skill refuses to draft any provision that devises property, appoints a beneficial power, or confers a non-compensatory benefit upon the drafting attorney, the attorney's spouse, or a person related to the attorney within the degrees the governing jurisdiction has adopted. If the attorney asserts that a relationship-based exception applies (for example, the client is the attorney's parent), the skill requires an express, contemporaneous written attorney confirmation naming the exception before drafting.

Several jurisdictions go further than the Model Rule (e.g., voiding the gift as a matter of substantive law rather than merely subjecting the lawyer to discipline). The jurisdictional checklist names the governing state's rule.

---

## 5. Lawyer as fiduciary

**ABA Formal Opinion 02-426 (2002)** — "Lawyer Serving as Fiduciary" — conditions a lawyer's simultaneous service as fiduciary (personal representative, trustee, attorney-in-fact) and counsel for the estate on informed client consent that includes disclosure of (a) that alternative qualified fiduciaries exist, (b) that fiduciary compensation is separate from and in addition to attorney compensation, and (c) the resulting conflict of interest.

Several states have adopted statutory disclosure-and-acknowledgment requirements that go beyond the Model Opinion — typically requiring a separate signed acknowledgment with prescribed language before the drafting attorney may receive fiduciary compensation. Examples include Florida F.S. §§ 733.617(8) and 736.0708(4), New York Surrogate's Court Procedure Act § 2307-a, and California Probate Code § 21350–21392 (addressing the related but distinct gifts-to-drafter problem).

**Operational implementation.** The skill refuses to draft any instrument nominating the drafting attorney (or a firm member, or a person related to the attorney) as a compensated fiduciary unless the attorney affirmatively confirms that the governing jurisdiction's disclosure-and-acknowledgment requirement has been or will be satisfied. When confirmed, the skill emits the statutory or model acknowledgment language specified in the jurisdictional checklist as a separate writing annexed to but not part of the instrument.

---

## 6. Exculpation of the fiduciary

Where the drafting attorney or firm member is named as fiduciary, the Uniform Trust Code § 1008 and its state analogs render an exculpatory clause inserted by the drafter presumptively invalid unless (a) the clause is fair under the circumstances, and (b) its existence and contents were adequately communicated to the settlor / testator, typically through independent counsel. Analogous rules apply to personal-representative exculpation in most states.

The skill does not draft exculpatory clauses for a fiduciary who is the drafting attorney or a firm member. If the attorney affirmatively requests one, the skill requires written confirmation that the governing jurisdiction's independent-communication requirement has been satisfied.

For fiduciaries unaffiliated with the drafting attorney, standard-form exculpatory provisions are drafted subject to the governing state's public-policy limits (e.g., no exculpation for intentional misconduct, gross negligence, or reckless indifference).

---

## 7. Confidentiality and tool selection

**Model Rule 1.6(c)** requires reasonable efforts to prevent inadvertent or unauthorized disclosure of client information. When choosing or using an AI tool, the lawyer must:

- Confirm the tool's provider will not train on client inputs without express authorization.
- Confirm appropriate enterprise-grade data handling (encryption in transit and at rest, access controls, subprocessor lists).
- Confirm the lawyer's ability to comply with data-retention and data-destruction obligations the firm or client has accepted.

If the tool does not satisfy these conditions, do not use it. This is a gate on the engagement, not a later flag.

---

## 8. Candor and the capacity problem

**ABA Model Rule 1.14** addresses a client with diminished capacity. A drafting attorney working on an estate plan should be alert to capacity questions at every intake and should re-assess at execution. The skill does not make capacity assessments and flags any urgency factor that may bear on capacity (hospital bedside, facility, health-driven urgency) for the attorney.

---

## 9. The substantive-law backdrop that these ethics rules overlay

Several state jurisdictions have enacted substantive-law rules that reinforce the ethics rules — for example, voiding as a matter of law any gift to a drafting attorney that falls outside the relationship exception, or conferring a presumption of undue influence on the drafter. These substantive-law rules appear in the jurisdictional checklist (Section E). The drafting attorney must satisfy both the ethics duties named here and the state-law substantive rules named in the checklist.

---

## 10. Documentation

Every engagement should retain, at minimum:

- The executed engagement letter with AI-use disclosure and consent language.
- The completed intake form, including the Section 0 attorney affirmations.
- Any standalone written acknowledgment the jurisdictional checklist requires (drafter-as-fiduciary, drafter-as-beneficiary-by-exception, drafter-prepared exculpatory clause).
- The compliance checklist produced at Phase 3.
- The execution-formalities memo produced for each document.
- Any contemporaneous note of capacity assessment at intake and at execution.

These records are the attorney's principal defense if the plan is challenged and are essential to demonstrating the attorney's compliance with the rules summarized above.
