# Sample Run

A fictional run of the skill for a hypothetical client in a Uniform Probate Code state. The client, the state, and the plan are fabricated. The example is designed to show what each phase's output looks like, not to supply drafting text for any real matter.

---

## Matter

**Governing state.** Hypothetical UPC state ("**State X**"). The firm has filled in `jurisdictional-checklist-StateX.md` with State X's probate code, UPOAA adoption with three state-specific modifications, and advance-directive statutory form.

**Client.** Dana Okonkwo-Reyes, age 54, married to Priya Okonkwo-Reyes, age 52. Two children: Elena (age 17) and Marcus (age 14), both biological children of the marriage. Net worth approximately $3.8M, including the family residence ($1.1M, titled jointly with right of survivorship), a brokerage account ($1.6M, jointly held), retirement accounts ($850K in Dana's name, $210K in Priya's name), and a 30% interest in a closely held consulting LLC.

**Attorney.** Counsel of record is drafting a full six-document package for Dana and a mirror-image package for Priya. No member of the drafting firm is named as fiduciary or beneficiary. The engagement letter includes the firm's standard AI-use disclosure and the clients have returned signed consent.

---

## Phase 1 — Intake (abridged)

**Section 0 — Ethics gates.** All five items answered affirmatively. AI-use consent attached as Engagement Annex B.

**Section 1 — Jurisdiction.** State X. Checklist loaded.

**Section 2 — Family.** Marriage since 2007. No prior marriages. Two biological children of the marriage, both minors. No estrangement. Both spouses U.S. citizens.

**Section 3 — Assets.** Per matter summary.

**Section 4 — Fiduciary nominees.**

- Trustee of each spouse's revocable trust: the other spouse primary; Dana's sister (Tomiwa Okonkwo) as successor; a named corporate fiduciary as second successor.
- Personal representative: same ordering.
- Guardian of minor children (person and property): Dana's sister; Priya's brother (Rohan Patel) as alternate.
- DPOA agent: spouse primary; Tomiwa alternate.
- Health care agent: spouse primary; Tomiwa alternate.

**Section 5 — Dispositive plan.**

- On first death: residuary passes outright to the surviving spouse.
- On second death (or if common disaster): residuary passes to descendants in separate continuing trusts terminating at age 30 with HEMS distributions until that age.
- No specific devises.
- No charitable dispositions in v1.
- No tangible-personal-property memorandum at this time.

**Section 6 — Tax.** Below the federal estate-tax threshold. State X has no state estate tax. No portability election considerations. Standard SECURE Act post-SECURE conduit-trust analysis deferred pending attorney's review of whether the 10-year rule makes a conduit trust worth the complexity here; placeholder noted.

**Section 7 — Contingencies.** Common disaster deemed as simultaneous death, each spouse's estate settled as if having survived the other. Anti-lapse default accepted. Spendthrift included. No in-terrorem clause requested.

**Section 8 — Administrative.** Firm retains originals in firm vault. Signing at firm office. No urgency.

**Section 9 — Capacity and red flags.** Attorney affirms capacity and identifies no red flags.

---

## Phase 2 — Drafting (excerpts)

*The skill produces all six documents for each spouse (twelve documents in total). Below are two excerpts to show what the output looks like.*

### Excerpt — Dana's Revocable Living Trust, Article VII (Residuary Disposition)

> **Article VII — Residuary Disposition.**
>
> *Section 7.1 — On Grantor's Death.* Upon the Grantor's death, the Trustee shall administer the trust as follows.
>
> *Section 7.2 — To Surviving Spouse.* If the Grantor's spouse, Priya Okonkwo-Reyes, survives the Grantor, the Trustee shall distribute the entire then-remaining trust estate outright and free of trust to the Grantor's spouse.
>
> *Section 7.3 — If Spouse Does Not Survive.* If the Grantor's spouse does not survive the Grantor, the Trustee shall divide the then-remaining trust estate into equal separate shares, one share for each of the Grantor's then-living descendants, by representation, and shall hold each share in a separate continuing trust under Article VIII.
>
> *Section 7.4 — Simultaneous Death.* For purposes of this Article VII, if the Grantor and the Grantor's spouse die under circumstances rendering it impossible to determine the order of their deaths, the Grantor's spouse shall be deemed not to have survived the Grantor.
>
> *Section 7.5 — Forfeiture Hook.* No person disqualified under the laws of State X from taking from the Grantor, including without limitation any person disqualified under State X's slayer statute or abuser-of-vulnerable-adult forfeiture statute, shall be deemed a "descendant" or "beneficiary" for any purpose of this Article, and any gift, power, or appointment otherwise conferred shall be as if such person had predeceased the Grantor without issue.
>
> *Section 7.6 — Placeholder.* `[TO BE CONFIRMED: Whether Dana's retirement account beneficiary designation should name this trust (via a conduit provision in Article VIII for each child's sub-trust) or name each spouse and child directly. Attorney to resolve post-SECURE Act tradeoffs and update beneficiary designations accordingly.]`

### Excerpt — Dana's Pour-Over Last Will, Article 7 (Personal Representative)

> **Article 7 — Nomination of Personal Representative.**
>
> *Section 7.1 — Primary Nomination.* I nominate my spouse, Priya Okonkwo-Reyes, as Personal Representative of my estate, to serve without bond to the extent State X law permits the waiver.
>
> *Section 7.2 — Alternates.* If my spouse is unable or unwilling to serve, I nominate my sister, Tomiwa Okonkwo, as Personal Representative. If neither my spouse nor Tomiwa Okonkwo is able or willing to serve, I nominate [corporate fiduciary to be confirmed], a trust company authorized to act as fiduciary in State X, as Personal Representative.
>
> *Section 7.3 — Independent Administration.* To the extent State X recognizes independent or unsupervised administration, I direct that my estate be so administered.
>
> *Section 7.4 — Placeholder.* `[TO BE CONFIRMED: Exact legal name, state of charter, and principal office of the corporate fiduciary the clients wish to name as second-alternate.]`

---

## Phase 3 — Jurisdictional compliance checklist (excerpt)

| Item | Required by checklist | Status in draft | Notes |
|---|---|:-:|---|
| Witnesses on will (State X) | Two disinterested | ✓ | Execution memo confirms |
| Self-proving affidavit (State X statutory form) | Attached as final page of will | ✓ | Statutory form reproduced verbatim from checklist |
| Homestead devise restriction | None in State X | n/a | State X has no constitutional homestead restriction |
| Elective share (State X) | 1/3 augmented estate | ✓ | Plan leaves surviving spouse entire residuary; exceeds elective share |
| Pretermitted spouse rule | UPC § 2-301 as enacted | ✓ | Marriage and children predate all instruments; N/A |
| Pretermitted child rule | UPC § 2-302 | ✓ | Both children identified in will |
| Slayer statute | UPC § 2-803 as enacted | ✓ | Forfeiture hook present in each instrument |
| Divorce revocation | UPC § 2-804 | n/a | No prior marriages |
| DPOA statutory warning text | State X §§ 12-345 | ✓ | Verbatim reproduction at top of DPOA |
| DPOA specific-grant authorities | Gift, survivorship, beneficiary changes, trust creation | ⚠️ | Trust-creation grant flagged for attorney review — client's instruction on that authority was ambiguous at intake; placeholder inserted |
| Advance-directive statutory form (State X) | Mandatory form | ✓ | Form reproduced |
| Advance-directive witness disqualifications | Treating physician, facility employee | ✓ | Recital included |
| Living will pregnancy limitation | None in State X | n/a | |
| Custodian's duty to deposit will | 30 days after death | ✓ | Reminder in execution memo |
| Drafter-as-fiduciary disclosures | Required if any firm member served | n/a | No firm member named |
| Drafter-as-beneficiary exceptions | Required if any firm member took | n/a | No firm member named |
| AI-consent documentation | Required | ✓ | Engagement Annex B attached |

---

## Phase 3 — Open items and placeholders

1. Corporate fiduciary to be named as second-alternate in each spouse's will and trust. *(Dana's will § 7.2; Priya's will § 7.2; Dana's trust Art. IX; Priya's trust Art. IX.)*
2. Retirement-account beneficiary designations — confirm whether Dana's $850K IRA and Priya's $210K IRA name the respective spouse and children directly, or name the respective revocable trust with conduit provisions in each child's sub-trust. Attorney to resolve post-SECURE Act tradeoffs. *(Dana's trust § 7.6; Priya's trust § 7.6.)*
3. DPOA authority regarding trust creation, amendment, or revocation — intake instruction was ambiguous. Attorney to confirm client preference and update DPOA Section 4. *(Dana's DPOA § 4; Priya's DPOA § 4.)*
4. Tangible-personal-property memorandum — neither spouse has prepared one, but the will recites that such a memorandum may be incorporated by reference if State X's authorizing statute applies. Attorney to decide whether to prepare a stub memorandum now or defer.
5. Common-disaster defined term — intake directed that each spouse's estate be settled as if having survived the other. Current draft adopts a deemed-non-survival rule against the other. Attorney to confirm that the drafts correctly implement intent given State X's 120-hour default rule.

---

## Phase 3 — Execution-formalities memo (excerpt, for Dana's will)

- **Witnesses.** Two disinterested witnesses, neither a beneficiary under the will. Each witness signs in the presence of the testator and each other. Recommend using firm staff who are not beneficiaries and who are not related to any beneficiary.
- **Self-proving affidavit.** Execute the State X statutory self-proving affidavit at the same sitting before a notary. State X authorizes combined attestation and self-proving.
- **Notary.** Required for self-proving affidavit. Confirm notary commission is current and that the notary is not a witness and is not a beneficiary.
- **Capacity assessment at signing.** Attorney to make a fresh capacity assessment at signing. Recommend a contemporaneous note to the file documenting the assessment.
- **Original will custody.** Firm vault retains the original after execution. Client receives a conformed copy. Client advised that State X's custodian-duty rule requires deposit of the original with the probate clerk within 30 days after the custodian learns of the testator's death.
- **Do not sign yet if.** If any of the Phase 3 open items remains unresolved at the signing appointment, do not sign the will. Reschedule.

---

## What this example is not

A template. State X is hypothetical. The UPC-aligned rules cited here are representative, not verbatim from any specific enactment. Do not lift this text into a real matter. Use it as a pattern for what a complete run looks like, then re-draft against the actual jurisdictional checklist and the actual intake.
