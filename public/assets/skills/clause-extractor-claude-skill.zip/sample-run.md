# Sample Run

This walks the clause-extractor through a short fictional SaaS master services agreement and shows what the output looks like. The contract is fabricated; any resemblance to a real agreement is coincidence.

---

## Input: `Acme SaaS MSA (fictional) — excerpt`

> **Section 7. Warranties; Disclaimer.**
> 7.1 *Service Warranty.* Provider warrants that the Services will be performed in a workmanlike manner and will materially conform to the Documentation. Customer's exclusive remedy for breach of this warranty shall be re-performance of the non-conforming Services or, at Provider's election, a pro-rata refund of fees paid for the non-conforming Services.
> 7.2 *Disclaimer.* EXCEPT AS EXPRESSLY SET FORTH IN SECTION 7.1, THE SERVICES ARE PROVIDED "AS IS" AND PROVIDER DISCLAIMS ALL OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
>
> **Section 8. Indemnification; Limitation of Liability.**
> 8.1 *Provider Indemnity.* Provider shall defend, indemnify, and hold harmless Customer from and against any third-party claim alleging that the Services, as provided by Provider and used by Customer in accordance with this Agreement, infringe a third party's U.S. patent, copyright, or trademark. Provider's aggregate liability under this Section 8.1, together with all other liability under this Agreement, shall not exceed the fees paid by Customer in the twelve (12) months preceding the claim.
> 8.2 *Exclusion of Damages.* IN NO EVENT SHALL EITHER PARTY BE LIABLE FOR ANY CONSEQUENTIAL, INCIDENTAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES, OR FOR LOST PROFITS, REVENUE, OR DATA, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
>
> **Section 11. Data Protection.**
> 11.1 *DPA.* The parties' Data Processing Addendum, attached as Exhibit C, is incorporated by reference. To the extent Provider processes Personal Data on Customer's behalf, Provider acts as Processor and Customer as Controller for purposes of the GDPR and CCPA. Cross-border transfers outside the EEA will be governed by the Standard Contractual Clauses attached to the DPA.
>
> **Section 14. Governing Law; Venue.**
> 14.1 This Agreement is governed by the laws of the State of Delaware, without regard to conflict-of-laws principles. The state and federal courts sitting in New Castle County, Delaware shall have exclusive jurisdiction over any dispute arising from this Agreement. EACH PARTY WAIVES ITS RIGHT TO A TRIAL BY JURY.

---

## Output

```json
[
  {
    "clause_id": "c_001",
    "clause_category": "warranty",
    "section_ref": "Section 7.1",
    "text": "Service Warranty. Provider warrants that the Services will be performed in a workmanlike manner and will materially conform to the Documentation. Customer's exclusive remedy for breach of this warranty shall be re-performance of the non-conforming Services or, at Provider's election, a pro-rata refund of fees paid for the non-conforming Services.",
    "notes": "Exclusive-remedy limitation embedded — paired with c_002 (limitation-of-liability) covering the exclusive-remedy sentence."
  },
  {
    "clause_id": "c_002",
    "clause_category": "limitation-of-liability",
    "section_ref": "Section 7.1 (second sentence)",
    "text": "Customer's exclusive remedy for breach of this warranty shall be re-performance of the non-conforming Services or, at Provider's election, a pro-rata refund of fees paid for the non-conforming Services.",
    "notes": "Paired with c_001 (warranty) — exclusive-remedy clause embedded inside the warranty section."
  },
  {
    "clause_id": "c_003",
    "clause_category": "warranty",
    "section_ref": "Section 7.2",
    "text": "Disclaimer. EXCEPT AS EXPRESSLY SET FORTH IN SECTION 7.1, THE SERVICES ARE PROVIDED \"AS IS\" AND PROVIDER DISCLAIMS ALL OTHER WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.",
    "notes": null
  },
  {
    "clause_id": "c_004",
    "clause_category": "indemnification",
    "section_ref": "Section 8.1 (first sentence)",
    "text": "Provider shall defend, indemnify, and hold harmless Customer from and against any third-party claim alleging that the Services, as provided by Provider and used by Customer in accordance with this Agreement, infringe a third party's U.S. patent, copyright, or trademark.",
    "notes": "IP-infringement indemnity scoped to U.S. rights only. Paired with c_005 (limitation-of-liability) — cap in Section 8.1 applies."
  },
  {
    "clause_id": "c_005",
    "clause_category": "limitation-of-liability",
    "section_ref": "Section 8.1 (second sentence)",
    "text": "Provider's aggregate liability under this Section 8.1, together with all other liability under this Agreement, shall not exceed the fees paid by Customer in the twelve (12) months preceding the claim.",
    "notes": "12-month fees cap — applies to indemnity in c_004 and to all other liability. Paired with c_004 (indemnification) and c_006 (limitation-of-liability)."
  },
  {
    "clause_id": "c_006",
    "clause_category": "limitation-of-liability",
    "section_ref": "Section 8.2",
    "text": "Exclusion of Damages. IN NO EVENT SHALL EITHER PARTY BE LIABLE FOR ANY CONSEQUENTIAL, INCIDENTAL, INDIRECT, SPECIAL, OR PUNITIVE DAMAGES, OR FOR LOST PROFITS, REVENUE, OR DATA, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.",
    "notes": "Consequential-damages exclusion, mutual. No carve-outs stated."
  },
  {
    "clause_id": "c_007",
    "clause_category": "data-protection",
    "section_ref": "Section 11.1",
    "text": "DPA. The parties' Data Processing Addendum, attached as Exhibit C, is incorporated by reference. To the extent Provider processes Personal Data on Customer's behalf, Provider acts as Processor and Customer as Controller for purposes of the GDPR and CCPA. Cross-border transfers outside the EEA will be governed by the Standard Contractual Clauses attached to the DPA.",
    "notes": "DPA incorporated by reference — extractor does not descend into Exhibit C. Downstream reviewer should extract Exhibit C separately."
  },
  {
    "clause_id": "c_008",
    "clause_category": "dispute-resolution",
    "section_ref": "Section 14.1",
    "text": "This Agreement is governed by the laws of the State of Delaware, without regard to conflict-of-laws principles. The state and federal courts sitting in New Castle County, Delaware shall have exclusive jurisdiction over any dispute arising from this Agreement. EACH PARTY WAIVES ITS RIGHT TO A TRIAL BY JURY.",
    "notes": "Delaware law, exclusive Delaware forum, jury waiver. No arbitration provision."
  }
]
```

---

## How to read the output

**Multi-label pairs.** Sections 7.1 and 8.1 each produced two entries — one for the primary subject and one for an embedded limitation. The verbatim text of the paired entries may overlap, and the `notes` field cross-references so downstream reviewers can see at a glance that they are looking at the same span under a different lens.

**Exhibit handling.** Section 11.1 incorporates a separate DPA by reference. The extractor does not descend into incorporated exhibits — that's a separate extraction pass. The `notes` field flags this for the downstream reviewer so the DPA is not skipped.

**No deviation analysis.** Every entry is descriptive. The extractor does not flag, score, or redline anything. A downstream contract-review workflow consumes this array and runs each entry through a clause-specific reviewer.

**`clause_id` stability.** IDs are sequential within a single extraction run. If the contract is re-extracted after edits, IDs are not guaranteed to be stable across runs — downstream tooling that needs cross-run stability should hash `(section_ref, clause_category, text_hash)` or equivalent.

---

## What a downstream workflow does with this

The typical next step is fan-out: each entry in the array is handed to a clause-specific reviewer (an `indemnification-reviewer`, `limitation-of-liability-reviewer`, `data-protection-reviewer`, etc.) that compares the clause text against a playbook position and returns a structured finding. Those findings are then assembled into a redlined contract and a risk memo — see, for example, a contract-review redline-assembler skill that consumes the finding shape.

The extractor is deliberately the dumb end of the pipeline. Keeping it dumb is what makes it reliable.
