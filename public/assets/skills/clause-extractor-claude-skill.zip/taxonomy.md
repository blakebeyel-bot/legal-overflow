# Clause Taxonomy — Default

This file defines the clause labels the extractor will emit and the trigger language that should cause a clause to be tagged with each label. Adopters should copy this file into their own skill repo and edit it for their industry — the extractor itself is taxonomy-agnostic.

**Rules of the road:**

- Do not add labels at runtime. Add labels here, then re-run.
- Trigger words are cues, not decision rules. A clause that mentions "insurance" in passing while actually governing termination is a `termination` clause, not an `insurance` clause — unless it independently creates an insurance obligation, in which case emit both.
- When a clause plausibly matches multiple labels, emit multiple entries. Multi-label is the common case, not the exception.

---

## Core labels

### `indemnification`

Operative language allocating the cost of third-party claims between the parties.

**Triggers:** "indemnify", "defend", "hold harmless", "indemnitee", "indemnitor", "claims against", "losses arising out of", "third-party claim".

**Pair with:** `limitation-of-liability` (if the indemnity is capped or carves out certain damages); `insurance` (if the indemnity is insurance-backed).

---

### `insurance`

Operative language requiring a party to maintain specified insurance coverage, name the other as additional insured, waive subrogation, or deliver certificates.

**Triggers:** "insurance", "policy", "coverage limits", "certificate of insurance", "additional insured", "primary and non-contributory", "waiver of subrogation", "umbrella", "excess", named coverage lines (e.g., "CGL", "auto liability", "professional liability", "cyber", "E&O").

**Pair with:** `indemnification` (insurance-backed indemnity); `industry-specific` if the named coverage line is industry-bespoke (e.g., marine protection-and-indemnity, nuclear liability).

---

### `limitation-of-liability`

Operative language capping aggregate liability, excluding categories of damages, or carving out exceptions from the cap.

**Triggers:** "aggregate liability", "liability shall not exceed", "in no event shall", "consequential", "incidental", "indirect", "punitive", "lost profits", "carve-out", "notwithstanding anything to the contrary".

**Pair with:** `indemnification` (cap or exception applies to indemnity); `warranty` (cap constrains warranty remedies).

---

### `payment-terms`

Operative language governing price, invoicing, due dates, late fees, retainage, offset/setoff, or pay-when-paid / pay-if-paid conditions.

**Triggers:** "invoice", "net __ days", "late fee", "interest on past due", "retainage", "offset", "setoff", "pay-when-paid", "pay-if-paid", "progress payment", "milestone payment", "lien waiver", "true-up", "audit right".

**Pair with:** `termination` (non-payment as termination trigger).

---

### `warranty`

Express or implied warranties, workmanship guarantees, disclaimers, and remedy limitations.

**Triggers:** "warrant", "warranty", "AS IS", "WITHOUT WARRANTIES", "fitness for a particular purpose", "merchantability", "workmanlike", "free from defects", "disclaim".

**Pair with:** `limitation-of-liability` (warranty remedies capped or exclusive).

---

### `termination`

Grounds and mechanics for ending the contract: for cause, for convenience, cure periods, effect of termination, survival.

**Triggers:** "terminate", "termination for cause", "termination for convenience", "material breach", "cure period", "notice of termination", "effect of termination", "survival", "wind down", "transition services".

**Pair with:** `payment-terms` (payment obligations surviving termination); `confidentiality` / `intellectual-property` (survival).

---

### `dispute-resolution`

Governing law, forum / venue, arbitration, mediation, jury waiver, injunctive relief, attorneys' fees.

**Triggers:** "governing law", "venue", "exclusive jurisdiction", "arbitration", "AAA", "JAMS", "ICC", "mediation", "jury waiver", "waiver of jury trial", "attorneys' fees", "prevailing party", "injunctive relief", "specific performance".

**Pair with:** nothing typically; dispute resolution is usually self-contained.

---

### `force-majeure`

Excuse from performance due to events beyond a party's reasonable control.

**Triggers:** "force majeure", "act of God", "excusable delay", "events beyond reasonable control", "pandemic", "epidemic", "government action", "war", "labor dispute", "strike".

**Pair with:** `termination` (extended force majeure as termination trigger).

---

### `confidentiality`

Non-disclosure obligations, permitted uses, return or destruction of confidential information, exceptions, duration.

**Triggers:** "confidential information", "non-disclosure", "proprietary information", "trade secret", "need-to-know", "return or destroy", "residual knowledge".

**Pair with:** `termination` (survival); `intellectual-property` (confidentiality as IP protection mechanism).

---

### `intellectual-property`

Ownership of pre-existing IP, ownership of work product, licenses granted, open-source restrictions, moral rights.

**Triggers:** "background IP", "foreground IP", "work product", "deliverables", "assign", "license", "perpetual, irrevocable", "open source", "copyleft", "moral rights", "patent", "trademark", "derivative work".

**Pair with:** `warranty` (IP infringement warranty); `indemnification` (IP infringement indemnity).

---

### `data-protection`

Processing of personal data or regulated data categories, DPA incorporation, cross-border transfer mechanisms, subprocessor terms, breach notification, data subject rights, security measures.

**Triggers:** "personal data", "personal information", "GDPR", "CCPA", "CPRA", "HIPAA", "processor", "controller", "subprocessor", "SCCs", "standard contractual clauses", "data breach", "security incident", "TOMs", "data subject request".

**Pair with:** `confidentiality`; `indemnification` (data-breach indemnity).

---

### `assignment`

Restrictions on or permissions for assigning the contract, assignment to affiliates, change of control.

**Triggers:** "assign", "assignment", "change of control", "successor", "delegate", "affiliate assignment".

**Pair with:** `termination` (change of control as termination trigger).

---

## Catch-all labels

### `industry-specific`

Any operative clause whose content is peculiar to the transaction type and does not fit a core label. When emitted, the `notes` field must name the industry convention invoked — for example:

- Construction — differing site conditions, ground conditions, staging area, site access
- Marine / maritime — Jones Act, protection-and-indemnity, salvage, general average, limitation-of-liability acts
- Healthcare — HIPAA business-associate addenda, Anti-Kickback, Stark law references
- Financial services — suitability, Reg Best Interest, customer complaint handling
- Construction labor / OCIP / CCIP — wrap-up insurance programs, borrowed-servant doctrines, workers' compensation waivers

Adopters who operate regularly in a single industry should split this into named labels in their own copy of `taxonomy.md` — for example, promoting `ground-conditions`, `employee-injury`, and `marine-specific` to first-class labels.

### `unclassified`

Operative legal language that does not plausibly fit any other label. `notes` must explain why. Never used to hide clauses the extractor could not be bothered to classify — used only when a clause is genuinely outside the taxonomy.

---

## Adaptation checklist

When adapting this taxonomy for an industry-specific practice:

- Decide which industry-specific patterns appear often enough to deserve their own label. Promote them out of `industry-specific`.
- Remove labels you will never see (for example, a pure SaaS practice may not need `force-majeure` triggers keyed to "weather" or "site access").
- Add trigger phrases peculiar to your counterparties' drafting conventions. Real-world contracts drift from textbook phrasing; your triggers should reflect that drift.
- Do not rename existing labels without updating every downstream consumer (redline assemblers, risk memos, reviewer agents) that expects the old labels.
