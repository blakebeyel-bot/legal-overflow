# Clause Extractor

A Claude skill that segments an ingested contract into labeled clauses keyed to a configurable clause taxonomy. The output is a strictly structured JSON array — one entry per (clause, label) pair — suitable for fan-out to downstream clause-specific reviewers, redline assemblers, or risk memo generators.

The extractor itself does not evaluate, redline, or score clauses. It is intentionally the most deterministic stage of a contract-review pipeline: its only job is to hand structured clauses to whatever workflow consumes them.

**License:** MIT.
**Version:** 1.0.0.

---

## Bundle contents

| File | Purpose |
|---|---|
| `SKILL.md` | The skill definition — taxonomy overview, extraction method, output shape. |
| `taxonomy.md` | Default clause taxonomy with triggers. Intended to be edited or replaced by adopters. |
| `output-schema.json` | JSON Schema (Draft 2020-12) defining the array the extractor returns. |
| `sample-run.md` | End-to-end example — fictional SaaS MSA excerpt → extracted JSON array. |
| `prompt-pack.md` | Paste-ready prompts for use without a skill-execution environment. |
| `README.md` | This file. |

---

## Install

### Option A — As a Claude skill (Claude Code, Cowork, Agent SDK)

Copy the whole folder into the host's skills directory. For example:

```
~/.claude/skills/clause-extractor/
```

Then invoke the skill from any workflow that needs clause segmentation. The host will pick it up by the `name: clause-extractor` field in `SKILL.md`'s YAML frontmatter.

### Option B — Hosted skill catalog

Upload the folder as a single skill entry. The host should read `SKILL.md` as the main definition and treat the remaining files as attachments reachable relative to `SKILL.md`.

### Option C — Prompt-only (no skill host)

Use the prompts in `prompt-pack.md`. Paste the extractor prompt into any general-purpose LLM, followed by the contract text. The model will return a JSON array conforming to `output-schema.json`. This is the fallback for environments that cannot execute skills.

---

## Customizing the taxonomy

The default `taxonomy.md` covers the categories present in almost every commercial agreement: indemnification, insurance, limitation-of-liability, payment-terms, warranty, termination, dispute-resolution, force-majeure, confidentiality, intellectual-property, data-protection, assignment. It also defines two catch-all buckets — `industry-specific` and `unclassified`.

Practitioners who operate regularly in one industry should promote their most common industry-specific patterns out of the catch-all and into named first-class labels. Examples:

- Construction — promote `ground-conditions`, `site-access`, `wrap-up-insurance`.
- Marine / maritime — promote `marine-specific`, `p-and-i`, `salvage`.
- Healthcare — promote `hipaa-business-associate`, `anti-kickback`.
- Financial services — promote `suitability`, `customer-complaint-handling`.

**Do not rename existing default labels** without updating every downstream consumer (reviewer agents, redline assemblers, risk memo generators) that expects the old labels. Additions are cheap; renames are expensive.

When extending the taxonomy, keep `taxonomy.md` in sync with `SKILL.md`'s label list. The extractor reads `taxonomy.md` at runtime; `SKILL.md`'s list exists for human readers.

---

## Integration with downstream reviewers

A typical pipeline looks like:

```
contract.docx
   │
   ▼
[clause-extractor]  ───►  array of (clause, label) entries
   │
   ▼
[fan-out to label-specific reviewer agents]
   │        e.g., indemnification-reviewer, lol-reviewer, data-protection-reviewer
   ▼
array of findings (deviation, severity, proposed redline, counter-language)
   │
   ▼
[redline-assembler]  ───►  tracked-changes redline .docx + risk memo .docx
```

The contract of the extractor is the array defined in `output-schema.json`. Downstream reviewers take one entry and return a finding; the assembler consolidates findings into deliverables. None of the stages need to know about the others beyond their schemas — that separation is what keeps the pipeline auditable.

---

## What this skill does NOT do

- It does not score, redline, or opine on clauses.
- It does not paraphrase, summarize, or normalize clause text.
- It does not resolve defined terms or descend into incorporated exhibits.
- It does not deduplicate overlapping multi-label entries. If the same clause hits three labels, you get three entries covering the same text, each cross-referencing the others.
- It does not validate the contract against any playbook. That is the job of downstream reviewers.

These limitations are design choices, not bugs. A narrow, deterministic extractor is easier to trust and easier to replace.

---

## Maintenance

- **Taxonomy drift.** Every six to twelve months, sample recent extractions for clauses that landed in `industry-specific` or `unclassified`. If the same pattern shows up repeatedly, promote it to a named label.
- **Trigger drift.** Counterparties' drafting conventions change. Periodically review the trigger cues in `taxonomy.md` against recent contracts and add phrases your counterparties actually use.
- **Schema evolution.** If `output-schema.json` changes, bump the `$id` version and notify downstream consumers. Do not silently add required fields.

---

## License

MIT License.

Copyright (c) 2026

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

---

## Disclaimer

This skill is a workflow aid. It identifies and labels clauses; it does not provide legal advice, does not create an attorney-client relationship, and does not substitute for attorney judgment. Any downstream review, negotiation, or execution decision should be made by qualified counsel who has independently verified the extraction and any authorities cited by downstream reviewers.
