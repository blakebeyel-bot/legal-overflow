---
name: clause-extractor
description: Segments an ingested contract into labeled clauses keyed to a configurable clause taxonomy. Use when a clause-by-clause contract review workflow needs to prepare clauses for fan-out to specialized reviewers, for redline assembly, or for downstream risk analysis. Returns a structured list — never prose.
version: 1.0.0
license: MIT
---

# Clause Extractor

Segment a contract into discrete clauses mapped to a clause taxonomy. The output is strictly structured data; the extractor itself does not evaluate, redline, or opine on any clause.

The default taxonomy covers the categories present in most commercial agreements. It is designed to be extended — industry-specific labels can be added or substituted without modifying the extractor's method. See `taxonomy.md` for the full label list and trigger cues.

---

## Taxonomy (exact labels — do not invent new ones at runtime)

**Core (applies to almost every commercial contract):**

- `indemnification`
- `insurance`
- `limitation-of-liability`
- `payment-terms`
- `warranty`
- `termination`
- `dispute-resolution`
- `force-majeure`
- `confidentiality`
- `intellectual-property`
- `data-protection`
- `assignment`

**Bucket for anything that does not fit a core label:**

- `industry-specific` — anything peculiar to the transaction type (for example, construction site-conditions, marine salvage, healthcare patient data, financial services suitability). When this label is emitted, the `notes` field must name the industry convention invoked.
- `unclassified` — used only when a clause contains operative legal language that does not plausibly fit any other label. Always accompanied by a short explanation in `notes`.

Adopters who operate in a specific industry will typically add named labels (for example, `ground-conditions`, `employee-injury`, `marine-specific`) in their own copy of `taxonomy.md`. Do not add labels mid-extraction.

See `taxonomy.md` for label triggers.

---

## Method

1. **Walk the contract top-to-bottom.** For each numbered section, heading, or distinct paragraph, determine whether it contains operative legal language. Skip recitals, definitions, and signature blocks — but if a definition is embedded inside an operative clause, keep it with its clause.
2. **Classify each operative section into one or more taxonomy labels.** Multi-label is expected. A single indemnity clause that also caps damages must emit BOTH an `indemnification` entry AND a `limitation-of-liability` entry covering the same text, each with a cross-reference note pointing at the other. Do not split the text differently for each label — both entries quote the same span.
3. **Copy clause text verbatim.** Do not paraphrase, summarize, or normalize capitalization. Preserve numbering, enumerations, and internal cross-references. If the clause contains a defined term whose definition lives elsewhere, do not inline the definition; keep the reference as-is.
4. **Unclassified bucket.** If a clause contains operative legal language that does not match any label, emit it under `unclassified` and explain why in `notes`. Never discard an operative clause.
5. **Boilerplate gray zone.** Severability, entire-agreement, counterparts, notices, waiver, amendment, and similar housekeeping clauses should be labeled when they bear on risk (e.g., a notice provision with a short cure period) and labeled `unclassified` otherwise. Do not emit an entry for a pure counterparts-and-electronic-signatures clause unless an adopter's taxonomy requires it.

---

## Output Format

Return a JSON array. One entry per (clause, label) pair. The schema is defined formally in `output-schema.json`.

```json
[
  {
    "clause_id": "c_001",
    "clause_category": "indemnification",
    "section_ref": "Section 8.1",
    "text": "<verbatim clause text>",
    "notes": "Also caps liability — see clause_id c_002 (limitation-of-liability) covering same span"
  },
  {
    "clause_id": "c_002",
    "clause_category": "limitation-of-liability",
    "section_ref": "Section 8.1",
    "text": "<verbatim clause text — same span as c_001>",
    "notes": "Paired with c_001 (indemnification) — same clause span, different label"
  }
]
```

Return nothing else. No prose, no commentary, no summary, no markdown outside the JSON, no "Here is the extraction:" preface. Downstream agents parse the first `[` to the matching `]` and will break on any extra text.

---

## Inputs

- `contract_path` *(required)* — path to the contract file. Supported formats depend on the host: plain text and `.docx` work without additional tooling; `.pdf` requires a text-extraction step before invocation.
- `taxonomy_path` *(optional)* — path to an adopter-specific `taxonomy.md`. Defaults to the file shipped with this skill.

---

## Returns

A JSON array conforming to `output-schema.json`. One element per (clause, label) pair. Adopters who need additional fields (for example, a page reference or a hash of the clause text) should extend `output-schema.json` in their copy rather than mutating the extractor's output shape at runtime.

---

## What this skill does NOT do

- It does not score, redline, or flag clauses. Deviation analysis is the job of downstream clause-specific reviewers.
- It does not rewrite or reformat clause text.
- It does not resolve defined terms.
- It does not deduplicate overlapping clauses — if the same span matches two labels, it emits two entries, each pointing at the other.
- It does not read signature blocks, exhibits, or schedules unless those exhibits contain operative legal language (in which case extract them and note the location in `section_ref`, e.g., `"Schedule A, § 2"`).

---

## License

MIT. See `README.md`.
