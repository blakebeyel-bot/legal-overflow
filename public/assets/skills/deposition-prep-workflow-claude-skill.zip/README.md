# Deposition Prep in One Afternoon

A Claude Skill for litigators. Takes a witness's transcript corpus and produced exhibits and turns them into a cross-examination outline in under four hours. Built for the case where the depo is tomorrow morning and the senior lawyer has been in trial for two weeks.

Output is a Microsoft Word `.docx` cross-exam outline plus a structured `outline.json` artifact. Both follow `outline-schema.json` in this folder.

Licensed MIT. This is a tool for licensed attorneys working a real matter. It does not replace your judgment, your privilege review, or your case theory.

## What's in the bundle

- `SKILL.md` — the skill definition and instructions Claude follows
- `transcript-schema.json` — JSON schema for the cleaned transcript and exhibit corpus (Stage 1 output)
- `outline-schema.json` — JSON schema for the final cross-exam outline (Stage 4 output)
- `sample-run.md` — fictional but realistic end-to-end run (CFO of a public company, securities-class-action context)
- `README.md` — this file

## Installation

### Option 1 — Claude Code (local)

1. Drop the `deposition-prep-in-one-afternoon/` folder into `~/.claude/skills/` (user-level) or `.claude/skills/` at the root of your matter folder (project-level).
2. Make sure the `docx` skill is also installed — the outline is rendered through it.
3. Restart Claude Code. Confirm the skill appears via `/skills`.
4. Trigger by asking Claude to "prep me for the Hsu depo," "build a cross-exam outline for [witness]," or similar.

### Option 2 — Hosted Claude Skills interface

1. Zip the folder so `SKILL.md` sits at the root of the archive.
2. Upload via your Claude product's Skills interface and enable for the workspace.

### Option 3 — Manual prompt

If you are not running the skill infrastructure, paste the body of `SKILL.md` (everything below the YAML frontmatter) into a system prompt, attach (or paste) the transcript and exhibit corpus, and run.

## Privilege and protective-order safety — read before using

The skill instructs Claude to refuse to process anything in three categories: (1) privileged material, (2) work product, (3) AEO documents whose protective order does not permit AI processing. **The skill is only as careful as the corpus you hand it.** Before you point this at a matter:

- **Run the corpus through your privilege filters first.** Do not assume the model will catch a stray attorney-client email. It will catch obvious ones; subtle ones it may not.
- **Read the protective order.** The "permitted recipients" or "permitted purposes" clauses control. If the order requires that vendors execute Exhibit A acknowledgments, ensure your firm has an acknowledgment on file with your Claude vendor before processing any designated material.
- **Maintain a local privilege log.** Keep a list of what you withheld from the model and why. This is your audit trail if a privilege dispute arises later.
- **Watch for clawback.** If the producing party invokes FRE 502(d) clawback after you have processed a document, you have an affirmative duty to remove it from your working set and notify them. The skill flags clawback-status documents for human review at Stage 1 — but you have to feed it the clawback notices.
- **PHI/PII.** If your corpus contains personal health information, financial-account numbers, SSNs, or biometric data, confirm your Claude deployment is covered by the appropriate BAA / DPA before processing. If not covered, redact before sending.
- **Sealed materials.** Court-sealed documents do not go to a hosted model unless your protective order specifically permits it.

If any of the above is unclear, do not run the skill. Resolve it with the partner first.

## Verifying it works

Use the sample run in `sample-run.md` as your benchmark. Feed Claude (a) a fictional witness with at least three sworn prior statements, (b) at least 25 exhibits including documents with version lineage, (c) at least one prior inconsistent statement under oath, and ask for a Tier 1 deposition prep. The output should:

- Produce a `transcript-corpus.json` conforming to `transcript-schema.json`.
- Produce a 60+ entry timeline with each entry citing Bates or transcript pin.
- Identify at least 5 impeachment items rated HIGH or MEDIUM.
- Produce a Word outline in three sections: Background, Timeline, Impeachment, with a Top 5 Goals list at the top and a 25+ row exhibits index at the end.
- Each impeachment block must have the four-step structure: commit → identify exhibit → confront verbatim → close.

If any of those four are missing, the skill failed for that run. Most often the cause is that Stage 3 was rushed; tighten the impeachment finder instructions.

## Limits

- This is a Tier 1 prep workflow. It does not replace witness-prep sessions with the lead lawyer, mock cross, or a strategy meeting on theory of the case.
- The "in one afternoon" framing assumes the corpus is already produced and Bates-stamped. Pre-production work (custodian interviews, search-term negotiation, processing) is out of scope.
- The skill reads what you give it. If you have not produced or collected the document that contradicts the witness, the skill will not impeach the witness with it.
- The skill does not predict objections from opposing counsel beyond the most common ones (form, foundation, calls for legal conclusion). Sophisticated objection strategy still requires a human.

## License

MIT. See header of `SKILL.md`.
