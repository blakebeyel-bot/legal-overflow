# Sample Run — *In re Meridian Robotics Corp. Securities Litigation*

**Witness:** Renata Hsu, CFO, Meridian Robotics Corp.
**Deposition date:** (scheduled, 10:00 a.m.)
**Case:** *In re Meridian Robotics Corp. Securities Litigation*, No. 24-cv-01847 (N.D. Cal.)
**Matter number:** 10482-007
**Examiner:** Lead plaintiff's counsel
**Prep time elapsed:** 3 hr 42 min

This sample is a fictional but realistic end-to-end run of the skill. Facts, names, and Bates numbers are invented. The workflow, structure, and output format are the real thing.

---

## Stage 1 — Transcript ingestion and cleanup

**Corpus ingested:**

- T-001: Deposition of Hsu, *Sidorov v. Meridian Robotics Corp.*, derivative action (M.D. Fla. 2022), 312 pages, certified.
- T-002: Congressional testimony of Hsu, House Financial Services Subcommittee on Capital Markets, Sept. 14, 2021, 46 pages.
- T-003: Hsu declaration (Aug. 2024) filed in opposition to preliminary injunction motion in this case, 11 paragraphs, 6 pages.
- T-004: Interrogatory responses verified by Hsu (First Set of Interrogatories, Aug. 30, 2024), 14 responses.

**Exhibits ingested:** 41 exhibits, Bates range MERIDIAN-00001247 through MERIDIAN-00148910, pulled from the document production database and cross-checked against the priv log.

**Quarantined:**

- 2 items held back pending confirmation of clawback status (FRE 502(d)) — emails dated Apr. 14 and Apr. 16, 2024 between Hsu and outside SEC counsel. Partner to resolve before final outline review.
- 1 item held back as marked AEO; protective order (ECF 47, ¶8(c)) permits processing by retained litigation-support vendors meeting the order's confidentiality requirements. Vendor attestation on file. Cleared for inclusion.

**Corpus stats:**

- Total transcripts: 4
- Total transcript pages: 375
- Total exhibits: 41 (2 quarantined, 39 active)
- Ingestion timestamp: (T minus 3 hr 40 min before dep)

---

## Stage 2 — Witness timeline (excerpt; full timeline is 78 entries)

| Date | Event | Source | Role |
|------|-------|--------|------|
| 2023-01-10 | Hsu hired as CFO; PSU grant tied to 3-yr total revenue target | Ex. 2 (offer letter, MERIDIAN-00001247) | Signatory |
| 2024-01-22 | Q4'23 earnings call; Hsu reaffirms Q2'24 revenue guidance of "approximately $82 million" | Ex. 4 (transcript, MERIDIAN-00003102) | Speaker |
| 2024-02-15 | Internal forecast meeting; Controller Kolev flags CPS-4 distributor shipments as "pull-in from Q3" | Ex. 7 (notes of J. Ngo, Dep. Treasurer; MERIDIAN-00008411) | Attendee |
| 2024-03-12 | Arcadia Distribution (largest CPS-4 channel) requests 60-day payment extension | Ex. 11 (email, MERIDIAN-00011002) | Recipient |
| **2024-03-28** | **Board meeting; Hsu presents Q2'24 deck v4 reaffirming $82M guidance** | **Ex. 22 (board deck v4, MERIDIAN-00018247)** | **Author / presenter** |
| 2024-04-04 | Ernst Young quarterly review letter flags "Arcadia channel concentration risk" | Ex. 13 (EY letter, MERIDIAN-00022801) | Recipient |
| 2024-04-09 | Email from Kolev to Hsu: "we have a real problem on CPS-4; distributor can't take delivery" | Ex. 14 (email chain, MERIDIAN-00023991, page .995) | Recipient |
| 2024-04-10 | Email from Hsu to Kolev and Nguyen (Dep. CFO): "let's discuss tomorrow AM before I see [CEO]" | Ex. 14 (same chain, page .993) | Author |
| **2024-04-11** | **Email from Hsu to Kolev, Nguyen: "we'll need to cycle back on the CPS-4 number; I don't see how we hit the deck"** | **Ex. 14 (same chain, page .991)** | **Author** |
| 2024-04-18 | Audit committee meeting; no disclosure of CPS-4 issue in written materials | Ex. 28 (minutes, MERIDIAN-00031414) | Attendee |
| 2024-04-25 | Q1'24 earnings release; Q2 guidance reaffirmed in prepared remarks | Ex. 31 (release, MERIDIAN-00038012) | Signatory of 10-Q cert |
| 2024-05-08 | Restatement announcement; Q2 guidance withdrawn | Ex. 39 (8-K, MERIDIAN-00101502) | Signatory |
| 2024-05-08 | Stock down 41% on 6x avg volume | Ex. 40 (trading data, MERIDIAN-00148901) | — |

**Flagged for impeachment build-out (Stage 3):** Mar 28 ↔ Apr 11 contradiction; Mar 28 deck v3 (Ex. 22a, $79M) ↔ v4 ($82M); Apr 25 10-Q cert (FRE 801(d)(2), Sarbanes-Oxley cert) post-dates Apr 11 internal admission; prior deposition answer at T-001 82:14 (Sidorov deposition) re: "forecast discipline" is arguably inconsistent.

---

## Stage 3 — Impeachment material (9 items, HIGH/MEDIUM only)

**IMP-1 (HIGH) — Mar 28 board representation vs. Apr 11 internal email**
- Expected position: "I believed the $82M guidance was achievable when I presented it to the board."
- Contradiction: Ex. 14, Apr 11 email: "we'll need to cycle back on the CPS-4 number; I don't see how we hit the deck" (Hsu to Kolev, Nguyen), MERIDIAN-00023991.991.
- Basis: FRE 801(d)(2)(A) — party admission; foundation via witness as author.
- If witness wiggles: "The Apr 11 email reflects a momentary concern that turned out to be wrong." → Close: Walk to Ex. 28 (Apr 18 audit committee minutes) — no such correction disclosed to the audit committee; walk to Ex. 31 (Apr 25 earnings release) — guidance still reaffirmed.

**IMP-2 (HIGH) — Board deck versions v3 ($79M) → v4 ($82M)**
- Expected position: "The deck numbers were the output of the standard forecasting process."
- Contradiction: Ex. 22a (v3, MERIDIAN-00018022, slide 7 shows $79M) vs. Ex. 22 (v4, MERIDIAN-00018247, slide 7 shows $82M). Redline metadata and Hsu's email (Ex. 21, MERIDIAN-00017912) show she returned the deck to the FP&A team with tracked changes raising the number after the FP&A team had set it at $79M.
- Basis: FRE 801(d)(2)(A); authentication via Ex. 21 directing the change.
- If witness wiggles: "$79M was a preliminary working number; $82M was the finalized view." → Close: Ex. 14 internal emails dated AFTER the finalization show the team, including Hsu, did not believe $82M was achievable. Prior number was not "preliminary"; it was the last good-faith estimate before Hsu intervened.

**IMP-3 (HIGH) — Congressional testimony on forecast discipline**
- Expected position: (evasion on whether Hsu had authority to revise revenue forecasts unilaterally).
- Contradiction: T-002 (congressional testimony, Sept 14, 2021) at 38:04: "In our process, the CFO does not override the FP&A output without a documented basis memorialized in the forecasting memo."
- Basis: FRE 613 prior inconsistent statement + FRE 801(d)(1)(A) (prior inconsistent under oath).
- If witness wiggles: "That was a different company policy at the time." → Close: Ex. 22 metadata shows no forecasting memo documenting the v3→v4 change; interrogatory response (T-004, Response 8) confirms no such memo exists.

**IMP-4 (HIGH) — Prior deposition Q re: channel concentration disclosure**
- Expected position: "We disclosed the Arcadia concentration risk in our quarterly reports."
- Contradiction: T-001 (Sidorov deposition, 2022) at 214:17: "Concentration thresholds of 10% of revenue or greater trigger quarterly disclosure review." Arcadia was 17% of CPS-4 revenue in Q1'24 (Ex. 16, MERIDIAN-00025812); no disclosure appears in Q1'24 10-Q (Ex. 31).
- Basis: FRE 613 + FRE 801(d)(1)(A).
- If witness wiggles: "I don't recall the exact threshold." → Close: Walk to T-001 214:17 verbatim; refresh recollection if needed.

**IMP-5 (MEDIUM) — Comp tied to revenue**
- Expected position: "My compensation was not tied to any specific quarterly revenue number."
- Contradiction: Ex. 2 (offer letter), Ex. 3 (2023 PSU award agreement) — vesting hurdles include a "three-year cumulative revenue" target. A Q2'24 miss materially reduces expected vesting.
- Basis: FRE 608(b) / bias (not for truth of the matter but to show motive).
- If witness wiggles: "Three-year cumulative, not quarterly — so one quarter is small in the mix." → Close: Ex. 5 (comp committee deliberations, MERIDIAN-00007011) shows quarterly milestones drive accrual probability.

**IMP-6 (MEDIUM) — Prior declaration statement re: forecast process**
- Expected position: (reaffirm declaration).
- Contradiction: T-003, ¶6: "At all times, my forecasts were prepared in consultation with, and with the concurrence of, our Controller and Deputy CFO." Ex. 14 shows Kolev and Nguyen actively dissenting on Apr 9–11.
- Basis: FRE 801(d)(1)(A) (declaration is under oath).

**IMP-7 (MEDIUM) — EY letter flag**
- Expected position: "We responded promptly to EY's Arcadia concentration flag."
- Contradiction: Ex. 13 (Apr 4 EY letter) asks for written response within 10 business days; Ex. 15 (Apr 22 Hsu response) comes 14 business days later and does not address Arcadia concentration.
- Basis: FRE 803(6) (EY letter as business record) + FRE 801(d)(2).

**IMP-8 (MEDIUM) — 10-Q certification post-date**
- Expected position: "I believed in good faith the April 25 10-Q representations were accurate."
- Contradiction: Ex. 14 (Apr 11 email) predates the cert.
- Basis: FRE 801(d)(2)(A), SOX §302 cert.

**IMP-9 (MEDIUM) — Audit committee disclosure**
- Expected position: "I kept the audit committee informed of material risks."
- Contradiction: Ex. 28 (Apr 18 audit committee minutes) contains no reference to the CPS-4/Arcadia issue despite Ex. 14 on Apr 11.
- Basis: Adoptive admission; silence where a duty to disclose existed.

---

## Stage 4 — Cross-exam outline (structure and excerpts)

**Witness:** Renata Hsu, CFO, Meridian Robotics Corp.
**Case:** *In re Meridian Robotics Corp. Securities Litigation*, No. 24-cv-01847 (N.D. Cal.)
**Examiner:** [Lead plaintiff's counsel]
**Estimated total time:** 5 hr 45 min (of 7-hr statutory cap)

**Top 5 Goals:**

1. Lock in that Hsu personally raised the Q2 revenue forecast from $79M (v3) to $82M (v4) before the March 28 board presentation (Ex. 22, Ex. 22a, Ex. 21).
2. Lock in that by April 11, Hsu had written, in her own words, that the $82M number was unachievable (Ex. 14).
3. Lock in that the April 18 audit committee meeting contained no disclosure of the CPS-4 issue, despite the April 11 email (Ex. 28).
4. Lock in that Hsu signed the SOX §302 certification for the April 25 10-Q, which reaffirmed guidance, after the April 11 email (Ex. 31).
5. Lock in that Hsu's comp is materially tied to the three-year cumulative revenue target disclosed to the board at the same Mar 28 meeting (Ex. 2, Ex. 3, Ex. 5).

**Ground-rules reminder:** This witness was designated as 30(b)(6) on Topics 3, 7, 9–12 in the Rule 30(b)(6) notice (ECF 62). Any testimony on those topics binds the company. Keep topic transitions clean so the record is clear when she is speaking personally vs. as 30(b)(6).

---

### I. Background — 12 questions (est. 30 min)

I.1 — You are the Chief Financial Officer of Meridian Robotics Corporation. Correct?
I.2 — You have held that position since January 2023.
I.3 — Before Meridian, you served as CFO of Volta Capital from 2019 to 2022. Correct?
I.4 — You report directly to the CEO, Ms. Alana Park.
I.5 — You also report on a dotted-line basis to the Chair of the Audit Committee.
I.6 — Your compensation includes a base salary, a cash bonus, and equity grants. Correct?
I.7 — Among your equity grants are Performance Stock Units — PSUs. Correct?
*Exhibit:* Ex. 2 (offer letter) — purpose: *lock_in_admission*. Pin cite: MERIDIAN-00001247.
I.8 — The PSUs have a vesting formula tied to Meridian's three-year cumulative revenue. Correct?
*Exhibit:* Ex. 3 (PSU award agreement) — pin cite: MERIDIAN-00001812, §3(b).
I.9 — Falling short of the cumulative revenue target would materially reduce the value of your PSU vesting. True?
I.10 — At Meridian, the finance organization maintains written forecasting memos for each quarter. Correct?
I.11 — Those memos are archived under the company's document-retention policy. Correct?
I.12 — As CFO, you are one of the certifying officers under Section 302 of the Sarbanes-Oxley Act for Meridian's quarterly and annual SEC filings. Correct?

[Remaining background questions cover the FP&A reporting structure, the identity of the Controller and Deputy CFO, and the forecasting cadence.]

---

### II. Timeline — 34 questions (est. 3 hr 10 min)

[Each timeline event from Stage 2 is a 2–4 question block: mark the date, mark the exhibit, establish what she knew when she knew it, and lock in a single sentence about what she did. Below is a representative block.]

II.9 — On February 15, 2024, you attended an internal forecast meeting. Correct?
*Exhibit:* Ex. 7 (J. Ngo notes), MERIDIAN-00008411 — purpose: *refresh_recollection*.
II.10 — At that meeting, your Controller, Mr. Kolev, raised a concern about CPS-4 distributor shipments. Yes?
II.11 — Specifically, Mr. Kolev said the shipments were — and I'm reading from Ex. 7 — "pull-in from Q3." Correct?
II.12 — "Pull-in from Q3" means recognizing revenue in Q2 that would more naturally have fallen in Q3. Correct?

[…]

II.22 — On March 28, 2024, you presented a board deck to the Meridian Board of Directors. Correct?
*Exhibit:* Ex. 22 (board deck v4), MERIDIAN-00018247 — purpose: *mark_and_identify*.
II.23 — That deck reaffirmed the company's Q2 2024 revenue guidance of approximately $82 million. Correct?
*Exhibit:* Ex. 22, slide 7 — purpose: *lock_in_admission*. Pin cite: MERIDIAN-00018253.
II.24 — The deck did not disclose Mr. Kolev's February 15 concern about CPS-4 pull-in. True?
II.25 — The deck did not disclose Arcadia Distribution's March 12 request for a 60-day payment extension. True?
*Exhibit:* Ex. 11 (Arcadia request).
[⚠ anticipated objection: form / calls for speculation on what "the deck disclosed"; response: reading the document for its content.]

[…]

II.29 — On April 9, 2024, Mr. Kolev sent you an email that read, in part, "we have a real problem on CPS-4; distributor can't take delivery." Correct?
*Exhibit:* Ex. 14 (email chain) — pin cite: MERIDIAN-00023991.995.
II.30 — On April 10, you replied to Mr. Kolev and Mr. Nguyen saying, "let's discuss tomorrow AM before I see [CEO]." Correct?
*Exhibit:* Ex. 14, page .993.
II.31 — On April 11, at 8:42 a.m. Pacific, you sent an email to Mr. Kolev and Mr. Nguyen that read, "we'll need to cycle back on the CPS-4 number; I don't see how we hit the deck." Correct?
*Exhibit:* Ex. 14, page .991.
II.32 — By "the deck," you were referring to the board deck you had presented on March 28. True?
II.33 — By "cycle back on the CPS-4 number," you were referring to the Q2 revenue guidance contribution from CPS-4. Correct?
II.34 — As of April 11, you no longer believed $82 million in Q2 revenue was achievable. True?
[⚠ impeachment-loaded; if denied, pivot to Section III.]

---

### III. Impeachment — 9 questions (est. 45 min)

Two main impeachment blocks, then targeted confronts on IMP-3 through IMP-9 in priority order.

**Block A — The April 11 email (IMP-1, IMP-8, IMP-9)**

III.1 — You would agree that you have a duty, as CFO, not to make materially misleading statements to the investing public. Correct?
III.2 — You signed the Sarbanes-Oxley Section 302 certification for Meridian's first-quarter Form 10-Q filed on April 25, 2024. Correct?
*Exhibit:* Ex. 31 (10-Q and cert) — pin cite: MERIDIAN-00038012, cert page 47.
III.3 — That 10-Q reaffirmed the Q2 2024 revenue guidance of approximately $82 million. Correct?
III.4 — As of April 25, 2024, you had already written the April 11 email we just looked at. Correct?
*Exhibit:* Ex. 14 (recall).

**Block B — Board deck v3 → v4 (IMP-2)**

III.5 — There was a prior version of the March 28 board deck. Correct?
*Exhibit:* Ex. 22a (deck v3) — pin cite: MERIDIAN-00018022, slide 7.
III.6 — Version 3 of slide 7 showed a Q2 2024 revenue forecast of $79 million. Correct?
III.7 — You sent the deck back to the FP&A team with instructions to revise that number. Correct?
*Exhibit:* Ex. 21 (Hsu email with tracked changes) — pin cite: MERIDIAN-00017912.
III.8 — In Version 4 — the version you presented to the board — slide 7 showed $82 million. Correct?
*Exhibit:* Ex. 22 (recall).
III.9 — There is no forecasting memo documenting the basis for the change from $79 million to $82 million. Correct?
*Transcript cite:* T-004 (interrogatory response), Response 8.

[Remaining impeachment targets IMP-3 through IMP-9 are sequenced as single-question confronts; full text omitted for this sample.]

---

## Exhibits index — 41 exhibits

| Ex. | Bates | Date | Description |
|-----|-------|------|-------------|
| 1 | MERIDIAN-00001100 | 2023-01-05 | Meridian Corp. organizational chart (CFO org) |
| 2 | MERIDIAN-00001247 | 2023-01-10 | R. Hsu offer letter (incl. PSU terms) |
| 3 | MERIDIAN-00001812 | 2023-01-15 | 2023 PSU award agreement — R. Hsu |
| 4 | MERIDIAN-00003102 | 2024-01-22 | Q4'23 earnings call transcript |
| 5 | MERIDIAN-00007011 | 2023-11-12 | Compensation committee deliberations — PSU accrual methodology |
| 6 | MERIDIAN-00008200 | 2024-02-08 | FP&A Q2'24 forecast memo (v1) |
| 7 | MERIDIAN-00008411 | 2024-02-15 | Notes of J. Ngo, Dep. Treasurer — forecast meeting |
| 8 | MERIDIAN-00008998 | 2024-02-19 | Internal email — Hsu to Park re: Q2 forecast |
| 9 | MERIDIAN-00009501 | 2024-02-22 | CPS-4 weekly shipment dashboard |
| 10 | MERIDIAN-00010447 | 2024-03-05 | Arcadia Distribution MSA amendment |
| 11 | MERIDIAN-00011002 | 2024-03-12 | Email — Arcadia requests 60-day payment extension |
| 12 | MERIDIAN-00012004 | 2024-03-18 | Board meeting pre-read materials |
| 13 | MERIDIAN-00022801 | 2024-04-04 | EY quarterly review letter — channel concentration |
| 14 | MERIDIAN-00023985 – 00023995 | 2024-04-09 to 04-11 | Email chain — Kolev / Hsu / Nguyen re: CPS-4 |
| 15 | MERIDIAN-00024712 | 2024-04-22 | Hsu response to EY letter |
| 16 | MERIDIAN-00025812 | 2024-04-01 | Arcadia revenue concentration analysis |
| 17 | MERIDIAN-00026110 | 2024-04-03 | FP&A revised CPS-4 model (internal) |
| 18 | MERIDIAN-00017200 | 2024-03-20 | Board deck v1 |
| 19 | MERIDIAN-00017450 | 2024-03-22 | Board deck v2 |
| 20 | MERIDIAN-00017800 | 2024-03-25 | FP&A markup of deck draft |
| 21 | MERIDIAN-00017912 | 2024-03-26 | Email — Hsu returns deck with tracked changes |
| 22 | MERIDIAN-00018247 | 2024-03-28 | Board deck v4 (as presented) |
| 22a | MERIDIAN-00018022 | 2024-03-27 | Board deck v3 |
| 23 | MERIDIAN-00019001 | 2024-03-28 | Board minutes (Mar 28 meeting) |
| 24 | MERIDIAN-00019414 | 2024-04-01 | Q1'24 close calendar |
| 25 | MERIDIAN-00028012 | 2024-04-05 | SOX §302 sub-certifications from finance team |
| 26 | MERIDIAN-00029501 | 2024-04-12 | Kolev email to Hsu — proposed CPS-4 reserve |
| 27 | MERIDIAN-00030022 | 2024-04-15 | Audit committee pre-read materials |
| 28 | MERIDIAN-00031414 | 2024-04-18 | Audit committee minutes |
| 29 | MERIDIAN-00033001 | 2024-04-20 | Draft Q1'24 earnings release |
| 30 | MERIDIAN-00036812 | 2024-04-23 | Disclosure committee meeting minutes |
| 31 | MERIDIAN-00038012 | 2024-04-25 | Q1'24 Form 10-Q (as filed) and SOX cert |
| 32 | MERIDIAN-00041010 | 2024-04-25 | Q1'24 earnings call transcript |
| 33 | MERIDIAN-00048001 | 2024-05-01 | Internal CPS-4 reserve analysis (updated) |
| 34 | MERIDIAN-00051244 | 2024-05-03 | Email — Park to Hsu re: preliminary restatement options |
| 35 | MERIDIAN-00062910 | 2024-05-06 | Draft 8-K restatement language (v1) |
| 36 | MERIDIAN-00072001 | 2024-05-07 | Draft 8-K restatement language (v2) |
| 37 | MERIDIAN-00084517 | 2024-05-07 | Audit committee resolution authorizing restatement |
| 38 | MERIDIAN-00095001 | 2024-05-08 | Final 8-K restatement language (as filed, pre-press) |
| 39 | MERIDIAN-00101502 | 2024-05-08 | Form 8-K announcing restatement |
| 40 | MERIDIAN-00148901 | 2024-05-08 | Trading data — May 8 session |
| 41 | MERIDIAN-00148910 | 2024-05-09 | Internal post-announcement talking points |

---

## Open issues for lead counsel (before the depo starts)

1. **Clawback-claimed emails (Apr 14 and Apr 16, 2024 between Hsu and outside SEC counsel).** Need go/no-go from partner on whether to use in examination, consistent with FRE 502(d) order and good-faith obligations.
2. **30(b)(6) scope.** Topics 3, 7, 9–12 bind the company. Confirm whether lead counsel wants to elicit corporate testimony on Topic 11 (reserves methodology) from this witness or wait for a different designee.
3. **Confidentiality designations at the deposition.** Ex. 22a (board deck v3) is designated "Highly Confidential — Attorneys' Eyes Only." Confirm the court reporter and videographer have acknowledgments on file per PO ¶8(d).
4. **Errata practice.** N.D. Cal. practice under L.R. 30-2 permits substantive errata. Prepare for the possibility that the witness amends Apr 11 testimony on errata; preserve the record accordingly.
