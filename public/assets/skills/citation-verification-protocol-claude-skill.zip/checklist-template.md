<!--
PRINTABLE ONE-PAGE CHECKLIST (front + back)
Front: Stage-by-stage checklist completed during the Bluebook form-check.
Back:  Drafting sign-off executed at the close of the form-check.

Print duplex. Complete in ink. File in the matter file with the final draft.
-->

# CITATION FORM-CHECK CHECKLIST
### Bluebook 22nd Edition

**Protocol:** Citation Verification Protocol v1.1.0 · MIT-licensed · Reviewed annually
**Authority:** *The Bluebook: A Uniform System of Citation* (22nd ed. 2025)
**Style selected:** ☐ Bluepages (practitioner) ☐ White-pages (scholarly)
**Local rule override (if any):** ______________________________ *(BT2 / local court rule number)*

**Matter:** _________________________________________________
**Caption / docket:** ______________________________________
**Court & filing deadline:** ______________________________
**Draft file name + version:** ____________________________
**Draft date + hash (optional):** _________________________
**Drafting attorney:** ____________________________________
**Verifying attorney:** ___________________________________
**Date form-check commenced:** ____________________________

---

## FRONT — Stage-by-stage checklist

### Stage 1 — Extraction

- [ ] Every instance of citable authority extracted (cases, statutes, regs, rules, secondary, court documents, legislative history)
- [ ] No deduplication — each pin-cite location has its own row
- [ ] Extraction table total count confirmed: **___** citations
- [ ] Style determination confirmed at intake (Bluepages vs. white-pages)
- [ ] Local court rule (BT2) consulted and any override recorded
- [ ] Sealed / PO-designated material confirmed permissible for model processing

### Stage 2 — Rule mapping

- [ ] Governing Bluebook rule identified for every citation (BP or R., by number)
- [ ] Relevant tables noted (T1, T6, T7, T8, T10, T12, T13, T14, T16, BT2)
- [ ] Local-rule override applied where BT2 or local court rule departs from 22e

### Stage 3 — Form verification (applicable tests per citation type)

For each citation, verifying attorney initials each test that passes:

| # | Components | Abbrev. | Reporter | Court/Yr | Pin | Short/*id.* | Signal | Parenth. | Quote | History | Parallel | Caps |
|---|------------|---------|----------|----------|-----|-------------|--------|----------|-------|---------|----------|------|
| 1 |            |         |          |          |     |             |        |          |       |         |          |      |
| 2 |            |         |          |          |     |             |        |          |       |         |          |      |
| 3 |            |         |          |          |     |             |        |          |       |         |          |      |
| _(continues for all citations — mark N/A for tests that do not apply)_ |

- [ ] Every citation tiered ✓ / ▲ / ✗
- [ ] Every ▲ corrected in the draft and re-verified
- [ ] Every ✗ re-sourced, rewritten, or removed, and the replacement run through Stages 1-3
- [ ] Quotations flagged for attorney source review reconciled

### Stage 4 — Report

- [ ] Verification report (`.docx`) generated and filed in the matter file
- [ ] Initial tier counts: ✓ **___**   ▲ **___**   ✗ **___**
- [ ] Post-correction tier counts: ✓ **___**   ▲ 0   ✗ 0

### Stage 5 — Sign-off

- [ ] Back-side sign-off completed
- [ ] Filed in matter file
- [ ] Bluebook edition and skill run log retained

---

## BACK — Drafting sign-off

### DRAFTING SIGN-OFF — BLUEBOOK FORM-CHECK

Matter: ___________________________________________________

Caption: _________________________________________________

Docket number: ___________________________________________

Court: ___________________________________________________

Document being filed: ____________________________________

Filing date: _____________________________________________

**The undersigned confirms that the form of the citations in the above-identified document has been verified against the Twenty-Second Edition of *The Bluebook: A Uniform System of Citation*, and specifically:**

1. Every citation in the document was extracted and identified.
2. Each citation was mapped to the governing Bluepages or white-pages rule and any applicable tables.
3. Each citation was evaluated against the tests in Stage 3 of the protocol that apply to its citation type: required components (e.g., R. 10.1 for cases; R. 12.3 for statutes; R. 15 for books; R. 16 for periodicals); abbreviations (R. 10.2 / T6, R. 10.4 / T7, T10, T12, T13, T14, T16); reporter series and pagination (R. 10.3; T1.1; T1.3); court and year (R. 10.4, R. 10.5); pin-cite form (R. 3; R. 3.2); short-form and *id.* (R. 4; R. 10.9); introductory signals and ordering (R. 1.2, R. 1.3, R. 1.4); parentheticals (R. 1.5; R. 10.6); quotations (R. 5); prior and subsequent history (R. 10.7; T8); parallel citation (R. 10.3.1; BT2); capitalization (R. 8; BP8).
4. Local citation rules of the filing court were consulted (BT2) and applied where they depart from Bluebook 22e.
5. Every citation flagged ▲ NEEDS CORRECTION has been corrected in the draft and the corrected citation has been re-run through Stages 1-3.
6. Every citation flagged ✗ NON-CONFORMING has been re-sourced, rewritten, or removed, and any replacement has been re-run through Stages 1-3.
7. Quotations have been compared against source text, or flagged for attorney source review and reconciled before signature.
8. The tool-assistance log (if any AI tool was used in drafting) has been completed and retained in the matter file.

**Style applied:** ☐ Bluepages (practitioner) ☐ White-pages (scholarly)

**Tier results at close:**   ✓ _____   ▲ 0   ✗ 0

**Drafting / supervising attorney:**

Name (print): ____________________________________________

Bar number / jurisdiction: ________________________________

Signature: _______________________________________________

Date: ____________________________________________________

**Verifying attorney** (if different from drafting):

Name (print): ____________________________________________

Signature: _______________________________________________

Date: ____________________________________________________

---

*Retain in the matter file. This sign-off records form-checking only; it does not attest to the substantive accuracy of any authority cited in the filing.*

*Protocol version 1.1.0 · MIT-licensed · Reviewed annually or upon issuance of a new Bluebook edition.*
