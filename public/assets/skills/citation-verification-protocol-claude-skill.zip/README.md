# Citation Verification Protocol

A Claude Skill implementing a structured, documented form-check of every citation in a legal filing against the Twenty-Second Edition of *The Bluebook: A Uniform System of Citation*.

The protocol enforces a five-stage pipeline — extract, rule-map, form-verify, report, sign off — and produces a contemporaneous record of the form-check that is retained in the matter file. Every finding is anchored to a specific Bluebook rule, Bluepages rule, or table number (e.g., `BB R. 10.2.2`, `BB BP10.1.1`, `BB T6`) so the drafting attorney can audit each call against the Bluebook itself.

Licensed MIT. Reviewed annually or upon issuance of a new Bluebook edition.

## Scope

This protocol checks Bluebook **form** — the components, abbreviations, reporters, dates, pin-cite formatting, short-form usage, signals, parentheticals, quotation punctuation, subsequent-history notation, parallel citation, and capitalization called for by Bluebook 22e. It does not substitute for the drafting attorney's independent verification that each cited authority exists, stands for the proposition cited, and has not been reversed, vacated, or overruled.

## Authority

The authority for this protocol is *The Bluebook: A Uniform System of Citation* (22nd ed. 2025), as published by the Columbia Law Review Association, the Harvard Law Review Association, the University of Pennsylvania Law Review, and The Yale Law Journal.

The protocol does not reproduce Bluebook text. The drafting attorney must have access to a copy of the Bluebook 22e (print or the online subscription at legalbluebook.com) to audit any finding against the source text. Findings are pin-cited by rule or table number; the attorney consults those rules directly.

No copyrighted Bluebook commentary or PDF is bundled with this skill.

## Bundle contents

- `SKILL.md` — protocol definition and the instructions the model follows.
- `checklist-template.md` — printable one-page form-check checklist (front) and drafting sign-off (back).
- `report-template.md` — structural template for the Stage 4 verification report; rendered as `.docx` at runtime.
- `prompt-pack.md` — five chained prompts for use with any chat model that does not support the Skills infrastructure.
- `README.md` — this file.

## Installation

### Option 1 — Claude Code

1. Copy the `citation-verification-protocol/` folder into `~/.claude/skills/` (user-level) or `.claude/skills/` at the matter root (project-level).
2. Confirm the `docx` skill is also installed. The Stage 4 report is rendered through it.
3. Restart Claude Code. The skill appears under `/skills`.
4. Invoke by pasting or attaching a draft and asking Claude to "run the citation verification protocol" or "form-check the citations in this draft."

### Option 2 — Hosted Claude Skills interface

1. Zip the folder with `SKILL.md` at the archive root.
2. Upload through the Skills interface and enable for the workspace.

### Option 3 — Manual prompt

Paste the body of `SKILL.md` (everything below the YAML frontmatter) into a system prompt, attach the draft, and run. `prompt-pack.md` contains a version chained for any chat model without skills infrastructure.

## Workflow

1. **Intake.** Paste or attach the draft. Declare the style: Bluepages (practitioner filings) or white-pages (scholarly). Note any local-court citation rule that overrides Bluebook 22e for the filing court (see `BB BT2`). Confirm the draft is not under a seal that precludes model processing.
2. **Stage 1 — Extraction.** The model returns a numbered extraction table of every citation, one row per pin-cite location. Confirm the count before proceeding.
3. **Stage 2 — Rule mapping.** The model maps each citation to the governing Bluebook rule (BP or R.) and the relevant tables (T1, T6, T7, T8, T10, T12, T13, T14, T16, BT2) by number. Output is a three-column table keyed to the citation numbers from Stage 1.
4. **Stage 3 — Form verification.** The model applies the twelve-test form verification (components, abbreviations, reporter, court/year, pin-cite, short form and *id.*, signal, parenthetical, quotation form, prior/subsequent history, parallel citation, capitalization) and assigns a tier (✓ / ▲ / ✗) to each citation. Each finding is pin-cited to the controlling Bluebook rule or table by number.
5. **Stage 4 — Report.** The model renders a `.docx` form-check report. File in the matter file.
6. **Stage 5 — Drafting sign-off.** After every ✗ is resolved and every ▲ is corrected and re-verified, complete the one-page drafting sign-off from `checklist-template.md`. Signed by the drafting or supervising attorney. Retained in the matter file.

## Verification standard

The output is validated against the reference example in `SKILL.md`, Section 10: a draft with 47 citations in which the verifier plants known-faulty items. A correctly run protocol should surface:

- ✓ 44 conforming;
- ▲ 2 needing correction — e.g., "Int'l Bus. Machs. Corp." abbreviation incorrect per `BB R. 10.2.2; T6`; reporter series given as "F.3d" where the correct series is "F.4th" per `BB R. 10.3.1; T1.1`;
- ✗ 1 non-conforming — e.g., "See Jones v. Smith, at 215." missing required components (reporter, volume, court, year) per `BB R. 10.1`.

A run that does not detect each planted deviation has failed and the protocol must be rerun.

## What this protocol is and is not

- **It is** a workflow for discharging the Bluebook 22e form-check on a documented schedule, producing a deliverable the drafting or supervising attorney signs off on before filing.
- **It is** grounded in the Bluebook itself. Every flagged item carries a pin-cite to a specific Bluebook rule, Bluepages rule, or table so that the drafting attorney can verify the call against the Bluebook directly.
- **It is not** a substitute for the attorney's independent judgment on substantive accuracy: whether the case exists, remains good law, and stands for the proposition cited. Those determinations remain with the drafting and supervising attorneys.
- **It is not** a substitute for the jurisdiction's local citation rules. Where a court rule (e.g., Supreme Court Rule 33; local appellate rules listed at `BB BT2`) departs from Bluebook 22e, the court rule governs and the protocol output must be reconciled accordingly before sign-off.
- **It is not** a substitute for the Bluebook itself. The skill identifies rules by number; the attorney consults the Bluebook for rule language.
- **It is not** confidential-source coverage. The draft is attorney work product; transmission to the model must be consistent with your firm's AI-use policy and with any protective order in the matter.
- **It is not** an attorney-client privilege substitute. Running a draft through a hosted model does not create privilege. If the draft contains privileged material beyond the citations themselves, redact before processing.

## Maintenance

Reviewed annually, and additionally upon issuance of a new edition of *The Bluebook*. Each review updates:

1. The rule and table cross-references in `SKILL.md` if numbering has changed;
2. The Stage 3 test list if the new edition introduces, reorganizes, or retires form rules (e.g., the 22e addition of the *contrast* signal and the "(citation modified)" parenthetical);
3. BT2 references in the operating map if local citation rules in frequently-encountered jurisdictions have changed;
4. The YAML `version` field in `SKILL.md` and the version reference in `checklist-template.md` and `report-template.md`.

Prior versions are retained in `/archive/`; the active version is the one matching the frontmatter.

## License

MIT. See header of `SKILL.md`. Use by licensed attorneys only. Not legal advice. The protocol supplements, and does not replace, the drafting and supervising attorneys' independent obligation to verify the substantive accuracy of every authority cited in the filing.
