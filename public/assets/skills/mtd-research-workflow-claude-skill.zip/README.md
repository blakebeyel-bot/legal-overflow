# Motion-to-Dismiss Research & Draft

A Claude Skill that takes a litigator from complaint to filing-ready Rule 12(b) motion in a day. Seven stages: complaint intake with typed allegation extraction, 12(b) decision tree, element-by-element deficiency analysis, controlling-law research plan, citation-flagged draft generator, opposing-argument war-game, and a partner-review checklist. Federal default; state-court adaptation below.

MIT-licensed. Version 1.0.0. Reviewed April 2026.

## Bundle contents

- `SKILL.md` — the skill definition. Seven-stage workflow; halt conditions; cross-stage JSON shapes; federal / state boundaries;
- `intake-schema.json` — JSON Schema for the parsed complaint (Stage 1);
- `draft-schema.json` — JSON Schema for the motion draft (Stage 5), including the citation manifest and war-game;
- `partner-review-checklist.md` — 15-item pre-filing checklist (Stage 7);
- `sample-run.md` — fully worked end-to-end fictional example;
- `README.md` — this file.

A separate deliverable — `prompt-pack.md` — renders the same seven stages as paste-ready prompts for any chat model. Use it when you do not have the Skills infrastructure available.

## What the skill produces — reference sample

For a complaint alleging three common-law claims — breach of fiduciary duty, negligence, and unjust enrichment — the skill produces a motion with the structure:

```
I. ARGUMENT
   A. Standing (if challenged)
   B. Plaintiff Fails to State a Claim for Breach of Fiduciary Duty
   C. Plaintiff Fails to State a Claim for Negligence
   D. Plaintiff Fails to State a Claim for Unjust Enrichment
   E. Plaintiff's Claims Are Barred by the Applicable Statute of Limitations
CONCLUSION
```

Every citation is flagged `[VERIFY]` until cleared by the citation-verification protocol. Every factual assertion about the complaint cites "(Compl. ¶ __)" or "(Compl. Ex. __)". The worked example is in `sample-run.md`.

## Installation

### Option 1 — Claude Code

Copy the `motion-to-dismiss/` folder into `~/.claude/skills/` (user-level) or `.claude/skills/` at the project/matter root. Restart. The skill will appear under `/skills`. Invoke by pasting or attaching the complaint and saying something like "run the motion-to-dismiss workflow; we are in the Southern District of Florida, diversity, and we represent the defendant."

### Option 2 — Hosted Skills interface

Zip the folder with `SKILL.md` at the archive root and upload.

### Option 3 — No skills infrastructure

Use `prompt-pack.md`. The seven prompts run in order and produce the same JSON shapes at each stage.

## Jurisdiction-adaptation notes

The skill defaults to federal practice under the Federal Rules of Civil Procedure. For state-court motions, adjust as follows.

**Pleading standard.** Twombly/Iqbal is federal. Not every state has adopted it. Many retain a notice-pleading standard that predates Twombly and will not tolerate a 12(b)(6)-style "conclusory allegations disregarded" argument dressed up in federal trappings. Before citing Iqbal in a state-court brief, confirm that the forum state follows it. Where the state does not, substitute the state's pleading standard and the cases that apply it.

**Rule analogs.** Most state codes have analogs to Rule 12(b), but the numbering and the scope differ. A non-exhaustive partial map:

- **New York** — CPLR 3211. Many of the same grounds (jurisdiction, statute of limitations, failure to state a cause of action) but organized differently (3211(a)(1) documentary evidence; 3211(a)(7) failure to state a cause of action; 3211(a)(8) personal jurisdiction; 3211(a)(5) statute of limitations and collateral estoppel; etc.).
- **California** — CCP § 430.10 (demurrer). A meet-and-confer under CCP § 430.41 is required before filing; failure to meet-and-confer is often cited as a ground to deny the demurrer. The standards of review on demurrer — accepting all well-pleaded facts as true but not conclusions — track federal 12(b)(6) but the California case law is its own body.
- **Florida** — Fla. R. Civ. P. 1.140(b). Motions to dismiss are common but the pleading standard in Florida state court is still notice pleading; Florida has not adopted Twombly/Iqbal. A motion predicated on the federal plausibility standard will fail in state court.
- **Texas** — Texas Rule 91a (motion to dismiss for no basis in law or fact). A short, specific rule with its own case law.
- **Illinois** — 735 ILCS 5/2-619 (affirmative matter) and 5/2-615 (defective pleading) are often combined as a "combined motion."

For each of these, the skill's 12(b) decision tree is re-labeled to the state-specific rule; the substantive analysis of elements, SOL, and allegation typing is unchanged.

**Elements.** For state-law claims, the forum state's elements govern under Erie in federal diversity and always in state court. Pull the forum state's formulations — from the highest court's most recent statement — not the Restatement unless the state has expressly adopted the Restatement.

**Meet-and-confer.** Some jurisdictions (California demurrers; many judges' standing orders in federal court) require a meet-and-confer before filing. The skill does not run meet-and-confer; the attorney does. But before filing, confirm and certify compliance.

**Page limits and formatting.** Local rules and judges' standing orders control. Item 15 on the partner-review checklist is the catch-all for this. A motion that fails on page limits loses before the judge reads the first sentence.

## Citation verification

This skill produces every citation with a `[VERIFY]` marker. Clearing the marker is the job of a companion skill — the **citation-verification protocol** — which runs Bluebook form check and substantive accuracy review on each cite in the draft's manifest.

The drafter does not clear the marker. The verifier does. The verifier returns a marked-up manifest; the drafter integrates it and the `[VERIFY]` markers come out. Unverified citations never leave the Firm.

The verification protocol runs off the `citation_manifest` section of `draft-schema.json`. Every citation has a `citation_id`, a pointer to the sentence in which it appears, and a `verify_status` field that the verifier flips from `unverified` to `verified` or `corrected`. An entry is `withdrawn` when the citation does not support the proposition and cannot be saved by a pin-cite or parenthetical adjustment.

## Rule 11, good-faith filing, and AI discipline

A motion to dismiss is a Rule 11 filing. The drafter certifies that the legal contentions are warranted by existing law or a non-frivolous argument for extension and that the factual contentions have evidentiary support. AI-assisted drafting does not change that. Two rules for the Firm:

1. **Every cited case in the draft has been personally read.** Not "the AI found it." Not "the paralegal Shepardized it." A cite that the drafter has not read comes out before filing.
2. **The citation-verification protocol signs off.** The protocol's signed manifest is filed with the matter. If a cite turns out to be wrong, the manifest is the record of the diligence that the Firm performed before filing.

The cases where lawyers have been sanctioned for AI-generated hallucinated citations have a common thread: no human verification, no reading of the cases, no manifest. Do not be one of those cases.

## What this skill does not do

- **It does not decide whether to file.** That is a partner-level decision.
- **It does not brief in opposition to the motion.** A separate skill is appropriate.
- **It does not verify citations.** The citation-verification protocol does that.
- **It does not draft the notice of motion or proposed order** — those are local-rules-sensitive and handled separately.
- **It does not handle motions to strike, for judgment on the pleadings, or for more definite statement** without adjustment. A future version may add Rule 12(c), 12(e), and 12(f) templates.

## Maintenance

Reviewed at least annually and upon (i) a Supreme Court decision bearing on Twombly/Iqbal or any 12(b) doctrine, (ii) a material amendment to the Federal Rules of Civil Procedure, (iii) a new state-court deployment where the local rules and pleading standard differ materially from the federal default, (iv) a sanctions order in any jurisdiction that bears on the use of AI in motion drafting.

## License

MIT. Use by licensed attorneys and their supervised teams only. Not legal advice. The drafting and supervising attorneys remain responsible for the accuracy and defensibility of every motion the Firm files.

*Last reviewed: April 2026.*
