# Sample Run — End-to-End

A fictional matter run through all seven stages. Plaintiff alleges breach of fiduciary duty, negligence, and unjust enrichment. Federal diversity case in the Southern District of Florida, applying Florida substantive law under Erie.

Every citation in this sample is illustrative. Anything that looks like a real case name is generic or invented. Before you use any citation from this file in a real motion, run it through the citation-verification protocol.

## The matter

- **Caption**: *Harbor Capital Partners, LLC v. Meridian Advisors, Inc., and Thomas B. Ellison*
- **Court**: United States District Court for the Southern District of Florida
- **Docket**: 1:26-cv-00847-JEM
- **Filed**: March 12, 2026
- **Jurisdiction**: Diversity (28 U.S.C. § 1332) — HCP is a Delaware LLC with sole member in New York; Meridian is a Florida corporation; Ellison is a Florida resident. Amount in controversy alleged at $4.2M.
- **Claims**: Count I — Breach of Fiduciary Duty (both defendants); Count II — Negligence (both defendants); Count III — Unjust Enrichment (both defendants).
- **Filing deadline for responsive pleading**: April 21, 2026 (service executed March 31, 2026; 21 days under Rule 12(a)(1)(A)(i)).

## Stage 1 — Intake (excerpt from `intake-schema.json`-shaped object)

```json
{
  "schema_version": "intake-v1.0.0",
  "parsed_at": "2026-04-01T09:12:00-04:00",
  "source": {
    "file_name": "HCP_v_Meridian_complaint.pdf",
    "file_hash": "sha256:4c7b…e9a1",
    "format": "pdf",
    "pages": 22
  },
  "caption": "Harbor Capital Partners, LLC v. Meridian Advisors, Inc. and Thomas B. Ellison",
  "court": {
    "name": "United States District Court for the Southern District of Florida",
    "level": "federal_district",
    "docket_number": "1:26-cv-00847-JEM",
    "judge": "Hon. José E. Martinez",
    "division": "Miami"
  },
  "filing_date": "2026-03-12",
  "jurisdiction_basis": {
    "type": "diversity",
    "diversity_amount_alleged": 4200000,
    "diversity_complete_on_face": true,
    "face_defects": []
  },
  "claims": [
    {
      "claim_id": "claim_1",
      "count_label": "Count I",
      "name": "Breach of Fiduciary Duty",
      "governing_law": "Florida common law",
      "elements_by_forum": [
        { "element_number": 1, "name": "Fiduciary relationship", "controlling_case": "Florida high-court formulation — VERIFY" },
        { "element_number": 2, "name": "Breach of fiduciary duty" },
        { "element_number": 3, "name": "Damages proximately caused by the breach" }
      ],
      "supporting_paragraphs": [12, 13, 14, 25, 26, 41, 42, 43, 44]
    },
    {
      "claim_id": "claim_2",
      "count_label": "Count II",
      "name": "Negligence",
      "governing_law": "Florida common law",
      "elements_by_forum": [
        { "element_number": 1, "name": "Duty of care" },
        { "element_number": 2, "name": "Breach" },
        { "element_number": 3, "name": "Causation (actual and proximate)" },
        { "element_number": 4, "name": "Damages" }
      ],
      "supporting_paragraphs": [12, 13, 28, 29, 45, 46, 47]
    },
    {
      "claim_id": "claim_3",
      "count_label": "Count III",
      "name": "Unjust Enrichment",
      "governing_law": "Florida common law",
      "elements_by_forum": [
        { "element_number": 1, "name": "Plaintiff conferred a benefit on defendant" },
        { "element_number": 2, "name": "Defendant appreciated the benefit" },
        { "element_number": 3, "name": "Acceptance and retention of the benefit under circumstances making retention inequitable" }
      ],
      "supporting_paragraphs": [15, 16, 17, 48, 49]
    }
  ],
  "paragraphs": [
    { "paragraph_number": 12, "text": "HCP engaged Meridian as investment advisor in March 2021.", "type": "F", "supports_claims": ["claim_1", "claim_2"] },
    { "paragraph_number": 13, "text": "Defendants owed HCP a fiduciary duty.", "type": "L", "supports_claims": ["claim_1"] },
    { "paragraph_number": 25, "text": "On July 15, 2022, Ellison executed a $1.8M transfer to an entity in which he held an undisclosed 30% interest.", "type": "F", "supports_claims": ["claim_1"], "exhibit_ref": "Ex. B" },
    { "paragraph_number": 28, "text": "Defendants acted with gross negligence.", "type": "C", "supports_claims": ["claim_2"] },
    { "paragraph_number": 44, "text": "As a direct and proximate result of Defendants' breaches of fiduciary duty, HCP has suffered damages in excess of $4M.", "type": "L", "supports_claims": ["claim_1"] }
  ],
  "dates": [
    { "date": "2021-03-10", "paragraph": 12, "significance": "contract_date", "ties_to_claim": ["claim_1", "claim_2", "claim_3"] },
    { "date": "2022-07-15", "paragraph": 25, "significance": "alleged_wrongful_act", "ties_to_claim": ["claim_1", "claim_2"] },
    { "date": "2022-11-02", "paragraph": 30, "significance": "alleged_injury", "ties_to_claim": ["claim_1", "claim_2"] },
    { "date": "2026-03-12", "paragraph": 0, "significance": "filing_date", "ties_to_claim": ["claim_1", "claim_2", "claim_3"] }
  ],
  "relief_sought": [
    "Compensatory damages in excess of $4,000,000",
    "Punitive damages",
    "Pre- and post-judgment interest",
    "Attorneys' fees and costs",
    "Such further relief as the Court deems just"
  ]
}
```

Intake anomalies: none. The complaint is numbered cleanly through paragraph 51 and separates the counts clearly.

## Stage 2 — 12(b) basis identification

Running the decision tree:

- **12(b)(1)** — Subject-matter jurisdiction looks clean on the face. Diversity is pleaded with citizenship of the LLC member (New York) and both defendants (Florida). Amount in controversy pleaded above the threshold. Standing is not a live issue — HCP has pleaded an alleged $4.2M loss to itself, and the injury is traceable to the defendants and redressable by damages. Do not plead (b)(1).
- **12(b)(2)** — Personal jurisdiction over both defendants is uncontested; both are Florida residents. Do not plead (b)(2).
- **12(b)(3)** — Venue is proper in the Southern District under § 1391(b)(2). Do not plead (b)(3).
- **12(b)(4) / (5)** — Service executed via Fla. Stat. § 48.031 on Meridian's registered agent and on Ellison personally. Facially proper. Do not plead (b)(4) or (5).
- **12(b)(6)** — Lead ground. Every count has pleading deficiencies; see Stage 3.
- **12(b)(7)** — No Rule 19 issue apparent.
- **Statute of limitations (raised under 12(b)(6) where apparent on the face)** — Florida four-year limitations period for negligence (Fla. Stat. § 95.11(3)) and likely four-year for unjust enrichment; four-year for breach of fiduciary duty (with a two-year alternative where fraud is alleged). Earliest alleged wrongful act is July 15, 2022. Complaint filed March 12, 2026. Math: 3 years, 7 months, 25 days — inside the four-year period but an important discipline point when we also consider the 2021 contract-date paragraphs that the plaintiff tried to smuggle into the claims.

Grounds to plead: **12(b)(6)** as the centerpiece; **statute of limitations** as to any portion of Counts I–II that traces to the March 2021 engagement rather than the July 2022 transfer; **Rule 9(b)** is not triggered because no claim sounds expressly in fraud, but monitor the opposition.

## Stage 3 — Element-by-element deficiency analysis

### Count I — Breach of Fiduciary Duty

| Element | Pleaded? | Paragraph cites | Allegation type | Verdict |
|---|---|---|---|---|
| 1. Fiduciary relationship | Alleged at ¶ 13 | ¶ 13 | L | **Inadequate** — bare legal conclusion; the complaint does not plead the hallmarks of a fiduciary relationship under Florida law (acceptance of a duty to act for another's benefit, discretion, reliance). ¶ 12 merely alleges engagement as "investment advisor" — a contractual relationship that does not automatically create a fiduciary one. |
| 2. Breach | ¶¶ 25, 26, 41, 42 | ¶¶ 25, 26, 41, 42 | F (25), F (26), L (41, 42) | **Pleaded as to ¶¶ 25-26** (the 2022 self-dealing transfer); **inadequate as to ¶¶ 41-42** (conclusory). |
| 3. Damages | ¶ 44 | ¶ 44 | L | **Inadequate** — alleges "in excess of $4M" as a legal conclusion without pleading the measure, method, or connection. No paragraph links the alleged breach to a specific quantum of harm. |

Verdict: Count I is dismissible for failure to plead the fiduciary-relationship element with anything beyond a legal conclusion and for failure to plead damages causally linked to the breach.

### Count II — Negligence

| Element | Pleaded? | Paragraph cites | Allegation type | Verdict |
|---|---|---|---|---|
| 1. Duty | ¶ 13 (fiduciary) | ¶ 13 | L | **Inadequate** — the complaint asserts duty only derivatively from the fiduciary allegation; no separate negligence-duty basis is pleaded. Although Florida's economic-loss rule is now limited to products liability under *Tiara Condo. Ass'n, Inc. v. Marsh & McLennan Cos.*, 110 So. 3d 399 (Fla. 2013), a negligence claim arising from the performance of contractual duties still requires an independent tort duty. No such duty is pleaded. |
| 2. Breach | ¶¶ 28, 45 | ¶¶ 28, 45 | C (28), L (45) | **Inadequate** — "gross negligence" is a conclusion. |
| 3. Causation | ¶ 46 | ¶ 46 | L | **Inadequate** — "as a direct result" is a conclusion. |
| 4. Damages | ¶ 47 | ¶ 47 | L | **Inadequate** — same measure defect as Count I. |

Verdict: Count II is dismissible on duty (economic-loss rule and no independent duty pleaded) and for conclusory pleading across breach, causation, and damages.

### Count III — Unjust Enrichment

| Element | Pleaded? | Paragraph cites | Allegation type | Verdict |
|---|---|---|---|---|
| 1. Benefit conferred | ¶ 15 | ¶ 15 | F | **Pleaded** — fees paid under the engagement. |
| 2. Appreciation | ¶ 16 | ¶ 16 | F | **Pleaded**. |
| 3. Inequitable retention | ¶¶ 17, 48, 49 | ¶¶ 17, 48, 49 | L | **Inadequate as standalone** — but the larger problem is the gating question: the engagement letter (attached to the complaint as Ex. A) is an enforceable contract governing the subject matter. Under Florida law, unjust enrichment is unavailable where an express contract governs. |

Verdict: Count III is dismissible as duplicative of a contract that was not pleaded as Count IV but was attached as Ex. A and referenced throughout.

## Stage 4 — Controlling-law research plan

Tier 1 — Florida Supreme Court:

- A controlling formulation of the fiduciary-relationship test.
- The economic-loss rule's current scope.
- Unjust enrichment's availability where an express contract governs.

Tier 2 — Eleventh Circuit / Florida DCAs:

- Twombly/Iqbal applied to fiduciary-duty pleadings.
- Rule 12(b)(6) treatment of SOL and duplicative-contract claims.
- Florida DCA treatment of "investment advisor" as creating a fiduciary relationship or not.

Tier 3 — S.D. Fla. opinions:

- Motions to dismiss in comparable investment-advisor cases before Judge Martinez or the division generally.

Every case pulled is noted in the research plan with the holding in one sentence, the pin-cite for the proposition, and the Shepard/KeyCite status. Each is flagged `VERIFY`.

## Stage 5 — Draft (excerpt)

The full draft follows the `draft-schema.json` shape. The `I. ARGUMENT` section has five subsections (A–E). An excerpt from subsection B:

> **B. Plaintiff Fails to State a Claim for Breach of Fiduciary Duty**
>
> To plead breach of fiduciary duty under Florida law, a plaintiff must allege (1) the existence of a fiduciary relationship, (2) breach of the duty, and (3) damages proximately caused by the breach. *See* [controlling Florida Supreme Court case] [VERIFY]. HCP fails on the first and third.
>
> *1. HCP does not plead a fiduciary relationship.* HCP's only factual allegation bearing on the relationship is that it engaged Meridian as "investment advisor" in March 2021. (Compl. ¶ 12.) The complaint's assertion that Defendants "owed HCP a fiduciary duty" (Compl. ¶ 13) is a legal conclusion that the Court must disregard at the 12(b)(6) stage. *See Ashcroft v. Iqbal*, 556 U.S. 662, 678–79 (2009) [VERIFY]. The engagement of a financial advisor under a written contract does not, without more, give rise to a fiduciary relationship under Florida law. *See* [Florida DCA case] [VERIFY]. HCP pleads no facts establishing the hallmarks of a fiduciary relationship — acceptance of an undertaking to act for HCP's benefit with respect to a matter in which HCP reposed confidence and placed discretion.
>
> *2. HCP does not plead damages causally linked to the purported breach.* Paragraph 44 alleges damages "in excess of $4,000,000," but that is the pleader's conclusion rather than a factual allegation linking the alleged July 2022 transfer (Compl. ¶ 25) to a quantum of harm. Florida law does not permit a plaintiff to plead damages by reference only to a dollar figure untethered to a theory of injury. *See* [controlling case] [VERIFY].
>
> Count I should be dismissed.

The draft's **I. ARGUMENT** section has the structure the reference sample requires:

- **A. Standing** — conditional. Included here only to note that HCP's standing is not disputed on the face of the complaint; the section is retained as a placeholder and in a live motion would be deleted if not asserted.
- **B. Plaintiff Fails to State a Claim for Breach of Fiduciary Duty** — element-by-element (shown above).
- **C. Plaintiff Fails to State a Claim for Negligence** — duty, breach, causation, damages, with the economic-loss rule paragraph.
- **D. Plaintiff Fails to State a Claim for Unjust Enrichment** — duplicative-contract argument leading.
- **E. Plaintiff's Claims Are Barred by the Applicable Statute of Limitations** — conditional argument addressed to the 2021-anchored theory; dates on the page, arithmetic shown.

Conclusion: dismissal of Counts I and II with prejudice to the 2021-based theory and without prejudice to a properly pleaded theory keyed to the July 2022 transfer; dismissal of Count III with prejudice as duplicative.

## Stage 6 — War-game

Three strongest opposition arguments and the pre-emption:

1. *"A fiduciary relationship exists as a matter of law where an investment advisor has discretionary authority over client assets."* — Pre-empted in § B.1 by citing the Florida rule that "investment advisor" is not a per se fiduciary label and that discretionary authority must be pleaded with facts, not labels.
2. *"The economic-loss rule does not apply to negligence claims alleging breach of an independent duty."* — Pre-empted in § C by pleading that no independent duty is pleaded; any duty pleaded is contractual in origin.
3. *"Unjust enrichment may be pleaded in the alternative to a contract claim."* — Pre-empted in § D by citing the Florida rule that alternative pleading is available only where the contract's existence is disputed, which is not the case here because the engagement letter is attached.

Unanswered: one war-gamed argument — that Ellison individually is not a party to the engagement letter and therefore the duplicative-contract rule does not extend to him as to Count III. This is flagged in the partner-review note as a drafting judgment call: either add a fourth subsection to Count III or accept partial relief.

## Stage 7 — Partner-review checklist

All 15 items marked; items 4, 6, 8, 9, 13, and 15 are the ones that required iteration. Notable entries:

- Item 8 (SOL math on the page): PASS after the arithmetic was moved from a footnote into text.
- Item 10 (every case [VERIFY] or cleared): PASS with the manifest attached; citation verification will run on the draft before filing.
- Item 13 (war-gamed oppositions pre-empted): PASS with one unanswered argument noted for the partner.
- Item 15 (local rules and judge's standing order): PASS after confirming Judge Martinez's 20-page limit on initial motions and hyperlinking requirement.

## What the partner sees

A package consisting of: the draft, the `citation_manifest`, the war-game, the intake artifact (for audit trace), the research plan, and the checklist. Estimated partner-read time: 35 minutes. Estimated rewrite time if all items pass: zero to light. That is the outcome the workflow is designed to produce.
