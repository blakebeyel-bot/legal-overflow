---
name: Motion-to-Dismiss Research & Draft
description: Seven-stage workflow that takes a litigator from complaint to filing-ready Rule 12(b) motion in one day. Invoke when the user pastes or describes a complaint; mentions Rule 12(b), motion to dismiss, failure to state a claim, standing, statute of limitations, element deficiency, or litigation intake. Extracts allegations, maps 12(b) bases via decision tree, runs element-by-element deficiency analysis, generates a controlling-law research plan, drafts with citation flags, war-games opposing arguments, and produces a partner-review checklist. Federal default; state-court adaptation guidance included.
version: 1.0.0
license: MIT
---

# Motion-to-Dismiss Research & Draft

I have drafted a lot of these. The workflow below is what I wish I had the first time I had 24 hours to file. Seven stages, federal default, state-court variants noted where they matter. The goal is a draft that a partner can open and not have to rewrite — meaning the citations are real, the elements are analyzed one by one, the opposing brief's strongest points have been answered before they are made, and the statute-of-limitations math is on the page, not in my head.

This skill assumes Rule 12 of the Federal Rules of Civil Procedure applies. For state actions, use the state-court adaptation notes in the README. It also assumes that the pleading being attacked is a complaint; for an answer with counterclaims or a crossclaim, the same seven stages apply but the caption and relief block change.

Two ground rules, which are not optional:

1. **Every case citation the skill produces is flagged `VERIFY` until it has been run through the Firm's citation-verification protocol.** I do not file a draft that has not been through cite-check. I have seen what happens to the lawyers who do.
2. **Every factual assertion about the complaint cites a paragraph number in the complaint.** If I cannot cite a paragraph, the assertion does not go in the motion.

## Stage 1 — Complaint intake and allegation extraction

Input: the complaint (PDF, Word, or pasted text), plus any incorporated exhibits.

Output: an `intake-schema.json`-shaped object with the complaint parsed into caption, parties, jurisdictional basis, claims, allegations (each typed factual / conclusory / legal / date), dates of significance, relief sought, and exhibits.

What I do here, and what the skill does for me:

- Parse the caption, docket, court, filing date, and jurisdictional basis. If diversity, confirm amount-in-controversy pleading and complete diversity on the face. If federal question, flag the statute or constitutional provision invoked.
- Extract every numbered paragraph. Type each one as:
  - **F** — a factual allegation (who, what, when, where).
  - **C** — a conclusory allegation (e.g., "Defendant acted with gross negligence").
  - **L** — a legal conclusion (e.g., "Defendant owed a fiduciary duty to Plaintiff").
  - **D** — a date or a date-sensitive fact.
  - **E** — an allegation that references or attaches an exhibit.
- Map each claim (Count I, Count II, …) to the paragraphs that support it. A claim that rests only on C- and L-typed paragraphs is already half-dismissed; Twombly/Iqbal target conclusory pleading directly.
- Produce a dates timeline. Earliest alleged act, latest alleged act, accrual candidates for each claim, filing date. I use this timeline in Stage 3 for statute-of-limitations analysis and in Stage 5 for the fact section.

Halt condition: if the complaint is not coherent — e.g., paragraphs not numbered, claims not clearly delineated — I stop and fix the parse before moving on. A garbled intake produces a garbled motion.

## Stage 2 — 12(b) basis identification

Input: the intake object from Stage 1.

Output: a prioritized list of 12(b) grounds to plead, with one to three sentences explaining why each applies to this complaint.

I run the decision tree in this order. Order matters because some grounds are outcome-dispositive and moot the others.

1. **12(b)(1) — Subject-matter jurisdiction.** Is there diversity on the face? Is there a federal question on the face? Is the amount in controversy satisfied? Is this a claim Congress has withdrawn from federal jurisdiction? Standing — constitutional injury, causation, redressability — lives here. If (b)(1) applies, the court cannot reach (b)(6), and I lead with (b)(1). Rule 12(h)(3) cannot be waived; I flag it even if I plead only (b)(6) later.
2. **12(b)(2) — Personal jurisdiction.** General or specific jurisdiction over each defendant? Contacts with the forum? Was service proper? For foreign defendants, Hague Convention compliance? Waivable under 12(h)(1); if raised, it must be raised now or it is lost.
3. **12(b)(3) — Venue.** Proper district under 28 U.S.C. § 1391? Forum-selection clause implicating § 1404 (transfer) rather than 12(b)(3)? Waivable — raise now or lose it.
4. **12(b)(4) / (5) — Process / service of process.** Defective summons? Service outside Rule 4's time window (90 days, with good-cause extension)? Service on a non-authorized agent? Waivable — raise now or lose it.
5. **12(b)(6) — Failure to state a claim.** This is the centerpiece of most motions. Under Twombly/Iqbal, the complaint must state a plausible claim on its face, and legal conclusions are disregarded. For each claim, identify the elements and walk through which are alleged, which are conclusory, and which are absent. Stage 3 does this work in detail.
6. **12(b)(7) — Failure to join a party under Rule 19.** Indispensable party not joined? Joinder would destroy jurisdiction? Equity and good conscience factors?

Parallel grounds that are not 12(b) but that I plead alongside if available, because they can be raised by the same motion under Rule 12:

- **Statute of limitations** — technically an affirmative defense, but when the limitations bar appears on the face of the complaint (together with any documents the court may consider without converting the motion), it is properly raised under Rule 12(b)(6). I cite the circuit rule on this in the motion.
- **Res judicata / collateral estoppel** — likewise, face-of-the-complaint treatment only.
- **Failure to plead fraud with particularity under Rule 9(b)** — for any fraud-based claim.

## Stage 3 — Element-by-element deficiency analysis

Input: the intake, the 12(b) basis list.

Output: a table for each claim with rows = elements and columns = pleaded?, paragraph cites, factual vs. conclusory, verdict.

This is the stage that separates a motion that survives from a motion that gets denied with "Defendant's arguments are better suited to summary judgment."

For each claim:

- State the elements from controlling law. Federal claims: the statute plus circuit-controlling construction. State-law claims in diversity: the forum state's elements under Erie, with choice-of-law analysis if there is any ambiguity.
- For each element, list the complaint paragraphs that purport to allege it.
- Classify the allegations: factual (F) or conclusory (C) / legal (L). If the only support is C or L, the element is not plausibly pleaded under Iqbal.
- Write the element "verdict": **pleaded**, **inadequately pleaded** (with the reason — conclusory, no causal link, missing scienter, missing damages), or **not pleaded at all**.
- For dates, run the accrual analysis. Each claim has its own limitations period and accrual rule (occurrence vs. discovery). If the earliest date in the pleading is outside the limitations period and the complaint does not plead a tolling or delayed-discovery basis, flag SOL as a dismissal ground for that count.

For the reference sample — a complaint alleging breach of fiduciary duty, negligence, and unjust enrichment — I produce three tables:

- **Breach of fiduciary duty**: (1) fiduciary relationship, (2) breach of fiduciary duty, (3) damages caused by the breach. The fiduciary-relationship element is the usual battleground; a bare assertion that a relationship was "fiduciary in nature" is a legal conclusion.
- **Negligence**: (1) duty, (2) breach, (3) causation (actual and proximate), (4) damages. The duty element is where most motions turn: does the forum recognize a duty on these facts?
- **Unjust enrichment**: (1) benefit conferred on defendant by plaintiff, (2) appreciation of the benefit, (3) inequity of retention. Gating question: does an adequate legal remedy already exist? If so, the equitable claim is duplicative. Many jurisdictions bar unjust enrichment when an enforceable contract governs the subject matter.

## Stage 4 — Controlling-law research plan

Input: the deficiency tables, the jurisdictional basis, the claim list.

Output: a research plan — a prioritized list of cases and statutes to pull, each tied to the element it supports and the argument it will anchor.

I run this plan before I draft. The plan prevents the most common drafting failure — writing the argument first and then hunting for support, which is how weak citations get written into motions.

The plan has four priority tiers:

- **Tier 1 — controlling authority**: the Supreme Court (for federal claims) or the state's highest court (for state-law claims). Binding. I pull one or two per element.
- **Tier 2 — controlling appellate authority in the forum circuit / state**: for federal claims, the circuit; for state-law claims, the state's intermediate appellate courts. Binding on the district court.
- **Tier 3 — in-circuit / in-state trial-court authority**: persuasive but useful, especially if the same judge has ruled on the issue.
- **Tier 4 — out-of-circuit / secondary**: used sparingly. If I am relying on a Second Circuit case to argue something in the Fifth Circuit, the partner will want to know why.

For each cited authority I record: case name (short-form), forum/court, year, holding in one sentence, pin-cite for the proposition, and whether it has been questioned or overruled. Every case is flagged `VERIFY` until it has run through the citation-verification protocol — see Stage 5.

## Stage 5 — Citation-verified draft generator

Input: everything above.

Output: a `draft-schema.json`-shaped object that renders to a filing-formatted motion. Federal default caption; state adaptation in the README.

The draft has the following structure, which maps to the reference-sample output structure the skill must reproduce:

- **Caption / introduction**: short — one or two paragraphs stating who brings the motion and what 12(b) grounds are asserted.
- **Factual background**: the allegations as the plaintiff pleads them, in neutral voice, each sentence paragraph-cited. I do not argue here; the argument is in section I.
- **I. ARGUMENT**
  - **A. Standing** — if challenged under 12(b)(1). Walk through injury-in-fact, causation, redressability; if any fails, the court cannot reach the merits.
  - **B. Plaintiff Fails to State a Claim for Breach of Fiduciary Duty** (or the lead claim). Element-by-element, with the deficiency table from Stage 3 converted to prose. Each element gets a sub-heading.
  - **C. Plaintiff Fails to State a Claim for Negligence**. Same treatment.
  - **D. Plaintiff Fails to State a Claim for Unjust Enrichment**. Same treatment, with the duplicative-remedy point.
  - **E. Plaintiff's Claims Are Barred by the Applicable Statute of Limitations**. Accrual analysis for each count with the dates on the page.
- **Conclusion**: relief requested — dismissal with prejudice if amendment would be futile; without prejudice otherwise. I do not ask for "with prejudice" lightly, because the court will often grant leave to amend on a first motion, and asking for something you know you will not get weakens the rest of the brief.

Citation discipline inside the draft:

- Every case citation in the draft is emitted with a `[VERIFY]` marker. The skill does not clear the marker. The citation-verification protocol — a separate skill named `citation-verification-protocol` — clears the marker after Bluebook form check and substantive accuracy review.
- String cites are minimized. A proposition gets one controlling citation; a string cite indicates that the author could not find one case that said what they needed.
- Id., supra, short form are used as Bluebook requires, but are regenerated during citation verification (their correctness depends on the final ordering of the draft).
- Every factual assertion about the complaint cites "(Compl. ¶ __)" or, for exhibits the court may consider, "(Compl. Ex. __)".

The draft generator cross-references the citation-verification protocol by emitting a manifest of every citation in the draft, keyed to the sentence in which it appears, as a sibling artifact to the draft itself. The verifier reads that manifest, runs Bluebook form check and substantive review on each cite, and returns a marked-up manifest that the drafter integrates.

## Stage 6 — Opposing-argument war-gaming

Input: the draft.

Output: a list of the three to five best arguments the opposing brief will make, and the counters the draft already contains or should contain.

I do this before Stage 7 because it is easier to add a paragraph to a draft than to rewrite it after the opposition is filed. For the reference sample I expect the following counter-moves:

- On fiduciary-duty, the plaintiff will argue that the relationship was fiduciary as a matter of law given the facts alleged. Pre-empt by citing the controlling case that sets the test for a fiduciary relationship in the forum and showing the pleaded facts do not meet the test.
- On negligence, the plaintiff will argue a duty existed under the forum's general-duty framework. Pre-empt with the controlling no-duty case on analogous facts.
- On unjust enrichment, the plaintiff will argue in the alternative to a contract claim. Pre-empt by citing the rule that alternative pleading does not save a claim that is barred by an actual contract covering the subject matter; cite the case that applies that rule at 12(b)(6), not summary judgment.
- On SOL, the plaintiff will plead delayed discovery or fraudulent concealment in the opposition, even though it is not in the complaint. Pre-empt by arguing that the plaintiff is bound by the pleaded dates and cannot amend via opposition brief; cite the case that says so.

Each counter-move gets a sentence in the draft, typically buried in the argument for the relevant element. The point is not to telegraph; the point is to have the answer on the page before the question is asked.

## Stage 7 — Partner-review checklist

Input: the draft, the manifest, the war-game.

Output: a 15-item checklist (see `partner-review-checklist.md`) marked pass/fail/N/A.

The checklist is the last gate before the partner sees the draft. If any item fails, the drafter fixes it before sending up. A partner who opens a draft and finds the SOL math wrong on the second page will not trust anything later in the draft — fix it first.

## Cross-stage JSON shape

At every stage the artifact produced conforms to one of two schemas:

- `intake-schema.json` — Stage 1 output; reused by Stages 2–4.
- `draft-schema.json` — Stage 5 output; consumed by Stages 6–7.

Both schemas are explicit about which fields are factual (drawn from the complaint) and which are attorney-generated (the deficiency analysis, the research plan, the argument). A reviewer should be able to audit the draft back to the complaint on any assertion by following the field references.

## Federal vs. state-court adaptation

Federal default throughout. For state-court motions:

- Most state rules mirror Rule 12, but not all. Check the state's analog — e.g., New York CPLR 3211, California CCP § 430.10, Florida Rule 1.140(b). The grounds are similar but the numbering differs and the standards diverge. California in particular requires a meet-and-confer before filing a demurrer (the state equivalent).
- Twombly/Iqbal is federal. Not every state has adopted it; many retain a notice-pleading standard. Do not cite Iqbal in a state-court brief without confirming the state follows it.
- The forum state's elements of the claims govern under Erie in federal diversity and always in state court. Pull the forum-state elements, not the Restatement, unless the state has expressly adopted the Restatement formulation.

## Halt conditions summary

- Stage 1: parse failure — stop.
- Stage 2: no viable 12(b) ground — discuss with partner before drafting; a meritless motion is a waiver of arguments better raised at summary judgment.
- Stage 3: an element that is pleaded with factual specificity on every required count — reconsider the motion. If every element is plausibly pleaded, the motion is not a winner; escalate.
- Stage 4: a controlling case cuts the wrong way on a key element — revise the theory before drafting.
- Stage 5: any citation not yet verified — the draft leaves the stage with `[VERIFY]` markers intact. The markers are cleared by the citation verifier, not here.
- Stage 6: a war-gamed opposition argument has no counter — flag it in the partner-review note, not in the draft.
- Stage 7: any checklist item fails — fix before transmitting.

## What this skill does not do

- **It does not decide whether to file.** That is a partner decision, informed by this draft, the client's objectives, the budget, and the judge.
- **It does not brief in opposition to the motion.** A separate skill is appropriate for that.
- **It does not verify citations.** The citation-verification protocol does that. The two skills are designed to run together.
- **It does not handle motions to dismiss counterclaims or third-party complaints without manual adjustment.** The caption and posture differ.
- **It does not draft the notice of motion or proposed order** — those are local-rules-sensitive and handled separately.

## Maintenance

Reviewed annually and upon (i) a Supreme Court decision that shifts the Twombly/Iqbal standard or a 12(b) doctrine, (ii) a material Federal Rules amendment, (iii) adoption of the skill in a new practice area where the claim templates need extension.
