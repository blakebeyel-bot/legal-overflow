# Partner-Review Checklist — Motion to Dismiss

Fifteen items. Each is pass, fail, or N/A. A fail sends the draft back to the associate — it does not go up to the partner until every item passes or is formally waived with a note on the record.

I use this checklist because I have seen drafts fail on all fifteen at one time or another, and on each failure there is a partner wondering whether the associate read the complaint. This is the checklist that keeps that thought from forming.

## The fifteen

### 1. Caption correctness
The caption matches the complaint verbatim, including party order, party identifiers ("Inc.", "LLC"), and case number. The court is stated in the form the local rules require. The division, if any, is correct. If the caption on the complaint has a typo, the motion repeats the typo — do not "fix" the plaintiff's caption.

### 2. 12(b) grounds match the notice of motion
The grounds asserted in the motion body match the grounds in the notice of motion (or the first paragraph of the motion itself). A ground raised in the brief but not in the notice is a procedural defect. Rule 12(h)(1) waives certain grounds not raised in the first responsive motion, so an omission here is not a harmless typographical mistake.

### 3. Every factual assertion about the complaint is paragraph-cited
Read through the motion with a highlighter and confirm that every sentence that says "Plaintiff alleges …" or "The complaint states …" is followed by a "(Compl. ¶ __)" cite. Missing cites suggest the associate is characterizing the complaint rather than quoting it — a dangerous habit.

### 4. The complaint's best allegations are addressed, not ignored
If the complaint has a strong paragraph, the motion cites it and explains why, even taken as true, it does not plead the element. A motion that avoids the complaint's best paragraph will be met by an opposition that builds on it. Confront, do not dodge.

### 5. Elements for each challenged claim are stated from controlling law
For state-law claims, the forum state's elements — from the highest court's most recent statement — appear in the motion. Restatement formulations appear only if the forum state has adopted them. Federal claims cite the statute and circuit construction. The element list is not paraphrased; the courts have specific formulations and the motion uses them.

### 6. Element-by-element analysis is complete
For each challenged claim, the motion walks through every element. An element skipped is an admission that it is plausibly pleaded. If an element is conceded, say so expressly; do not hope the court will not notice.

### 7. Twombly / Iqbal is applied, not cited as a slogan
Every conclusory allegation that the motion asks the court to disregard is identified specifically — "Paragraph 37 states a legal conclusion" — not waved at generically. Iqbal is a working standard, not an incantation.

### 8. Statute of limitations math is on the page
If SOL is asserted, the brief shows the earliest and latest alleged act, the filing date, the limitations period with citation to the statute, and the arithmetic. A partner should not have to do the math from the dates in the facts section.

### 9. Tolling, delayed-discovery, and equitable-estoppel defenses to SOL are anticipated
The plaintiff will plead tolling in the opposition whether or not it is in the complaint. The motion cites the rule that a plaintiff cannot amend via opposition brief, and where the complaint pleads any basis for tolling, the motion addresses why it fails.

### 10. Every case citation is flagged [VERIFY] or has been cleared by the citation-verification protocol
Draft leaves the drafter's desk with no unflagged citations. If the citation-verification protocol has been run, the protocol's signed manifest is attached. If it has not been run, every cite carries the `[VERIFY]` marker and a note in the partner-review package says "citation verification pending."

### 11. The draft does not cite any case I have not personally looked at
This is the line that keeps lawyers off the front page of the legal press. If a citation appears in the draft and the drafter has not pulled the case and read it, the citation comes out. "The AI found it" is not a defense.

### 12. String cites are minimized
A string cite is a signal that no single case says what the brief needs. Each string cite is either collapsed to a single controlling case or the brief acknowledges that the proposition is a synthesis.

### 13. War-gamed oppositions are pre-empted in the draft
For each of the three to five strongest opposition arguments the war-game identified, the draft contains a pre-emptive sentence or paragraph. Unanswered arguments are listed in the partner-review note, not buried.

### 14. Relief requested is realistic
Dismiss with prejudice where amendment would be futile (e.g., SOL bar, standing defect that cannot be re-pleaded). Dismiss without prejudice for pleading deficiencies that can be cured. Do not ask for "with prejudice" across the board; it costs credibility.

### 15. Local rules and the judge's standing order have been checked
Page limits, font, margins, type size, meet-and-confer certifications, courtesy copy requirements, proposed-order format, hyperlinking rules, electronic-signature block. If the judge has a motion-practice standing order, every item in that order has been applied. A five-page hammering on the merits loses to a one-page order that says "denied for failure to comply with the Court's standing order on page limits."

## After the checklist

When all fifteen pass (or the failures are formally waived), the draft moves to the partner with:

- the marked-up checklist;
- the citation-verification manifest;
- the war-game with any unanswered arguments flagged;
- the intake artifact (so the partner can audit any assertion back to the complaint);
- the research plan (so the partner can see which cases were considered, not only which were cited).

The partner-review package is the record that supports the Firm's Rule 11 inquiry into the motion. Keep it.
