<!--
STRUCTURAL TEMPLATE ONLY. The actual deliverable must be a Microsoft Word (.docx) file.
This markdown file defines the sections, order, and content rules. Translate headings
and quote blocks into Word styles when rendering: H1 for the memo title, H2 for numbered
sections, H3 for each clause finding, Word's Quote style for all verbatim contract
language and proposed redlines, and a real Word table for the Critical Issues section.
Do NOT ship this memo as markdown.
-->

# Redline Memo — [Agreement Type]

**Counterparty:** [Counterparty Name]
**Agreement:** [Full title, e.g., "Master Services Agreement dated [date]"]
**Reviewer:** [Attorney name]
**Review date:** [YYYY-MM-DD]
**Overall recommendation:** [APPROVE AS-IS | APPROVE WITH CHANGES | DO NOT SIGN]

---

## 1. Executive Summary

- [Plain-English bullet a non-lawyer business owner can act on.]
- [What the deal actually does in one sentence.]
- [The top 1–2 reasons to be careful.]
- [Top ask if you only get one ask.]
- [Gating question for the business team, if any.]

---

## 2. Critical Issues

| # | Severity | Section | Issue (one line) | Proposed Fix (one line) |
|---|----------|---------|------------------|--------------------------|
| 1 | CRITICAL | §X.X | [brief] | [brief] |
| 2 | HIGH | §X.X | [brief] | [brief] |

---

## 3. Clause-by-Clause Findings

### 3.1 [Clause name] — §[number] — [SEVERITY]

**Current language (quoted verbatim):**
> "[exact text from the contract]"

**Why it's a problem:**
[Two to four sentences, plain English. Name the risk. Name the realistic downside.]

**Proposed redline (paste-ready):**
> "[exact replacement language]"

**Fallback position:**
[What we'll accept if they push back, and what we will not accept.]

---

### 3.2 [Next clause…]

*(repeat block per issue)*

---

## 4. Medium / Low Items

- §X.X — [one-liner, fix if easy]
- §X.X — [one-liner, fix if easy]

---

## 5. Open Questions for the Business Team

1. [Question — e.g., "Is the counterparty processing any personal data on our behalf? If yes, we need a DPA."]
2. [Question — e.g., "What is the actual contract value? The cap analysis depends on it."]
3. [Question — e.g., "Are we okay with perpetual confidentiality on trade secrets only, or do you need it for all Confidential Information?"]

---

## 6. Confidence Statement

Overall confidence in this review: **[X/5]**.

Areas of lower confidence:
- [e.g., "§8.4 cross-references a Schedule C that was not provided. Reassess when Schedule C is delivered."]
- [e.g., "The defined term 'Affiliate' is narrower than market. Confirm intent with counterparty."]

---

## 7. Pushback Pass — Issues I Almost Missed

[List anything surfaced on the senior-partner rereview. If nothing, state: "Pushback pass completed. No additional issues surfaced."]

---

*Prepared as a first-pass Tier 1 review. Not a substitute for a full negotiation cycle or outside-counsel opinion on novel or high-dollar terms.*
