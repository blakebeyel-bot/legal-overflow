# Contract Redline Review — Tier 1

A Claude Skill for in-house attorneys doing first-pass review of NDAs, MSAs, and SaaS agreements. Segments clauses, triages risk, deep-reads limitation of liability and indemnification, audits IP/data/confidentiality, and compiles a redline memo with paste-ready language and a senior-partner pushback pass.

Licensed MIT. Use at your own risk. Not a substitute for licensed legal counsel.

## What's in the bundle

- `SKILL.md` — the skill definition and instructions Claude follows
- `memo-template.md` — structural map for the redline memo (sections, order, content rules). The actual deliverable is always a Word `.docx` file — this markdown file is not the output format.
- `README.md` — this file

## Output format

The skill produces a Microsoft Word (`.docx`) memo, saved to your workspace folder and linked in the chat response. The skill delegates Word-document rendering to the `docx` skill, so that skill must also be installed (it typically ships with Claude Code by default). If the `docx` skill is not present, the memo will fall back to markdown — check your installation if that happens.

## Installation

### Option 1 — Claude Code (local)

1. Locate (or create) the skills directory for your Claude Code install. On most systems this is `~/.claude/skills/` for user-level skills or `.claude/skills/` at the root of a project for project-level skills.
2. Create the subfolder:

   ```
   .claude/skills/contract-redline-tier1/
   ```

3. Drop all three files from this bundle into that folder.
4. Restart Claude Code (or reload the session). The skill will auto-register.
5. Trigger it by asking Claude to "review this NDA," "redline this MSA," "first-pass this SaaS agreement," or similar. The description field in `SKILL.md` is what Claude uses to decide when to invoke the skill.

### Option 2 — Claude Skills interface (hosted)

1. Zip the `contract-redline-tier1/` folder so that `SKILL.md` sits at the root of the archive.
2. Open the Skills interface in your Claude product (claude.ai settings → Skills, or the Cowork skills panel).
3. Upload the zip.
4. Enable the skill for the workspace or project where you want it available.

### Option 3 — Manual prompt

If you are not using Claude Code or the hosted Skills interface, paste the body of `SKILL.md` (everything below the YAML frontmatter) into the system prompt or the first user message, attach the contract, and ask for a Tier 1 review.

## Verifying it works

Paste the reference example clause into Claude after loading the skill:

> §7.2 LIMITATION OF LIABILITY. In no event shall Vendor's aggregate liability exceed the fees paid by Customer in the twelve (12) months preceding the claim.

You should get back a memo that (a) flags the one-sided cap, (b) requests a mutual cap, (c) adds carve-outs for IP indemnity, confidentiality breach, data breach, gross negligence, willful misconduct, and fraud, and (d) provides paste-ready replacement language with a confidence rating.

If you do not get that, the skill did not load — check the folder path and file names.

## Scope and limits

Tier 1 means first-pass. It catches the obvious problems and the load-bearing ones. It does not replace:

- A full negotiation cycle on a high-dollar or strategically novel deal
- Specialist review for regulated contexts (HIPAA, FedRAMP, export control, financial services)
- An outside-counsel opinion where one is warranted
- Local-law review for jurisdictions outside the US

## License

MIT. See header of `SKILL.md`.
