<!--
AI-USE DISCLOSURE RIDER — UNITED STATES TEMPLATE
Authority hooks: ABA Model Rules 1.1 cmt. [8], 1.3, 1.4, 1.5, 1.6, 5.3; ABA
Formal Opinion 512 (July 29, 2024); applicable state ethics opinion.

Template tokens in {curly_braces} are substituted at runtime. Do not modify
Article 1 — the four anchor sentences are load-bearing and must appear
verbatim in every rendered rider. "Attorney" and "lawyer" are used per ABA
convention.
-->

# RIDER TO ENGAGEMENT LETTER — USE OF GENERATIVE ARTIFICIAL INTELLIGENCE

**Firm:** {firm_name}
**Client:** {client_name}
**Engagement letter dated:** {engagement_letter_date}
**Rider effective date:** {effective_date}
**Governing jurisdiction:** {state_or_member_state}

This Rider forms part of, and is governed by the same terms as, the engagement letter between {firm_name} (the "Firm") and {client_name} (the "Client") dated {engagement_letter_date} (the "Engagement Letter"). In the event of any conflict between this Rider and the Engagement Letter, this Rider controls with respect to the Firm's use of generative artificial intelligence tools.

## 1. Scope of disclosure

In representing you, {firm_name} may use generative AI tools to assist with research, drafting, and document review. A qualified attorney reviews and is responsible for all work product before it leaves this office.

- No client data is used to train third-party models.
- Prompts and outputs are retained per §5 below.
- You may opt out at any time in writing.

This disclosure is made consistently with the Firm's duties under the ABA Model Rules of Professional Conduct, including Rules 1.1 (competence, including technological competence under Comment [8]), 1.3 (diligence), 1.4 (communication), 1.5 (fees), 1.6 (confidentiality), and 5.3 (responsibilities regarding nonlawyer assistance); ABA Formal Opinion 512 (July 29, 2024); and the applicable professional-conduct rules of {state_or_member_state}, including any state ethics opinion then in effect (e.g., Florida Bar Ethics Op. 24-1 (Jan. 19, 2024); California State Bar, Practical Guidance for the Use of Generative Artificial Intelligence in the Practice of Law (Nov. 16, 2023); New York State Bar / NYC Bar Formal Op. 2024-5 (2024); Texas Bar Op. 705 (Feb. 2025); Oregon State Bar Formal Op. 2025-205 (Feb. 2025)). Where a court having jurisdiction over this matter has adopted a standing order or local rule requiring affirmative disclosure of generative-AI use in a filing, the Firm complies with that order or rule in addition to the disclosures in this Rider.

## 2. AI tools used by the Firm

The Firm uses the following generative AI tools, at the tiers identified, in the course of its legal work:

{ai_vendors_list}

The Firm procures these tools under enterprise-grade contracts that provide for the data-handling protections described in §4. If the Firm adds or removes a tool after the effective date of this Rider, it will update the Client at the next regular invoice or, if earlier, before the new tool is used on the Client's matter.

## 3. Categories of use

The Firm may use generative AI tools to support the following categories of work:

- Legal research, including issue spotting and case-law surveys, followed by attorney verification of each authority cited.
- Drafting support, including first drafts of memoranda, correspondence, briefs, and transactional documents, each of which is reviewed, revised, and adopted by a responsible attorney before transmission.
- Document review and summarization, including review of discovery productions, transactional diligence materials, and client-supplied documents.
- Administrative work product, including file organization and timekeeping narratives.

The Firm does not use generative AI tools to make final strategic decisions, to execute court filings, or to transmit communications to the Client, adverse parties, or tribunals without attorney review and adoption.

## 4. Human oversight and responsibility

Consistent with ABA Model Rules 1.1, 1.3, and 5.3, and ABA Formal Opinion 512:

- A qualified attorney of the Firm reviews and is responsible for all work product before it leaves the Firm, whether or not generative AI was used in its preparation.
- The attorney verifies the accuracy of every authority cited and the substance of every factual assertion, regardless of the tool's output.
- The attorney supervises the use of generative AI tools as nonlawyer assistance under Model Rule 5.3.
- The use of a generative AI tool does not reduce the attorney's responsibility to the Client for the quality, accuracy, and timeliness of the work.

## 5. Confidentiality and data handling

Consistent with ABA Model Rule 1.6, ABA Formal Opinion 512, and the Firm's obligations to the Client:

- Client-confidential information transmitted to a generative AI tool is transmitted only to tools procured under enterprise-grade contracts that (i) do not train on client data, (ii) provide encryption in transit and at rest, and (iii) segregate the Firm's tenant from other customers.
- **No client data is used to train third-party models.**
- Prompts and outputs are retained on the Firm's systems for {retention_period} and then deleted in accordance with the Firm's record-retention policy, subject to any applicable litigation hold.
- The Firm does not share client-confidential information with any AI tool not listed in §2, and does not use any consumer-tier generative AI tool for client work.
- If the Firm proposes to input Client-confidential information into a self-learning generative AI tool whose terms permit training on inputs, the Firm will not do so without first obtaining the Client's informed consent under ABA Formal Opinion 512, which will include (i) the Firm's best professional judgment as to why the tool is to be used, (ii) the kinds of Client information that would be disclosed to the tool, (iii) the specific risks of that disclosure (including the ways in which others might use the information against the Client's interests), (iv) the benefits to the representation, and (v) the Client's right to decline. The self-learning disclosure in this paragraph is not boilerplate; the required explanation is made in writing specific to the contemplated use.
- Consistent with ABA Formal Opinion 512, the Firm will additionally disclose its use of generative AI to the Client whenever (a) the Client requests such disclosure, (b) the terms of this engagement require it, or (c) the output of a generative AI tool will influence a significant decision in the representation.

## 6. Fees

The Firm's fee treatment for generative AI use in this matter is as follows:

{fee_treatment_paragraph}

The Firm does not bill the Client for the internal cost of its AI tools except as disclosed above. Efficiency gained from AI assistance is reflected in the Firm's time records consistently with the state bar rules on reasonable fees (Model Rule 1.5). Where the Firm's use of a generative AI tool is relevant to the basis or reasonableness of the Firm's fee, the Firm will obtain the Client's informed consent in advance, consistent with ABA Formal Opinion 512.

## 7. Client opt-out

The Client may instruct the Firm, at any time and without penalty, to cease using generative AI tools on the Client's matter. The opt-out takes effect upon receipt by the responsible attorney identified in §9 and applies prospectively.

To exercise the opt-out, the Client provides a signed writing — which may be by email from an authorized representative — to the responsible attorney. The Firm will confirm receipt and the prospective effective date of the opt-out within three business days.

An opt-out does not affect work already performed; the Firm remains responsible under §4 for work product it has already delivered.

## 8. Updates

If the Firm materially changes its use of generative AI on the Client's matter — including the addition of a new tool, a change in data-handling practices, or a change in retention policy — the Firm will provide the Client with a revised Rider or a written notice before the change takes effect.

## 9. Questions and contact

Questions about this Rider, or any notice under §7, may be directed to:

**{responsible_attorney}**
{responsible_attorney_title}
{firm_name}
{responsible_attorney_email}
{responsible_attorney_phone}

## 10. Acknowledgment

By countersigning below, the Client acknowledges that the Client has read this Rider, has had the opportunity to ask questions about it, and consents to the Firm's use of generative AI tools as described, subject to the Client's opt-out right under §7.

---

**FIRM**

{firm_name}

By: ________________________________________
Name: {responsible_attorney}
Title: {responsible_attorney_title}
Date: ____________________

**CLIENT**

{client_name}

By: ________________________________________
Name: ____________________________________
Title: ___________________________________
Date: ____________________

---

*This Rider is made consistently with ABA Model Rules 1.1, 1.3, 1.4, 1.5, 1.6, and 5.3, and with ABA Formal Opinion 512 (July 29, 2024), as well as applicable {state_or_member_state} professional-conduct rules. It is effective as of {effective_date}.*
