---
name: AI-Use Disclosure Rider
description: Generate a plain-language engagement-letter rider or retainer addendum that discloses a law firm's use of generative AI to its client. Use when drafting an AI disclosure to client, preparing a retainer addendum for AI use, updating an engagement letter for ChatGPT/Claude/Copilot use, meeting ABA Model Rules 1.1/1.4/1.6/5.3 client-communication duties, discharging ABA Formal Opinion 512 obligations, aligning with SRA principles for AI use in a UK practice, disclosing AI use under the EU AI Act and GDPR, or producing a client-friendly summary of firm AI practices. Produces a US, UK, or EU regional rider plus a 150-word plain-English client summary and a redline-ready side-by-side.
version: 1.0.0
license: MIT
---

# AI-Use Disclosure Rider

A Claude Skill that generates a plain-language engagement-letter rider (or retainer addendum) disclosing a law firm's use of generative AI tools to its client, in a form that is consistent with the governing professional-conduct regime in the United States, the United Kingdom, or the European Union.

The rider is a short, client-facing document — written in plain English, not in legalese — that tells the client which AI tools the firm uses, what the firm does with the client's data when it uses them, who bears responsibility for the work product, and how the client may opt out. It is drafted to sit at the end of an engagement letter or retainer, and to be acknowledged by the client's countersignature on a separate acknowledgment page so that a firm can evidence informed consent where informed consent is required.

Reviewed April 2026. MIT-licensed. The drafting attorney (or, in the UK, solicitor) remains responsible for the final form of the rider and for its compatibility with the firm's professional-conduct regime, any applicable malpractice carrier guidance, and the firm's internal AI-use policy.

## 1. Purpose

A growing number of professional-conduct authorities either require, or treat as a best practice, an affirmative disclosure to the client of the firm's use of generative AI:

- **United States** — ABA Model Rules 1.1 (Comment [8] on technological competence), 1.3 (diligence), 1.4 (communication), 1.5 (fees), 1.6 (confidentiality), and 5.3 (supervision of nonlawyer assistance, which the ABA has applied to AI tools). ABA Formal Opinion 512 (July 29, 2024) addresses the use of generative AI by lawyers and sets out the duties that attach. A number of state ethics committees have issued complementary opinions; two examples are Florida Bar Ethics Opinion 24-1 (January 19, 2024) and the California State Bar's Practical Guidance for the Use of Generative Artificial Intelligence in the Practice of Law (November 16, 2023).
- **United Kingdom** — SRA Principles (particularly Principles 2, 5, and 7), the SRA Code of Conduct for Solicitors, RELs and RFLs (Paragraphs 3.2-3.3 on competence, 6.3 on confidentiality, 7.1 on compliance), and the SRA's Risk Outlook guidance on the use of artificial intelligence. Data-protection obligations under the Data Protection Act 2018 and the UK GDPR apply in parallel.
- **European Union** — Regulation (EU) 2024/1689 (the EU AI Act, in force August 1, 2024) and the General Data Protection Regulation (Regulation (EU) 2016/679), particularly Articles 6, 9, 13-15, and 22 GDPR. National bar codes and the CCBE's guidance on the use of AI by European lawyers provide complementary rules.

This skill produces a client-facing rider that reflects each of those regimes, and a plain-English summary the client can read in under a minute.

## 2. Intake

Before drafting, the skill collects the following fields. Do not default-fill any of them — every field must be confirmed by the drafting attorney:

| Field | Notes |
|-------|-------|
| `firm_name` | The legal name of the firm as it appears on the engagement letter. |
| `jurisdiction` | One of: `US`, `UK`, `EU`. If more than one applies (e.g., a US firm with an EU client under GDPR), produce multiple riders and flag the overlap in the client summary. |
| `state_or_member_state` | For US: the state whose ethics rules govern. For EU: the Member State of engagement. Not required for UK. |
| `ai_vendors` | The list of AI tools the firm uses (e.g., OpenAI ChatGPT Enterprise, Anthropic Claude for Work, Microsoft 365 Copilot, Google Gemini for Workspace, Harvey, Thomson Reuters CoCounsel, Lexis+ AI). Name each vendor and product tier. |
| `retention_period` | How long prompts and outputs are retained before deletion, stated in calendar days or months, and referenced in §5 of the rider. |
| `training_data` | Whether client data is used to train third-party models. This field is sensitive. If the drafting attorney does not know, STOP — the skill must not guess or default. The usual correct answer for enterprise-tier vendor contracts is "no," but the attorney must confirm the vendor-specific contract. |
| `opt_out_mechanism` | The form the client's opt-out must take (typically a signed writing to the responsible attorney). |
| `fee_treatment` | One of: `no_charge` (AI use folded into the standard hourly rate with no separate charge); `efficiency_discount` (AI use results in an efficiency discount passed to the client); `cost_passthrough` (vendor seat cost is billed as a disbursement); `hybrid` (some combination — describe). |
| `effective_date` | The rider's effective date, typically the same date as the parent engagement letter. |
| `responsible_attorney` | The attorney or partner responsible for AI governance at the firm, to whom opt-out notices are directed. |

## 3. Generation workflow

1. Load the template for the selected jurisdiction (`rider-us-template.md`, `rider-uk-template.md`, or `rider-eu-template.md`).
2. Substitute every `{placeholder}` from the intake. Do not leave any placeholder un-substituted in the final output; if a field is unknown, the skill halts and asks for confirmation.
3. Generate the plain-English client summary from `client-summary-template.md`, substituting the same placeholders. The summary must remain under approximately 150 words.
4. Produce a redline-ready side-by-side of the current engagement letter and the rider if the drafting attorney supplies the engagement letter; otherwise the rider is delivered standalone.
5. Deliver the output as Markdown, and — if requested — render through the `docx` skill for client-facing signature.

## 4. Reference sample

Every rendered rider and every rendered client summary must include the following sentences, verbatim, in the "What this means for you" paragraph of the client summary and in the opening of Article 1 (Scope) of the rider. In the UK template the word "attorney" is replaced with "solicitor or other authorised lawyer"; in the EU template, with "lawyer."

> In representing you, [Firm] may use generative AI tools to assist with research, drafting, and document review. A qualified attorney reviews and is responsible for all work product before it leaves this office.
>
> - No client data is used to train third-party models.
> - Prompts and outputs are retained per §5 below.
> - You may opt out at any time in writing.

The `[Firm]` token is replaced with `firm_name` from the intake. The four sentences anchor the rider — their presence is what makes the disclosure a disclosure.

## 5. Regional compliance hooks

The three templates point to the following authorities. The skill does not reproduce the text of those authorities; it names them so that the drafting attorney may audit the rider against the primary sources.

- **`rider-us-template.md`** — ABA Model Rules 1.1 cmt. [8], 1.3, 1.4, 1.5, 1.6, 5.3; ABA Formal Opinion 512 (July 29, 2024); state ethics opinion for `state_or_member_state` (e.g., Florida Bar Ethics Op. 24-1 (Jan. 19, 2024); California State Bar, Practical Guidance for the Use of Generative Artificial Intelligence in the Practice of Law (Nov. 16, 2023)).
- **`rider-uk-template.md`** — SRA Principles 2, 5, and 7; SRA Code of Conduct for Solicitors, RELs and RFLs, Paragraphs 3.2-3.3, 6.3, and 7.1; SRA Risk Outlook: the use of artificial intelligence in the legal market; Data Protection Act 2018; UK GDPR.
- **`rider-eu-template.md`** — Regulation (EU) 2024/1689 (EU AI Act), particularly Articles 4 (AI literacy), 50 (transparency obligations), and Title III risk classifications as relevant; Regulation (EU) 2016/679 (GDPR), Articles 6, 9, 13-15, 22; CCBE guidance on the use of AI by European lawyers; the national bar code of the Member State of engagement.

## 6. Customization rules

- Do not default-fill the `training_data` field. If the firm has not confirmed that client data is excluded from model training, the skill halts and asks.
- Do not promise encryption, retention, or data-handling practices the firm has not independently verified against its vendor contracts.
- Do not purport to disclaim attorney responsibility for the work product. The human attorney remains responsible.
- Do not omit the opt-out mechanism.
- Do not substitute the Reference Sample. The four sentences in §4 are load-bearing and appear verbatim.

## 7. Output format

The skill delivers four artifacts, in this order:

1. The rider, in Markdown, ready to paste into the engagement letter as an annex or to render as a `.docx`.
2. The plain-English client summary, in Markdown, suitable for pasting into the cover email that transmits the engagement letter.
3. A redline-ready side-by-side of the engagement letter and rider (only if the engagement letter is supplied).
4. A short acknowledgment page (generated as the final page of the rider) for client countersignature.

## 8. What this skill is and is not

- **It is** a template generator reflecting April 2026 positions of the principal professional-conduct authorities in the United States, the United Kingdom, and the European Union.
- **It is** grounded by reference to primary sources (Model Rules, SRA Code, EU AI Act, GDPR) — the drafting attorney verifies the output against those sources.
- **It is not** a substitute for the drafting attorney's independent professional judgment.
- **It is not** a substitute for the firm's vendor-contract review, its data-protection-impact assessment, or its malpractice carrier's guidance.
- **It is not** legal advice to the firm or to the client. The rider must be reviewed and adopted by a qualified attorney (or, in the UK, solicitor) of the firm before use.

## 9. Maintenance

Reviewed at least annually, and additionally upon (i) issuance of a new ABA formal opinion on AI, (ii) a material update to the SRA Code or SRA Risk Outlook, (iii) entry-into-force of any new EU AI Act implementing act that bears on lawyer disclosure, or (iv) a material change to the firm's AI-tool vendor list or data-processing practices. The skill's `version` field is bumped on each review and prior versions are archived.

*Last reviewed: April 2026.*
