<!--
AI-USE DISCLOSURE RIDER — UNITED KINGDOM TEMPLATE
Authority hooks: SRA Principles 2, 5, and 7; SRA Code of Conduct for
Solicitors, RELs and RFLs, Paragraphs 3.2-3.3, 6.3, 7.1; SRA Risk Outlook
guidance on AI; Data Protection Act 2018; UK GDPR.

The word "attorney" in the Reference Sample is replaced with "solicitor
or other authorised lawyer." Do not modify Article 1 — the four anchor
sentences are load-bearing.
-->

# CLIENT CARE LETTER — SUPPLEMENT ON THE USE OF GENERATIVE ARTIFICIAL INTELLIGENCE

**Firm:** {firm_name}
**Client:** {client_name}
**Client care letter dated:** {engagement_letter_date}
**Rider effective date:** {effective_date}
**Governing jurisdiction:** England and Wales (or as specified: {state_or_member_state})

This supplement forms part of, and is governed by the same terms as, the client care letter between {firm_name} (the "Firm") and {client_name} (the "Client") dated {engagement_letter_date} (the "Client Care Letter"). Where this supplement conflicts with the Client Care Letter, this supplement controls with respect to the Firm's use of generative artificial intelligence tools.

## 1. Scope of disclosure

In representing you, {firm_name} may use generative AI tools to assist with research, drafting, and document review. A qualified solicitor or other authorised lawyer reviews and is responsible for all work product before it leaves this office.

- No client data is used to train third-party models.
- Prompts and outputs are retained per §5 below.
- You may opt out at any time in writing.

This disclosure is made consistently with the Firm's duties under the SRA Principles (in particular Principles 2 (upholding public trust), 5 (acting with integrity), and 7 (acting in the best interests of each client)), the SRA Code of Conduct for Solicitors, RELs and RFLs (in particular Paragraphs 3.2-3.3 (competence), 6.3 (confidentiality), and 7.1 (compliance)), the SRA's Risk Outlook guidance on the use of artificial intelligence in the legal market, and the Firm's obligations under the Data Protection Act 2018 and the UK GDPR.

## 2. AI tools used by the Firm

The Firm uses the following generative AI tools, at the tiers identified, in the course of its legal work:

{ai_vendors_list}

The Firm procures these tools under enterprise-grade contracts that provide for the data-handling protections described in §4. If the Firm adds or removes a tool after the effective date of this supplement, it will inform you at the next regular invoice or, if earlier, before the new tool is used on your matter.

## 3. Categories of use

The Firm may use generative AI tools to support the following categories of work:

- Legal research, including issue spotting and case-law surveys, followed by solicitor verification of each authority cited.
- Drafting support, including first drafts of attendance notes, correspondence, advice, and transactional documents, each of which is reviewed, revised, and adopted by a responsible solicitor before transmission.
- Document review and summarisation, including review of disclosure productions, transactional diligence materials, and client-supplied documents.
- Administrative work product, including file organisation and time recording.

The Firm does not use generative AI tools to make final strategic decisions, to execute court filings, or to transmit communications to the Client, other parties, or tribunals without solicitor review and adoption.

## 4. Competence and supervision

Consistent with Paragraphs 3.2-3.3 of the SRA Code of Conduct for Solicitors, RELs and RFLs, and with the competence principle (Principle 7):

- A qualified solicitor or other authorised lawyer of the Firm reviews and is responsible for all work product before it leaves the Firm, whether or not generative AI was used in its preparation.
- That person verifies the accuracy of every authority cited and the substance of every factual assertion, regardless of the tool's output.
- The Firm maintains adequate training and supervision in the use of generative AI tools under Paragraph 3.5 of the Code of Conduct.
- The use of a generative AI tool does not reduce the solicitor's responsibility to the Client for the quality, accuracy, and timeliness of the work.

## 5. Confidentiality and data protection

Consistent with Paragraph 6.3 of the SRA Code of Conduct, the Data Protection Act 2018, and the UK GDPR:

- Client-confidential information transmitted to a generative AI tool is transmitted only to tools procured under enterprise-grade contracts that (i) do not train on client data, (ii) provide encryption in transit and at rest, and (iii) segregate the Firm's tenant from other customers.
- **No client data is used to train third-party models.**
- Prompts and outputs are retained on the Firm's systems for {retention_period} and then deleted in accordance with the Firm's retention policy, subject to any applicable professional or regulatory hold.
- Where the Firm's use of a generative AI tool amounts to processing of personal data within the meaning of the UK GDPR, the Firm acts as controller (or, where applicable, joint controller) and has completed or updated its data protection impact assessment before deploying the tool on client matters.
- Consistent with the SRA's compliance-tips guidance on the use of AI and technology, the Firm does not input identifiable client data into a generative AI tool without the Client's informed consent, and is transparent about the data used, the oversight measures in place, and the reasons AI is used for the task (the SRA's "explainability" principle).
- The Firm does not share client-confidential information with any AI tool not listed in §2, and does not use any consumer-tier generative AI tool for client work.

## 6. Fees

The Firm's fee treatment for generative AI use in this matter is as follows:

{fee_treatment_paragraph}

The Firm's charges are consistent with its obligation under Paragraph 8.7 of the SRA Code of Conduct to provide the Client with information on the overall cost of the matter and on any reasonably foreseeable costs.

## 7. Client opt-out

The Client may instruct the Firm, at any time and without penalty, to cease using generative AI tools on the Client's matter. The opt-out takes effect upon receipt by the responsible solicitor identified in §9 and applies prospectively.

To exercise the opt-out, the Client provides a signed writing — which may be by email from an authorised representative — to the responsible solicitor. The Firm will confirm receipt and the prospective effective date of the opt-out within three working days.

An opt-out does not affect work already performed; the Firm remains responsible under §4 for work product it has already delivered.

## 8. Updates

If the Firm materially changes its use of generative AI on your matter — including the addition of a new tool, a change in data-handling practices, or a change in retention — the Firm will provide you with a revised supplement or a written notice before the change takes effect.

## 9. Questions and contact

Questions about this supplement, or any notice under §7, may be directed to:

**{responsible_attorney}**
{responsible_attorney_title}
{firm_name}
{responsible_attorney_email}
{responsible_attorney_phone}

If you are dissatisfied with any aspect of the Firm's use of AI on your matter, you may raise a complaint under the Firm's complaints procedure set out in the Client Care Letter, and — where applicable — with the Legal Ombudsman or the Solicitors Regulation Authority.

## 10. Acknowledgment

By countersigning below, the Client acknowledges having read this supplement, having had the opportunity to ask questions about it, and consenting to the Firm's use of generative AI tools as described, subject to the Client's opt-out right under §7.

---

**FIRM**

{firm_name}

By: ________________________________________
Name: {responsible_attorney}
Title: {responsible_attorney_title}
Date: ____________________

**CLIENT**

{client_name}

By: ________________________________________
Name: ____________________________________
Title: ___________________________________
Date: ____________________

---

*This supplement is made consistently with the SRA Principles (in particular Principles 2, 5, and 7), the SRA Code of Conduct for Solicitors, RELs and RFLs (in particular Paragraphs 3.2-3.3, 6.3, and 7.1), the SRA Risk Outlook guidance on the use of artificial intelligence in the legal market, the Data Protection Act 2018, and the UK GDPR. It is effective as of {effective_date}.*
