<!--
AI-USE DISCLOSURE RIDER — EUROPEAN UNION TEMPLATE
Authority hooks: Regulation (EU) 2024/1689 (EU AI Act) — particularly
Articles 4 (AI literacy) and 50 (transparency obligations) — and Regulation
(EU) 2016/679 (GDPR), Articles 6, 9, 13-15, and 22; CCBE guidance on the
use of AI by European lawyers; national bar code of the Member State of
engagement.

The word "attorney" in the Reference Sample is replaced with "lawyer."
Do not modify Article 1 — the four anchor sentences are load-bearing.
-->

# ANNEX TO ENGAGEMENT LETTER — USE OF GENERATIVE ARTIFICIAL INTELLIGENCE

**Firm:** {firm_name}
**Client:** {client_name}
**Engagement letter dated:** {engagement_letter_date}
**Annex effective date:** {effective_date}
**Member State of engagement:** {state_or_member_state}

This Annex forms part of, and is governed by the same terms as, the engagement letter between {firm_name} (the "Firm") and {client_name} (the "Client") dated {engagement_letter_date} (the "Engagement Letter"). Where this Annex conflicts with the Engagement Letter, this Annex controls with respect to the Firm's use of generative artificial intelligence tools.

## 1. Scope of disclosure

In representing you, {firm_name} may use generative AI tools to assist with research, drafting, and document review. A qualified lawyer reviews and is responsible for all work product before it leaves this office.

- No client data is used to train third-party models.
- Prompts and outputs are retained per §5 below.
- You may opt out at any time in writing.

This disclosure is made consistently with Regulation (EU) 2024/1689 (the EU AI Act), in particular the AI literacy obligation in Article 4 (applicable from February 2, 2025) and the transparency obligations in Article 50 (applicable from August 2, 2026); with Regulation (EU) 2016/679 (the General Data Protection Regulation, GDPR), in particular Articles 6, 9, 13, 14, 15, and 22; with the Council of Bars and Law Societies of Europe (CCBE) *Guide on the use of Generative AI by Lawyers* (October 2, 2025), read together with the CCBE Charter of Core Principles of the European Legal Profession and the CCBE Model Code of Conduct; and with the professional-conduct rules of the bar of {state_or_member_state}.

## 2. AI tools used by the Firm

The Firm uses the following generative AI tools, at the tiers identified, in the course of its legal work:

{ai_vendors_list}

The Firm procures these tools under enterprise-grade contracts that provide for the data-handling protections described in §4. If the Firm adds or removes a tool after the effective date of this Annex, it will inform you at the next regular invoice or, if earlier, before the new tool is used on your matter.

## 3. Categories of use

The Firm may use generative AI tools to support the following categories of work:

- Legal research, including issue spotting and case-law surveys, followed by lawyer verification of each authority cited.
- Drafting support, including first drafts of memoranda, correspondence, briefs, and transactional documents, each of which is reviewed, revised, and adopted by a responsible lawyer before transmission.
- Document review and summarization, including review of disclosure productions, transactional diligence materials, and client-supplied documents.
- Administrative work product, including file organization and time recording.

The Firm does not use generative AI tools to make final strategic decisions, to execute court filings, or to transmit communications to the Client, other parties, or tribunals without lawyer review and adoption. The Firm does not, in the course of its legal work on the Client's matter, deploy AI systems that the EU AI Act classifies as high-risk.

## 4. Human oversight and AI literacy

Consistent with Article 4 of the EU AI Act, and with the professional-conduct rules of the bar of {state_or_member_state}:

- A qualified lawyer of the Firm reviews and is responsible for all work product before it leaves the Firm, whether or not generative AI was used in its preparation.
- That lawyer verifies the accuracy of every authority cited and the substance of every factual assertion, regardless of the tool's output.
- The Firm's personnel involved in the operation or use of AI tools have a sufficient level of AI literacy, taking into account their role and the context in which the tools are used, consistent with Article 4 of the EU AI Act.
- The use of a generative AI tool does not reduce the lawyer's responsibility to the Client for the quality, accuracy, and timeliness of the work.

## 5. Confidentiality and data protection

Consistent with the GDPR and with the Firm's duty of professional secrecy:

- Client-confidential information transmitted to a generative AI tool is transmitted only to tools procured under enterprise-grade contracts that (i) do not train on client data, (ii) provide encryption in transit and at rest, (iii) segregate the Firm's tenant from other customers, and (iv) are supported by a GDPR-compliant data-processing agreement.
- **No client data is used to train third-party models.**
- Prompts and outputs are retained on the Firm's systems for {retention_period} and then deleted in accordance with the Firm's retention policy and GDPR Article 5(1)(e), subject to any applicable professional or regulatory hold.
- The lawful basis for the processing of the Client's personal data by the Firm in connection with the use of AI tools is the performance of the engagement (Article 6(1)(b) GDPR) and the Firm's legitimate interests in efficient and high-quality legal service delivery (Article 6(1)(f) GDPR). Where special categories of personal data within Article 9 GDPR are processed, the Firm relies on an additional lawful basis under Article 9(2), as documented in the Firm's records.
- The Client retains the rights of data subjects under Articles 15 to 22 GDPR, as applicable.
- The Firm does not share client-confidential information with any AI tool not listed in §2, and does not use any consumer-tier generative AI tool for client work.

## 6. Transparency under Article 50 of the EU AI Act

Article 50 of the EU AI Act applies from August 2, 2026. To the extent the Firm's use of a generative AI tool falls within Article 50, the Firm makes the following disclosures and, where applicable, aligns its labelling practices with the European Commission's Code of Practice on marking and labelling of AI-generated content (the final version of which is expected in 2026):

- Any text, image, audio, or video content generated or materially altered by a generative AI tool and transmitted to the Client as a deliverable is identified as such on its face, in a form readable by the Client and, where technically feasible, in machine-readable form.
- Where the Client interacts directly with an AI system deployed by the Firm (for example, an AI-assisted intake form or chatbot), the Client is informed at the outset of the interaction that the interaction is with an AI system and not with a natural person.
- The Firm does not deploy AI systems that produce deep fakes or that categorise natural persons into protected groups in the course of its legal work on the Client's matter.

## 7. Fees

The Firm's fee treatment for generative AI use in this matter is as follows:

{fee_treatment_paragraph}

The Firm's charges are consistent with the cost-transparency requirements of the Member State of engagement and of the Firm's bar code of conduct.

## 8. Client opt-out

The Client may instruct the Firm, at any time and without penalty, to cease using generative AI tools on the Client's matter. The opt-out takes effect upon receipt by the responsible lawyer identified in §10 and applies prospectively.

To exercise the opt-out, the Client provides a signed writing — which may be by email from an authorised representative — to the responsible lawyer. The Firm will confirm receipt and the prospective effective date of the opt-out within three working days.

An opt-out does not affect work already performed; the Firm remains responsible under §4 for work product it has already delivered.

## 9. Updates

If the Firm materially changes its use of generative AI on your matter — including the addition of a new tool, a change in data-handling practices, or a change in retention — the Firm will provide you with a revised Annex or a written notice before the change takes effect.

## 10. Questions and contact

Questions about this Annex, or any notice under §8, may be directed to:

**{responsible_attorney}**
{responsible_attorney_title}
{firm_name}
{responsible_attorney_email}
{responsible_attorney_phone}

## 11. Acknowledgment

By countersigning below, the Client acknowledges having read this Annex, having had the opportunity to ask questions about it, and consenting to the Firm's use of generative AI tools as described, subject to the Client's opt-out right under §8.

---

**FIRM**

{firm_name}

By: ________________________________________
Name: {responsible_attorney}
Title: {responsible_attorney_title}
Date: ____________________

**CLIENT**

{client_name}

By: ________________________________________
Name: ____________________________________
Title: ___________________________________
Date: ____________________

---

*This Annex is made consistently with Regulation (EU) 2024/1689 (the EU AI Act), in particular Articles 4 and 50; Regulation (EU) 2016/679 (GDPR), in particular Articles 6, 9, 13-15, and 22; the CCBE guidance on the use of artificial intelligence by European lawyers; and the professional-conduct rules of the bar of {state_or_member_state}. It is effective as of {effective_date}.*
