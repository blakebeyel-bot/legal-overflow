<!--
CLIENT SUMMARY TEMPLATE — PLAIN-ENGLISH COVER FOR THE AI-USE DISCLOSURE RIDER

Target length: approximately 150 words in the body. Written for a client who
is not a lawyer. Pair with the regional rider.

The Reference Sample — the four anchor sentences — appears verbatim in the
"What this means for you" paragraph. In the UK version, the word "attorney"
is replaced with "solicitor or other authorised lawyer"; in the EU version,
with "lawyer."
-->

# A QUICK NOTE ABOUT OUR USE OF AI

**From:** {firm_name}
**To:** {client_name}
**Date:** {effective_date}

Thank you for choosing {firm_name}. Attached to your engagement letter is a short Rider explaining our use of generative artificial intelligence (AI) on your matter. Here is what it says, in plain English:

**What this means for you.** In representing you, {firm_name} may use generative AI tools to assist with research, drafting, and document review. A qualified attorney reviews and is responsible for all work product before it leaves this office. No client data is used to train third-party models. Prompts and outputs are retained per §5 of the Rider. You may opt out at any time in writing.

**What we use AI for.** First drafts, research support, and document review — always under lawyer supervision.

**What we do not use AI for.** Final decisions, filings, or client communications without lawyer review.

**Opt-out.** Email {responsible_attorney_email} and we will stop immediately.

Questions? Reply to this email or call {responsible_attorney_phone}.

— {responsible_attorney}
{responsible_attorney_title}, {firm_name}
