# AI-Use Disclosure Rider

A Claude Skill that generates a plain-language engagement-letter rider (or retainer addendum) disclosing a law firm's use of generative AI tools to its client, in a form consistent with the governing professional-conduct regime in the United States, the United Kingdom, or the European Union.

Produces: a regional rider (US, UK, or EU), a 150-word plain-English client summary, a redline-ready side-by-side of the engagement letter and rider, and a countersignature page. MIT-licensed. Reviewed April 2026.

## Why this skill exists

The client-communication duties attached to a firm's use of generative AI are converging across jurisdictions. In the United States, ABA Formal Opinion 512 (July 29, 2024) and a growing number of state ethics opinions treat disclosure as a best practice and, in some circumstances, as required to discharge the duties of competence, communication, and confidentiality under Model Rules 1.1, 1.4, and 1.6. In the United Kingdom, the SRA's risk-outlook guidance on AI and the SRA Code of Conduct's competence, confidentiality, and communication paragraphs point in the same direction. In the European Union, the EU AI Act entered into force on August 1, 2024 and imposes transparency obligations under Article 50 and an AI-literacy obligation under Article 4; the GDPR obligations attach in parallel.

Most firms already use generative AI in some form. What many do not yet have is a short, client-facing disclosure that is accurate, professionally compliant, and accessible to a client who is not a lawyer. This skill produces that disclosure.

## Bundle contents

- `SKILL.md` — the skill definition, its intake fields, its generation workflow, and the regional compliance hooks;
- `rider-us-template.md` — US regional template, keyed to ABA Model Rules and ABA Formal Opinion 512;
- `rider-uk-template.md` — UK regional template, keyed to the SRA Principles and Code of Conduct;
- `rider-eu-template.md` — EU regional template, keyed to the EU AI Act and GDPR;
- `client-summary-template.md` — the 150-word plain-English summary;
- `prompt-pack.md` — two to three chained prompts for use with any chat model that does not support skills infrastructure; includes all three regional templates inline;
- `README.md` — this file.

## Installation

### Option 1 — Claude Code

1. Copy the `ai-use-disclosure-rider/` folder into `~/.claude/skills/` (user-level) or `.claude/skills/` at the firm project root.
2. Confirm the `docx` skill is installed if the firm wants the rider rendered as a Word document for countersignature.
3. Restart Claude Code. The skill appears under `/skills`.
4. Invoke by asking Claude to "generate an AI-use disclosure rider for {client_name}," or by pasting the engagement letter and asking Claude to "add a plain-language AI disclosure rider."

### Option 2 — Hosted Claude Skills interface

1. Zip the folder with `SKILL.md` at the archive root.
2. Upload through the Skills interface and enable for the firm's workspace.

### Option 3 — Manual prompt

Paste the body of `SKILL.md` into a system prompt, attach the engagement letter (if you have one), and run. `prompt-pack.md` is a version chained for any chat model without skills infrastructure and contains all three regional templates inline for single-pass use.

## Intake flow

The skill collects nine fields before drafting. None of them default-fills:

- `firm_name`
- `jurisdiction` — `US`, `UK`, or `EU`; more than one may apply
- `state_or_member_state`
- `ai_vendors` — vendor name and product tier
- `retention_period`
- `training_data` — if unknown, the skill halts
- `opt_out_mechanism`
- `fee_treatment` — one of: `no_charge`, `efficiency_discount`, `cost_passthrough`, `hybrid`
- `effective_date`
- `responsible_attorney` — and contact details

The nine intake fields map to the Rider's Articles 1 through 10 and appear in the client summary.

## Outputs

1. **The rider.** US, UK, or EU, in Markdown, ready to paste as an annex to the engagement letter or to render as `.docx` through the `docx` skill.
2. **The 150-word client summary.** Plain-English cover for the email that transmits the engagement letter.
3. **The redline-ready side-by-side.** Generated only if the engagement letter is supplied.
4. **The countersignature page.** The final page of the rider, for client signature.

## The four anchor sentences

Every rendered rider and every rendered client summary contains the following four sentences, verbatim, in Article 1 (Scope) of the rider and in the "What this means for you" paragraph of the client summary. The UK template substitutes "solicitor or other authorised lawyer" for "attorney"; the EU template substitutes "lawyer."

> In representing you, [Firm] may use generative AI tools to assist with research, drafting, and document review. A qualified attorney reviews and is responsible for all work product before it leaves this office.
>
> - No client data is used to train third-party models.
> - Prompts and outputs are retained per §5 below.
> - You may opt out at any time in writing.

These sentences are what turns the document into a disclosure. They are load-bearing and are not modified by the skill.

## What this skill is and is not

- **It is** a template generator reflecting April 2026 positions of the principal professional-conduct authorities in the United States, the United Kingdom, and the European Union.
- **It is** grounded by reference to primary sources — Model Rules, Formal Opinion 512, SRA Principles and Code, EU AI Act, GDPR — so the drafting attorney can audit any line of the output against the underlying rule.
- **It is not** a substitute for the drafting attorney's independent professional judgment or for the firm's vendor-contract review.
- **It is not** legal advice to the firm or to the client. The rider must be reviewed and adopted by a qualified attorney (or, in the UK, solicitor) of the firm before use.
- **It is not** a data-protection-impact assessment or a vendor due-diligence substitute. Those are separate workstreams.

## Maintenance

Reviewed at least annually, and additionally upon (i) issuance of a new ABA formal opinion on AI, (ii) a material update to the SRA Code or SRA Risk Outlook, (iii) entry-into-force of any EU AI Act implementing act that bears on lawyer disclosure, or (iv) a material change to the firm's AI-tool vendor list or data-processing practices.

## License

MIT. Use by firms and by licensed attorneys only. Not legal advice. Last reviewed April 2026.
